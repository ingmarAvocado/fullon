"""
Describe strategy
"""
import pandas
import decimal
import backtrader.indicators as btind
import backtrader as bt
import arrow
from typing import Union
from libs.strategy import loader
import pdb
import random

#from libs.strategy import strategy as strat

# logger = log.setup_custom_logger('pairtrading1a', settings.STRTLOG)

strat = loader.strategy


class Strategy(strat.Strategy):
    """description"""

    params = (('sma1', 45), ('pre_load_bars', 45))

    def local_init(self):
        """description"""
        self.verbose = True
        self.order_cmd = "spread"
        self.count = 0
        return None

    def local_next(self):
        """ description """
        self.entry_signal[0] = random.choice(["Buy", "Sell"])
        self.count = 0
        self.open_pos(0)

    def get_entry_signal(self):
        self.entry_signal[0] = "Buy"

    def risk_management(self):
        #return super().risk_management()
        if self.count > 10:
            self.close_position(0)
        self.count += 1
