"""
description
"""
from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals)

import sys
from typing import Optional
import backtrader as bt
from libs import log
from libs.strategy import drylive_strategy as strategy

logger = log.fullon_logger(__name__)


class Strategy(strategy.Strategy):
    """
    A trading strategy that uses a fixed number of bars for data feeds.

    Attributes:
        verbose (bool): Whether to print out detailed information.
        loop (int): The number of times the strategy has looped.
    """

    verbose: bool = False
    loop: int = 0

    def nextstart(self):
        """This only runs once... before init... before pre_next()...
        before next() but only once"""
        #super().nextstart()
        if self.nextstart_done is False:
            self._state_variables()
            self._save_status()
            """
            This will cancel all orders  without regards if its on a different exchange or not... just all of them
            this might have to be adjusted
            """
            #aqui tengo que mandar llamar un self.broker.cancel_all"
            '''
            self.dbase.update_orders_status(
                bot_id=self.helper.id,
                status='Cancel',
                restrict='Open')
            self.dbase.update_orders_status(
                bot_id=self.helper.id, status='Cancel', restrict='New')
            self._load_bot_vars()
            '''
        self.nextstart_done = True
        self.set_indicators_df()
        try:
            self.local_nextstart()  # How to check whether this exists or not
        except AttributeError:
            pass

    def kill_orders(self):
        """ description """
        for num in range(0, len(self.datas)):
            self.datas[num].broker.cancel_all_orders(self.getdatas[0].symbol)

    def _get_last_trade(self, datas_num):
        datas = self.datas[datas_num]
        last_trade = self.dbase.get_trades(
                ex_id=datas.feed.ex_id, symbol=datas.symbol, last=True)
        return last_trade[0]

    def notify_trade(self, trade: bt.Trade):
        print("hice un trade: ", trade)
        exit()
        pass

    def get_value(self, num: int):
        """
        returns how much value there is in an exchange
        """
        return self.broker.getvalue()

    def entry(self, datas_num: int, price: Optional[float] = None):
        """
        Compute the position size for trading, considering either a set position size,
        a percentage of available cash, or defaulting to the latest tick price.

        Args:
            datas_num (int): Index for data feed.
            price (Optional[float]): Price at which trading is considered. Defaults to the latest tick price.

        Returns:
            float: Computed position size for the trade.

        Note:
            This method uses `self.get_value(pair)` to ensure accuracy across varying collateral currencies.
        """
        # Defaulting to tick data if price not provided
        if not price:
            price = self.tick[datas_num]
        symbol = self.datas[datas_num].symbol
        # If the base currency isn't USD
        if not symbol.endswith("/USD"):
            base_currency = symbol.split("/")[1]
            conversion_rate = self.broker.get_symbol_value(symbol=f"{base_currency}/USD")
            if not conversion_rate:
                volume = 0
        else:
            conversion_rate = 1
        if self.size[datas_num]:
            usd_equivalent = self.size[datas_num] / conversion_rate  # self.p.leverage
            volume = usd_equivalent / price
        else:
            #now this is wrong, review later
            usd_equivalent = (self.cash[datas_num] * (self.p.size_pct / 100)) / conversion_rate #self.p.leverage
            volume = usd_equivalent / price
        return volume
