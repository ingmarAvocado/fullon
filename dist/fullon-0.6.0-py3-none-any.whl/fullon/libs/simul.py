"""
description
"""

import pandas as pd
from libs import settings
import sys
from libs import log
from PIL import Image
import numpy as np
from tabulate import tabulate
from typing import List, Dict, Union, Any
import json

logger = log.fullon_logger(__name__)


class simul:
    """description"""

    def __init__(self):
        """description"""
        pass

    def __del__(self):
        """description"""
        pass

    def plot(self, df):
        """description"""
        pass

    def echo_results(self, bot: dict, results: list,
                     sharpe_filter: float = 0.0,
                     short: bool = False):
        """
         Processes the simulation results for output based on given filters.
        Args:
            results (list): A list of tuples containing bot configurations and their corresponding simulation results.
            sharpe_filter (float): Sharpe ratio filter for the results.
            short (bool): A flag for whether to shorten the output.
        Note:
            This function creates an instance of the 'simul' class to parse results and deletes it afterwards.
        """

        try:
            if not results[0][1]:
                print("Simulation produced no results, maybe a problem with your parameters")
                return
        except IndexError:
            print("Simulation produced no results, maybe a problem with your parameters")
            return
        _results = []
        for bot, result in results:
            # Parse simulation results according to bot's configuration
            summaries = self.parse(results=result, bot=bot, sharpe_filter=sharpe_filter)
            if summaries:
                summary = self.calculate_final_summary(summaries=summaries)
                if summary:
                    _results.append((result, summary))
        _results = sorted(_results, key=lambda x: x[1]['Sharpe Ratio'], reverse=True)
        for result, summary in _results:
            self.verbose(dfs=summary['df'], bot=bot) if int(bot['verbose']) == 1 or int(bot['xls']) == 1 else None
            summary.pop('df')

            #  self.plot(df=df) if int(bot['visual']) == 1 else None
            if short:
                summary = self.short_detail(details=summary['params'],
                                            total_return=summary['Total Return'],
                                            roi=summary['Total ROI %'],
                                            sharpe_ratio=summary['Sharpe Ratio'])
            else:
                summary.pop('params')
            print(tabulate(summary.items(), headers=["Metric", "Value"], tablefmt="pretty"))

    def short_detail(self,
                     details: dict,
                     total_return: float,
                     roi: float,
                     sharpe_ratio: float) -> dict:
        """
        pass
        """
        detail = ''
        for k, v in details.items():
            match k:
                case 'stop_loss':
                    detail += f'SL: {v} '
                case 'take_profit':
                    detail += f'TP: {v} '
                case 'trailing_stop':
                    detail += f'TS: {v} '
                case 'timeout':
                    detail += f'TO: {v} '
                case 'size_pct':
                    pass
                case 'size':
                    pass
                case 'size_currency':
                    pass
                case 'leverage':
                    pass
                case _:
                    detail += f'{k}: {v} '
        short_summary = {
            'Details': detail,
            'Total Return': total_return,
            'Total ROI %': roi,
            'Sharpe Ratio': sharpe_ratio
        }
        return short_summary

    def verbose(self, dfs, bot):
        """description"""
        for feed, df in enumerate(dfs):
            if len(df) > 0:
                # Define desired column order, leave out columns that might not always be present
                column_order = ['ref', 'side', 'price', 'amount',
                                'cost', 'fee', 'roi', 'roi_pct',
                                'cash', 'assets', 'reason', 'timestamp']

                # Append new columns to the end of the list
                for col in df.columns:
                    if col not in column_order:
                        column_order.append(col)

                # Reorder the columns
                df = df[column_order]

                if int(bot['verbose']):
                    print(df.to_string())
                if int(bot['xls']):
                    filename= f"results_feed_{feed}.xls"
                    df.to_excel(filename, engine='openpyxl')

    def parse(self,
              results: List[Union[str, List[Dict[str, Any]]]],
              bot: Dict[str, int],
              sharpe_filter: float = 0.0) -> Dict[int, Dict[str, Any]]:
        """
        Parse the results of multiple simulations and calculate various performance metrics.

        Parameters
        ----------
        results : list
            A list of simulation results, where each result is either an error message (str) or a list of trade data (dict).
        bot : dict
            A dictionary containing various bot settings, such as verbosity, visualization, etc.
        sharpe_filter : float
            A minimum Sharpe ratio to filter the results.

        Returns
        -------
        str or None
            A formatted string containing the results of the simulations, or None if there is nothing to print.
        """
        if 'ERROR' in results[0]:
            return results[0]

        summaries = {}

        for n in range(0, len(results)):
            simulresults = results[n]

            if isinstance(simulresults, str):
                print(simulresults)
                continue

            if not simulresults:
                print(f"Empty simulation results for feed({n})")
                continue

            for p in ['verbose', 'xls', 'visual']:
                if p not in bot.keys():
                    bot[p] = 0

            detail = simulresults.pop()
            df = pd.DataFrame.from_dict(simulresults)

            if df.shape[0] <= 1:
                continue

            # Group dataframe by 'ref' to identify individual trades
            grouped_df = df.groupby('ref')

            # Initiate empty lists to store roi_pct for profitable trades, loss trades, all trades and durations
            profitable_roi_pct = []
            loss_roi_pct = []
            all_roi_pct = []
            durations = []

            # Iterate over grouped_df and add roi_pct of closing trade to the lists and calculate durations
            for name, group in grouped_df:
                closing_trade_roi_pct = group.iloc[1]['roi_pct']
                duration = group.iloc[1]['timestamp'] - group.iloc[0]['timestamp']
                durations.append(duration)
                all_roi_pct.append(closing_trade_roi_pct)
                if closing_trade_roi_pct > 0:
                    profitable_roi_pct.append(closing_trade_roi_pct)
                elif closing_trade_roi_pct < 0:
                    loss_roi_pct.append(closing_trade_roi_pct)

            # Calculating metrics
            total_fees = round(df['fee'].sum(),2)
            total_trades = len(all_roi_pct)
            profitable_trades = len(profitable_roi_pct)
            loss_trades = len(loss_roi_pct)
            win_rate = round((profitable_trades / total_trades) * 100, 4)
            average_return = round(np.mean(all_roi_pct), 4)
            median_return = round(np.median(all_roi_pct), 4)
            neg_std_dev = round(np.std(loss_roi_pct), 4)
            pos_std_dev = round(np.std(profitable_roi_pct), 4)
            average_duration = round(np.mean(durations).total_seconds(), 4) # In seconds
            sharpe_ratio = round(average_return / np.std(all_roi_pct), 4) # Sharpe ratio calculation
            if sharpe_ratio < sharpe_filter:
                return
            total_return = round(df['roi'].sum(), 2)
            roi = df.at[df.shape[0]-1, 'assets'] - 10000
            roi = round(100 - (10000 - roi) / 10000 * 100, 2)

            # Starting and ending dates
            start_date = df['timestamp'].min()
            end_date = df['timestamp'].max()

            # Placeholder for Profit Factor, Recovery Factor
            profit_factor = "placeholder"
            recovery_factor = "placeholder"

            # Create summary dictionary
            summary = {
                'Strategy': detail['strategy'],
                'Symbol': detail['symbol'],
                'Start Date': start_date,
                'End Date': end_date
            }
            summary.update(detail['params'])
            summary.update({
                'params': detail['params'],
                'Total Trades': total_trades,
                'Profitable Trades': profitable_trades,
                'Loss Trades': loss_trades,
                'Win Rate (%)': win_rate,
                'Total Fees': total_fees,
                'Average Return %': average_return,
                'Total Return': total_return,
                'Total ROI %': roi,
                'Median Return': median_return,
                'Negative Returns Standard Deviation': neg_std_dev,
                'Positive Returns Standard Deviation': pos_std_dev,
                'Average Duration (hours)': round(average_duration/60/60, 2),
                'Profit Factor': profit_factor,
                'Recovery Factor': recovery_factor,
                'Sharpe Ratio': sharpe_ratio,
                'df': df
            })
            summaries[n] = summary

        #so what happens is that results is a dict like {feed_number, simulation results}, some times i can have
        # two feeds with results (like when pairs trading)
        # but right now i am making two summaries, make it so that even if i have two feeds i return one (by doing matematics on each summary i guess)
        return summaries

    @staticmethod
    def round_floats_in_dict(d, decimal_places=2):
        for k, v in d.items():
            if isinstance(v, float):
                d[k] = round(v, decimal_places)
        return d

    def calculate_final_summary(self, summaries: Dict[int, Dict[str, Any]]) -> Dict[str, Any]:

        final_summary = {}
        n = len(summaries)

        # Static info
        static_keys = [
            'Strategy', 'Symbol', 'stop_loss', 'take_profit',
            'trailing_stop', 'timeout', 'size_pct', 'size',
            'rsi_upper', 'rsi_lower', 'rsi_period', 'leverage', 'params'
        ]
        final_summary.update(
            {key: summaries[0][key] for key in static_keys}
        )

        # Aggregated metrics
        aggregated_keys = [
            'Total Trades', 'Profitable Trades', 'Loss Trades',
            'Total Fees', 'Total Return', 'Total ROI %'
        ]
        final_summary.update(
            {key: sum(summaries[i][key] for i in summaries)
             for key in aggregated_keys}
        )

        # Averaged metrics
        averaged_keys = [
            'Win Rate (%)', 'Average Return %', 'Median Return',
            'Negative Returns Standard Deviation',
            'Positive Returns Standard Deviation',
            'Average Duration (hours)', 'Sharpe Ratio'
        ]
        final_summary.update(
            {key: sum(summaries[i][key] for i in summaries) / n
             for key in averaged_keys}
        )

        dfs = [summaries[i]['df'] for i in summaries]
        final_summary.update({'df': dfs})

        # Date stuff
        final_summary['Start Date'] = summaries[0]['Start Date']
        final_summary['End Date'] = summaries[0]['End Date']

        final_summary = self.round_floats_in_dict(final_summary)

        return final_summary
