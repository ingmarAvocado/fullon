"""
Cache class for managing caching operations with Redis.
The Cache class provides functionality to interact with
a Redis cache server, including creating, updating,
and retrieving cache entries. It also includes utility
methods for testing the connection to the cache server,
preparing the cache, and filtering cache entries based
on timestamps and component types.
"""

import time
import json
import redis
import arrow
from libs import log
from libs.caches import tick_cache as cache
from libs.structs.position_struct import PositionStruct
from typing import Dict, Optional, List

logger = log.fullon_logger(__name__)

'''
try:
    EXCHANGES_DIR = os.listdir('exchanges/')
except FileNotFoundError:
    EXCHANGES_DIR = os.listdir('fullon/exchanges/')
'''
EXCHANGES_DIR = ['kraken', 'kucoin_futures']


class Cache(cache.Cache):
    """
    A class for managing caching operations with Redis.
    Attributes:
.
    """

    def upsert_positions(self, ex_id: str, positions: Dict) -> bool:
        """
        Upserts account information by symbol.

        :param user_ex: UserEx object containing user and exchange information.
        :param account: A dictionary containing account information.
        :param date: The date when the account information is updated.
        :param futures: A boolean flag indicating if the exchange is a futures exchange.
        :return: True if the operation is successful, False otherwise.
        """
        try:
            user_ex = self.get_exchange(ex_id=ex_id)
            if user_ex.ex_id == '':
                return False
            uid = user_ex.uid
            key = f"account_positions"
            subkey = user_ex.name
            if positions == {} or self._check_position_dict(pos=positions) is False:
                if self.conn.hdel(key, subkey):
                    return True
                return False
            positions['timestamp'] = arrow.utcnow().timestamp()
            self.conn.hset(key, subkey, json.dumps(positions))
        except AttributeError as error:
            print(str(error))
            return False
        return True

    def upsert_user_account(self, ex_id: object, account: dict) -> bool:
        """
        Upserts user account.

        Args:
            uid (str): User ID.
            ex_id (str): Exchange ID.
            account (dict): Account information.
            date (str): Date information.

        Returns:
            bool: True if successful, False otherwise.
        """
        date = arrow.utcnow().format()
        try:
            key = f"{ex_id}"
            account['date'] = date
            self.conn.hset("accounts", key, json.dumps(account))
            return True
        except AttributeError:
            pass
        return False

    def clean_positions(self) -> int:
        """
        removes all positions from redis

        """
        return self.conn.delete("account_positions")

    def get_all_positions(self, ex_id: str) -> List[PositionStruct]:
        """
        Returns all positions from the account.

        Args:
            ex_id (str): Exchange ID.

        Returns:
            List[PositionStruct]: List of PositionStruct data.
        """
        positions = []
        try:
            user_ex = self.get_exchange(ex_id=ex_id)
            if user_ex.ex_id == '':
                return positions
            key = user_ex.name
            datas = self.conn.hget("account_positions", key)
            if not datas:
                return positions
            datas = json.loads(datas)
            for symbol, data in datas.items():
                if symbol != 'timestamp':
                    data['symbol'] = symbol
                    data['timestamp'] = datas['timestamp']
                    data = PositionStruct.from_dict(data)
                    positions.append(data)
        except (KeyError, TypeError) as error:
            logger.error(f"Error getting all positions: {error}")
            return []
        return positions


    @staticmethod
    def _check_position_dict(pos: Dict) -> bool:
        """
        Check if all items in the input dictionary have the same set of subkeys.

        :param pos: A dictionary containing pairs as keys and dictionaries with subkeys as values.
        :return: True if all items have the same set of subkeys, False otherwise.
        """
        subkeys = {'cost', 'volume', 'fee', 'price'}
        for pair, pair_data in pos.items():
            if set(pair_data.keys()) != subkeys:
                return False
        return True

    def get_position(self,
                     symbol: str,
                     ex_id: str,
                     latest: bool = False,
                     cur_timestamp: Optional[float] = None) -> PositionStruct:
        """
        Returns position from account by symbol.

        Args:
            symbol (str): Trading symbol.
            uid (str): User ID.
            ex_id (str): Exchange ID.
            latest (bool, optional): Whether to get the latest position or not. Defaults to False.
            cur_timestamp (int, optional): Current timestamp. Defaults to None.

        Returns:
            DefaultMunch or None: Position data or None if not found.
        """
        try:
            user_ex = self.get_exchange(ex_id=ex_id)
            if user_ex.ex_id == '':
                return PositionStruct(symbol=symbol)
            key = user_ex.name
            datas = self.conn.hget(f"account_positions", key)
            if not datas:
                return PositionStruct(symbol=symbol)
            datas = json.loads(datas)
            data = datas[symbol]
            data['symbol'] = symbol
            data['timestamp'] = datas['timestamp']
            data = PositionStruct.from_dict(data)
            if latest:
                if not cur_timestamp:
                    cur_timestamp = arrow.utcnow().shift(seconds=-1).timestamp()
                ws_timestamp = arrow.get(data.timestamp).timestamp()
                if ws_timestamp < cur_timestamp:
                    time.sleep(1)
                    return self.get_position(symbol=symbol,
                                             ex_id=user_ex.ex_id,
                                             latest=latest,
                                             cur_timestamp=cur_timestamp)
        except (KeyError, TypeError) as error:
            data = PositionStruct(symbol=symbol)
        return data

    def get_full_account(self, exchange: str, currency: str) -> dict:
        """
        Returns account with date.

        Args:
            exchange (str): exchange_id.
            currency (str, optional): Base currency. Defaults to "BTC".

        Returns:
           Dict: Account data
        """
        try:
            key = f"{exchange}"
            data = json.loads(self.conn.hget("accounts", key))
            return data[currency]
        except (TypeError, KeyError) as error:
            logger.error("We get error %s", str(error))
            return {}
