"""
Describe strategy
"""
import backtrader as bt
import arrow
from typing import Optional
from libs.strategy import loader
import pandas_ta
from scipy.ndimage import gaussian_filter


strat = loader.strategy


class Strategy(strat.Strategy):
    """description"""

    params = (
        ('take_profit', 2.5),
        ('trailing_stop', None),
        ('timeout', 30),
        ('stop_loss', 1.5),
        ('rsi_period', 14),
        ('rsi_upper', 63),
        ('rsi_lower', 36),
        ('pre_load_bars', 30),
        ('feeds', 2)
    )

    next_open: arrow.Arrow

    def local_init(self):
        """description"""
        self.verbose = False
        self.order_cmd = "spread"
        if self.p.timeout:
            self.p.timeout = self.datas[1].bar_size_minutes * self.p.timeout

    def local_next(self):
        """ description """
        if self.entry_signal[0]:
            if self.curtime[0] >= self.next_open:
                self.open_pos(0)

    def set_indicators_df(self):
        """
        A method to compute technical indicators and add them as new columns in the dataframe.

        For this particular implementation, we are computing and adding the following indicators:
        1. Relative Strength Index (RSI)

        Raises:
            ValueError: If 'high', 'low', or 'volume' columns are missing for computing ATR or volume volatility.
        """
        # Copy the 'close' column from OHLCV data into a new DataFrame
        self.indicators_df = self.datas[1].dataframe[['close']].copy()
        # Compute RSI and add it to the DataFrame
        self.indicators_df['rsi'] = pandas_ta.rsi(self.indicators_df['close'], length=self.p.rsi_period)
        #self.indicators_df['rsi_gaussian'] = gaussian_filter(self.indicators_df['rsi'], sigma=5)
        self.indicators_df['rsi_zlema'] = self.zlema(self.indicators_df['rsi'], 10)
        self.indicators_df['rsi_zlema_gaussian'] = gaussian_filter(self.indicators_df['rsi_zlema'], sigma=6)
        # self.indicators_df['rsi_gaussain_zlema'] = self.zlema(self.indicators_df['rsi_gaussian'], 10)
        # self.indicators_df['close_ema'] = pandas_ta.ema(self.indicators_df['close'], length=14)
        # self.indicators_df['close_sma'] = pandas_ta.sma(self.indicators_df['close'], length=14)
        self.indicators_df['rsi'] = self.indicators_df['rsi_zlema_gaussian']
        # After all computations, handle NaN values introduced by the rolling window calculations
        self.indicators_df = self.indicators_df.dropna()
        # Return the updated DataFrame with the new indicators
        return self.indicators_df

    def zlema(self, series, period):
        """Compute the Zero-Lag Exponential Moving Average"""
        lag = series.shift(period - 1)
        zlema_series = (2 * series - lag)
        return zlema_series.ewm(span=period, adjust=False).mean()

    def set_indicators(self):
        try:
            rsi = self.indicators_df.loc[self.curtime[1].format('YYYY-MM-DD HH:mm:ss'), 'rsi']
            if rsi:
                self.set_indicator('rsi', round(rsi, 2))
        except KeyError:
            self.set_indicator('rsi', None)

    def local_nextstart(self):
        """ Only runs once, before local_next"""
        self.next_open = self.curtime[0]

    def get_entry_signal(self):
        try:
            self.entry_signal[0] = ""
            rsi = self.indicators.rsi
            if rsi:
                if rsi < self.p.rsi_lower:  # if the RSI is less than the lower threshold
                    self.entry_signal[0] = "Sell"

                elif rsi > self.p.rsi_upper:  # in the market & RSI greater than upper threshold
                    self.entry_signal[0] = "Buy"
        except KeyError:
            pass

    def risk_management(self):
        """
        Handle risk management for the strategy.
        This function checks for stop loss and take profit conditions,
        and closes the position if either of them are met.

        only works when there is a position, runs every tick
        """
        # Check for stop loss
        if self.check_exit():
            self.next_open = self.time_to_next_bar(feed=1)
            self.entry_signal[0] = ""
            time_difference = (self.next_open.timestamp() - self.curtime[0].timestamp())
            if time_difference <= 2000:  # less than 60 seconds # 1 min
                self.next_open = self.next_open.shift(minutes=self.datas[1].bar_size_minutes)

    def event_in(self) -> Optional[arrow.Arrow]:
        """
        must use self.indicators_df
        """
        curtime = self.next_open.format('YYYY-MM-DD HH:mm:ss')

        # Filter based on conditions and time
        mask = ((self.indicators_df['rsi'] < self.p.rsi_lower) | (self.indicators_df['rsi'] > self.p.rsi_upper)) \
                & (self.indicators_df.index >= curtime)
        filtered_df = self.indicators_df[mask]

        # Check if the filtered dataframe has any rows
        if not filtered_df.empty:
            return arrow.get(str(filtered_df.index[0]))
        # If the function hasn't returned by this point, simply return None
        return None

    def event_out(self) -> Optional[arrow.Arrow]:
        """
        take profit and stop_loss are automatic
        """
        pass
