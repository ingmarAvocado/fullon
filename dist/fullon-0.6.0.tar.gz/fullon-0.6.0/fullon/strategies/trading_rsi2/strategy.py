"""
Describe strategy
"""
from multiprocessing import Value
import backtrader as bt
import arrow
from typing import Optional
from libs.strategy import loader
import pandas
import pandas_ta

#from libs.strategy import strategy as strat

# logger = log.setup_custom_logger('pairtrading1a', settings.STRTLOG)

strat = loader.strategy


class Strategy(strat.Strategy):
    """description"""

    params = (
        ('take_profit', 2.5),
        ('trailing_stop', 0.8),
        ('timeout', 24),
        ('stop_loss', 1),
        ('rsi_period', 14),
        ('rsi_upper', 58),
        ('rsi_lower', 48),
        ('pre_load_bars', 30),
        ('feeds', 2)
    )

    next_open: arrow.Arrow

    def local_init(self):
        """description"""
        self.verbose = False
        self.order_cmd = "spread"
        if self.p.timeout:
            self.p.timeout = self.datas[1].bar_size_minutes * self.p.timeout
        self.crossed_lower = False
        self.crossed_upper = False
        return None

    def local_next(self):
        """ description """
        if self.entry_signal[0]:
            if self.curtime[0] >= self.next_open:
                self.open_pos(0)
                self.crossed_lower = False
                self.crossed_upper = False

    def set_indicators_df(self):
        """
        A method to compute technical indicators and add them as new columns in the dataframe.

        For this particular implementation, we are computing and adding the following indicators:
        1. Relative Strength Index (RSI)

        Raises:
            ValueError: If 'high', 'low', or 'volume' columns are missing for computing ATR or volume volatility.
        """
        # Copy the 'close' column from OHLCV data into a new DataFrame
        self.indicators_df = self.datas[1].dataframe[['close']].copy()

        # Compute RSI and add it to the DataFrame
        self.indicators_df['rsi'] = pandas_ta.rsi(self.indicators_df['close'], length=self.p.rsi_period)

        # After all computations, handle NaN values introduced by the rolling window calculations
        self.indicators_df = self.indicators_df.dropna()

        # Return the updated DataFrame with the new indicators
        return self.indicators_df

    def set_indicators(self):
        try:
            rsi = self.indicators_df.loc[self.curtime[1].format('YYYY-MM-DD HH:mm:ss'), 'rsi']
            if rsi:
                self.set_indicator('rsi', round(rsi, 2))
        except KeyError:
            self.set_indicator('rsi', None)

    def local_nextstart(self):
        """ Only runs once, before local_next"""
        self.next_open = self.curtime[0]

    def get_entry_signal(self):
        """
        Determines the entry signal ("Buy" or "Sell") based on the Relative Strength Index (RSI).

        This method checks the current RSI value against predefined upper and lower thresholds, 
        and sets flags for potential "Buy" or "Sell" signals. Specifically:
        - A "Buy" signal is generated when the RSI crosses below the lower threshold and then rises above it.
        - A "Sell" signal is generated when the RSI crosses above the upper threshold and then falls below it.

        Parameters:
        - self.indicators.rsi (float): Current RSI value.
        - self.p.rsi_lower (float): Lower threshold for RSI.
        - self.p.rsi_upper (float): Upper threshold for RSI.

        Attributes:
        - self.crossed_lower (bool): Flag to indicate if the RSI has crossed below the lower threshold.
        - self.crossed_upper (bool): Flag to indicate if the RSI has crossed above the upper threshold.
        - self.entry_signal (list): List to store the entry signal ("Buy" or "Sell").

        Raises:
        - KeyError: If there is an error accessing the required attributes.
        """
        try:
            if self.curtime[0] >= self.next_open:
                self.entry_signal[0] = ""
                rsi = self.indicators.rsi
                if rsi:
                    if not self.crossed_upper or not self.crossed_lower:
                        if rsi < self.p.rsi_lower:  # if the RSI is less than the lower threshold
                            self.crossed_lower = True
                            return
                        elif rsi > self.p.rsi_upper:  # in the market & RSI greater than upper threshold
                            self.crossed_upper = True
                            return
                    if self.crossed_lower:
                        if rsi > self.p.rsi_lower:
                            self.entry_signal[0] = "Buy"
                            self.crossed_lower = False
                    if self.crossed_upper:
                        if rsi < self.p.rsi_upper:
                            self.entry_signal[0] = "Sell"
                            self.crossed_upper = False
        except KeyError:
            pass

    def risk_management(self):
        """
        Handle risk management for the strategy.
        This function checks for stop loss and take profit conditions,
        and closes the position if either of them are met.

        only works when there is a position, runs every tick
        """
        # Check for stop loss
        res = self.check_exit()
        if res:
            self.next_open = self.time_to_next_bar(feed=1)
            self.entry_signal[0] = ""
            time_difference = (self.next_open.timestamp() - self.curtime[0].timestamp())
            if time_difference <= 60:  # less than 60 seconds
                self.next_open = self.next_open.shift(minutes=self.datas[1].bar_size_minutes)
            self.crossed_lower = False
            self.crossed_upper = False

    def event_in(self) -> Optional[arrow.Arrow]:
        """
        Determine the timestamp of the next event where the RSI crosses either the
        lower or upper threshold and then returns to the other side of the threshold.

        The method identifies when the RSI crosses below the lower threshold or above
        the upper threshold, and then finds the point at which the RSI returns above the
        lower threshold or below the upper threshold, respectively.

        Parameters:
        - self.indicators_df (pd.DataFrame): DataFrame containing RSI values and corresponding timestamps.
        - self.p.rsi_lower (float): Lower threshold for RSI.
        - self.p.rsi_upper (float): Upper threshold for RSI.
        - self.next_open (arrow.Arrow): Timestamp of the current time.

        Returns:
        - Optional[arrow.Arrow]: Timestamp of the next event or None if no such event exists.
        """
        curtime = self.next_open.format('YYYY-MM-DD HH:mm:ss')

        # Filter the DataFrame to include only rows after the current time
        filtered_df = self.indicators_df[self.indicators_df.index >= curtime]

        # Identify where the RSI crosses the upper or lower thresholds
        crossed_upper = filtered_df['rsi'] > self.p.rsi_upper
        crossed_lower = filtered_df['rsi'] < self.p.rsi_lower

        # Find the first instance where RSI crosses one of the thresholds
        first_cross_upper = filtered_df[crossed_upper].index.min()
        first_cross_lower = filtered_df[crossed_lower].index.min()

        # If neither threshold is crossed, return None
        if pandas.isna(first_cross_upper) and pandas.isna(first_cross_lower):
            return None

        # Find when the RSI returns back below the upper threshold or above the lower threshold after crossing
        if not pandas.isna(first_cross_upper) and (pandas.isna(first_cross_lower) or first_cross_upper < first_cross_lower):
            return_date_index = (filtered_df.index > first_cross_upper) & filtered_df['rsi'].lt(self.p.rsi_upper)
            return_date = filtered_df[return_date_index].index.min()  # Using min() to find the earliest date
            self.crossed_upper = True
        else:
            return_date_index = (filtered_df.index > first_cross_lower) & filtered_df['rsi'].gt(self.p.rsi_lower)
            return_date = filtered_df[return_date_index].index.min()  # Using min() to find the earliest date
            self.crossed_lower = True

        if pandas.isna(return_date):
            return
        return arrow.get(return_date)

    def event_out(self) -> Optional[arrow.Arrow]:
        """
        take profit and stop_loss are automatic
        """
        pass
