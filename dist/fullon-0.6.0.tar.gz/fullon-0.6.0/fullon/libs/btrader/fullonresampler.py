import pandas as pd
from backtrader.feed import DataBase
import backtrader as bt
from pandas_ta.volatility import pdist
from libs.database_ohlcv import Database as DataBase_ohclv
import arrow


class FullonFeedResampler:
    """ this class can prepare DataBase resampled feed to add mehtods aparameters """

    _data: DataBase
    bars: int
    bar_size_minutes: int = 0

    def prepare(self,
                data: DataBase,
                bars: int,
                timeframe: int,
                compression: int,
                exchange: str,
                symbol: str) -> DataBase:
        """
        Prepares the data feed by adding necessary attributes and methods.

        :param data: The data feed to prepare.
        :return: The prepared data feed.
        """
        self._data = data
        self._bars = bars

        # Define the DataFrame columns
        columns = {0: "date", 1: "open", 2: "high", 3: "low", 4: "close", 5: "volume"}
        dataframe = pd.DataFrame(columns=columns.values())

        # Set the index to the 'date' column
        dataframe.set_index("date", inplace=True)

        # set time frame and period in case is needed
        setattr(data, 'timeframe', timeframe)
        setattr(data, 'compression', compression)
        setattr(data, 'exchange', exchange)
        setattr(data, 'symbol', symbol)
        setattr(data, 'table', self._get_table(exchange=exchange, symbol=symbol))

        # Set the dataframe and append_row method as attributes of the data feed
        setattr(data, 'dataframe', dataframe)
        setattr(data, 'append_row', self.append_row.__get__(data))

        # Wrap the originalnext method and set the wrapped version as an attribute of data
        original_next = data.next
        setattr(data, 'next', self._custom_next(original_next))
        bar_size = self._set_bar_size(timeframe=timeframe, compression=compression)
        setattr(data, 'bar_size_minutes', bar_size)
        return data

    def _set_bar_size(self, timeframe: int, compression: int) -> int:
        bar_size_minutes = 0
        match timeframe:
            case bt.TimeFrame.Minutes:
                bar_size_minutes = compression
            case bt.TimeFrame.Hours:
                bar_size_minutes = compression*60
            case bt.TimeFrame.Days:
                bar_size_minutes = compression*24*60
            case bt.TimeFrame.Weeks:
                bar_size_minutes = compression*24*60*7
        return bar_size_minutes

    def append_row(self) -> None:
        """
        Appends the current data line to the internal DataFrame.
        """
        to_date = self._data.datetime.datetime()
        if to_date in self._data.dataframe.index:
            return
        to_date = arrow.get(to_date)
        to_date = arrow.utcnow()
        minutes = self._data.bar_size_minutes * self._bars
        from_date = to_date.shift(minutes=-minutes)
        period = self._get_timeframe(self._data.timeframe)
        with DataBase_ohclv(exchange=self._data.exchange,
                            symbol=self._data.symbol) as dbase:
            rows = dbase.fetch_ohlcv(table=self._data.table,
                                     compression=self._data.compression,
                                     period=period,
                                     fromdate=from_date.datetime,
                                     todate=to_date.datetime)
        self._data.dataframe = self._create_dataframe(rows=rows)

    def _custom_next(self, original_next):
        """
        Wraps the original _next method to call append_row before returning its result.

        :param original_next: The original _load method of the data feed.
        :return: The wrapped _load method.
        """
        def wrapper(*args, **kwargs):
            result = original_next()
            if result:
                self.append_row()
            return result
        return wrapper

    def _get_table(self, exchange, symbol) -> str:
        """
        Gets the table name for the data feed.

        Returns:
            str: The table name.
        """
        table = exchange + "_" + symbol
        table = table.replace('/', '_')
        table = table.replace('-', '_')
        with DataBase_ohclv(exchange=exchange,
                            symbol=symbol) as dbase:
            if dbase.table_exists(schema=table, table="trades"):
                return table + ".trades"
            if dbase.table_exists(schema=table, table="candles1m"):
                return table + ".candles1m"
            raise ValueError(f"_get_table: Error, cant continue: \
                tables for schema {table} dont exist")

    def _get_timeframe(self, period: int) -> str:
        '''
        returns timeframe in string
        '''
        period_map = {
            bt.TimeFrame.Ticks: 'ticks',
            bt.TimeFrame.Minutes: 'minutes',
            bt.TimeFrame.Days: 'days',
            bt.TimeFrame.Weeks: 'weeks',
            bt.TimeFrame.Months: 'months',
        }
        return period_map[period]

    @staticmethod
    def _create_dataframe(rows) -> pd.DataFrame:
        """
        Creates a DataFrame from the input data
        :param rows: The data to be saved as df

        Returns dataframe
        """
        dataframe = pd.DataFrame(rows)
        # Rename the columns
        dataframe.rename(columns={0: "date",
                                  1: "open",
                                  2: "high",
                                  3: "low",
                                  4: "close",
                                  5: "volume"}, inplace=True)
        # Set the index to the 'date' column
        dataframe.set_index("date", inplace=True)
        # Get the columns to convert to numeric
        columns_to_convert = dataframe.columns.difference(['date'])
        # Convert the columns to numeric
        dataframe[columns_to_convert] = dataframe[columns_to_convert].apply(pd.to_numeric)
        dataframe.index = pd.to_datetime(dataframe.index)
        return dataframe
