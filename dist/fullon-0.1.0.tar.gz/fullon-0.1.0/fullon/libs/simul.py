"""
description
"""

import pandas as pd
from libs import settings
import sys
from libs import log
from PIL import Image
import numpy as np
from tabulate import tabulate
from typing import List, Dict, Union, Any

logger = log.fullon_logger(__name__)


class simul:
    """description"""

    def __init__(self):
        """description"""
        pass

    def __del__(self):
        """description"""
        pass

    def plot(self, df):
        """description"""
        pass

    def verbose(self, df, feed, bot):
        """description"""
        if len(df) > 0:
            # Define desired column order, leave out columns that might not always be present
            column_order = ['ref', 'side', 'price', 'amount', 'cost', 'fee', 'roi', 'roi_pct', 'cash', 'assets', 'reason', 'timestamp']

            # Append new columns to the end of the list
            for col in df.columns:
                if col not in column_order:
                    column_order.append(col)

            # Reorder the columns
            df = df[column_order]

            if int(bot['verbose']):
                print(df.to_string())
            if int(bot['xls']):
                filename= f"results_feed{feed}.xls"
                df.to_excel(filename, engine='openpyxl')

    def parse(self, results: List[Union[str, List[Dict[str, Any]]]], bot: Dict[str, int]) -> Union[str, None]:
        """
        Parse the results of multiple simulations and calculate various performance metrics.

        Parameters
        ----------
        results : list
            A list of simulation results, where each result is either an error message (str) or a list of trade data (dict).
        bot : dict
            A dictionary containing various bot settings, such as verbosity, visualization, etc.

        Returns
        -------
        str or None
            A formatted string containing the results of the simulations, or None if there is nothing to print.
        """
        if 'ERROR' in results[0]:
            return results[0]

        r = ""
        for n in range(0, len(results)):
            simulresults = results[n]

            if isinstance(simulresults, str):
                print(simulresults)
                continue

            if not simulresults:
                print(f"Empty simulation results feed({n})")
                continue

            for p in  ['verbose', 'xls', 'visual']:
                if not p in bot.keys():
                    bot[p] = 0

            detail = simulresults.pop()

            df = pd.DataFrame.from_dict(simulresults)

            if df.shape[0] <= 1:
                continue

            # Group dataframe by 'ref' to identify individual trades
            grouped_df = df.groupby('ref')

            # Initiate empty lists to store roi_pct for profitable trades, loss trades, all trades and durations
            profitable_roi_pct = []
            loss_roi_pct = []
            all_roi_pct = []
            durations = []

            # Iterate over grouped_df and add roi_pct of closing trade to the lists and calculate durations
            for name, group in grouped_df:
                closing_trade_roi_pct = group.iloc[1]['roi_pct']
                duration = group.iloc[1]['timestamp'] - group.iloc[0]['timestamp']
                durations.append(duration)
                all_roi_pct.append(closing_trade_roi_pct)
                if closing_trade_roi_pct > 0:
                    profitable_roi_pct.append(closing_trade_roi_pct)
                elif closing_trade_roi_pct < 0:
                    loss_roi_pct.append(closing_trade_roi_pct)

            # Calculating metrics
            total_trades = len(all_roi_pct)
            profitable_trades = len(profitable_roi_pct)
            loss_trades = len(loss_roi_pct)
            win_rate = round((profitable_trades / total_trades) * 100, 4)
            average_return = round(np.mean(all_roi_pct), 4)
            median_return = round(np.median(all_roi_pct), 4)
            neg_std_dev = round(np.std(loss_roi_pct), 4)
            pos_std_dev = round(np.std(profitable_roi_pct), 4)
            average_duration = round(np.mean(durations).total_seconds(), 4) # In seconds
            sharpe_ratio = round(average_return / np.std(all_roi_pct), 4) # Sharpe ratio calculation
            total_return = round(df['roi'].sum(), 2)
            roi = df.at[df.shape[0]-1, 'assets'] - 10000
            roi = round(100 - (10000 - roi) / 10000 * 100, 2)

            # Starting and ending dates
            start_date = df['timestamp'].min()
            end_date = df['timestamp'].max()

            # Placeholder for Profit Factor, Recovery Factor
            profit_factor = "placeholder"
            recovery_factor = "placeholder"

            # Create summary dictionary
            summary = {
                'Start Date': start_date,
                'End Date': end_date,
                'Total Trades': total_trades,
                'Profitable Trades': profitable_trades,
                'Loss Trades': loss_trades,
                'Win Rate (%)': win_rate,
                'Average Return': average_return,
                'Total Return': total_return,
                'Total ROI %': roi,
                'Median Return': median_return,
                'Negative Returns Standard Deviation': neg_std_dev,
                'Positive Returns Standard Deviation': pos_std_dev,
                'Average Duration (hours)': round(average_duration/60/60, 2),
                'Profit Factor': profit_factor,
                'Recovery Factor': recovery_factor,
                'Sharpe Ratio': sharpe_ratio
            }

            # Print the summary in a nice format
            self.verbose(df=df, feed=n, bot=bot) if int(bot['verbose']) == 1 or int(bot['xls']) == 1 else None
            print(f"\nfeed num ({n}) {detail['strategy']}[{detail['symbol']}]  p({detail['params']})")
            #  self.plot(df=df) if int(bot['visual']) == 1 else None
            print(tabulate(summary.items(), headers=["Metric", "Value"], tablefmt="pretty"))
            #print(f'Sharpe Ratio: {sharpe_ratio}  ROI % {roi}')
        return None
