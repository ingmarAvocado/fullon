import psycopg2
from libs import log
from libs import database_helpers as dbhelpers
from libs.models import exchange_model as database
from typing import List, Union, Dict, Any, Optional
import uuid


logger = log.fullon_logger(__name__)


class Database(database.Database):

    def get_base_str_params(self, str_id: str) -> Optional[Dict[str, Union[str, int, float]]]:
        """
        Fetches strategy parameters based on provided strategy ID.

        :param str_id: Strategy ID
        :return: A dictionary of strategy parameters if successful, else None.
        """
        if str_id is None:
            logger.error("str_id must not be None")
            return None

        sql = """
        SELECT take_profit, stop_loss, rolling_stop, trailing_stop, 
               timeout, timeout_size, size_pct, leverage
        FROM strategies
        WHERE str_id = %s
        """
        try:
            with self.con.cursor() as cur:
                cur.execute(sql, (str_id,))  # use a parameterized query
                row = cur.fetchone()
                self.con.commit()  # commit the transaction
                if row is not None:
                    # assuming dbhelpers.reg returns a dictionary of parameters
                    return dbhelpers.reg(cur, row)
                else:
                    return None
        except psycopg2.DatabaseError as error:
            logger.error(
                self.error_print(
                    error=error,
                    method="get_base_str_params",
                    query=sql
                )
            )
            return None
        finally:
            self.con.autocommit = True  # return to default transaction handling

    # gets the params from an strategy set by a user
    def get_str_params(self, str_id):
        sql = f"select name,value from strategies_params where str_id='{str_id}'"
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            rows = cur.fetchall()
            cur.close()
            return rows
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(
                self.error_print(
                    error=error,
                    method="get_str_params",
                    query=sql))
            if cur:
                cur.close()
            return None
        except BaseException:
            raise

    # gets the params from an strategy set by a user
    def get_str_name(self, str_id):
        sql = f"select cat_strategies.name FROM cat_strategies  WHERE  cat_strategies.cat_str_id  =  (SELECT cat_str_id FROM strategies WHERE str_id = '{str_id}')"
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            row = cur.fetchone()
            cur.close()
            return row[0]
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(
                self.error_print(
                    error=error,
                    method="get_str_params",
                    query=sql))
            if cur:
                cur.close()
            return None
        except BaseException:
            raise

    def get_user_strat_params(self, str_id: str) -> Optional[List[Dict[str, Any]]]:
        """
        Get user strategy parameters.

        Args:
            str_id (str): The strategy ID.

        Returns:
            Optional[List[Dict[str, Any]]]: A list of dictionaries containing the strategy parameters, or None if an error occurs.
        """
        try:
            sql = """SELECT public.strategies_params.name as name, public.strategies_params.value as value, public.strategies.str_id as str_id, public.strategies.name as str_name, public.strategies.uid, public.cat_strategies.name  as cat_str
            FROM public.strategies INNER JOIN public.strategies_params ON public.strategies.str_id = public.strategies_params.str_id
            INNER JOIN public.cat_strategies ON public.strategies.cat_str_id = public.cat_strategies.cat_str_id
            WHERE public.strategies.str_id='%s'""" % (str_id)
            cur = self.con.cursor()
            cur.execute(sql)
            rows = []
            for row in cur.fetchall():
                rows.append(dbhelpers.reg(cur, row))
            cur.close()
            return rows
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(
                self.error_print(
                    error=error,
                    method="get_user_strat_params",
                    query=sql))
            if cur:
                cur.close()
            return None
        except BaseException:
            raise

    def add_params_to_strategy(self, strategy: dict, params: dict) -> bool:
        """
        Add parameters to a strategy.

        Args:
            strategy (dict): A dictionary containing strategy details.
            params (dict): A dictionary containing the parameters to be added to the strategy.

        Returns:
            bool: True if the operation is successful, otherwise an exception is raised.

        Raises:
            psycopg2.DatabaseError: If an error occurs while inserting the parameters.
        """
        sql = ""
        for p in params.items():
            sql = sql + \
                f"INSERT INTO strategies_params VALUES ((SELECT str_id FROM strategies where uid = (SELECT UID FROM users WHERE mail='{strategy['user']}') AND name ='{strategy['name']}'),'{p[0]}','{p[1]}');"
        cur = None
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            if cur:
                del (cur)
            logger.warning(
                self.error_print(
                    error=error,
                    method="add_params_to_strategy",
                    query=sql))
        return True

    def add_user_strategy(self, strategy: dict) -> str:
        """
        Adds a strategy to the database.

        Args:
            strategy (dict): A dictionary containing the strategy details.

        Returns:
            str: The strategy ID.

        Raises:
            psycopg2.DatabaseError: If an error occurs while inserting the strategy or its parameters.
        """
        str_id = strategy.get('str_id', str(uuid.uuid4()))
        defaults = {
            'take_profit': None,
            'stop_loss': None,
            'rolling_stop': None,
            'trailing_stop': None,
            'timeout': None,
            'timeout_size': None,
            'leverage': 1,
            'size_pct': 5
        }

        strategy = {**defaults, **strategy}  # merge the defaults with the strategy, strategy values take precedence

        insert_strategy_sql = """
            INSERT INTO strategies
            VALUES (
                %s,
                (SELECT cat_str_id FROM cat_strategies WHERE name=%s),
                (SELECT uid FROM users WHERE mail=%s),
                %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
        """

        insert_params_sql = "INSERT INTO strategies_params(str_id, name, value) VALUES(%s, %s, %s)"

        try:
            with self.con.cursor() as cur:
                cur.execute(insert_strategy_sql, (
                    str_id,
                    strategy['cat_str_name'],
                    strategy['user'],
                    strategy['name'],
                    strategy['take_profit'],
                    strategy['stop_loss'],
                    strategy['rolling_stop'],
                    strategy['trailing_stop'],
                    strategy['timeout'],
                    strategy['timeout_size'],
                    strategy['leverage'],
                    strategy['size_pct']
                ))

                if 'params' in strategy:
                    for key, value in strategy['params'].items():
                        cur.execute(insert_params_sql, (str_id, key, value))

                self.con.commit()

        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            logger.warning(f"Error in add_user_strategy: {error}")
            raise psycopg2.DatabaseError(f"Error inserting strategy: {error}")

        return str_id

    def install_strategy(self, name: str, params: List[Dict[str, Any]] = []) -> None:
        """
        Installs a strategy in the database.

        Args:
            name (str): The name of the strategy.
            params (List[Dict[str, Any]], optional): A list of dictionaries containing the strategy parameters. Defaults to an empty list.

        Raises:
            psycopg2.DatabaseError: If an error occurs during the installation of the strategy.

        Returns:
            None
        """
        try:
            sql = f"INSERT INTO CAT_STRATEGIES(cat_str_id, name) VALUES (uuid_generate_v4(), '{name}') ON CONFLICT (name) DO NOTHING"
            with self.con.cursor() as cur:
                cur.execute(sql)
                self.con.commit()

        except (Exception, psycopg2.DatabaseError) as error:
            raise psycopg2.DatabaseError("Error installing strategy: " + str(error)) from error

        str_id = self.get_id("cat_strategies", "cat_str_id", "name", name)

        for param in params:
            options = param.get('options', "")
            sql = f"INSERT INTO cat_strategies_params (cat_str_id, name, type, options, value) VALUES ('{str_id}', '{param['name']}', '{param['type']}', {repr(options)}, '{str(param['default'])}') ON CONFLICT (cat_str_id, name) DO NOTHING"

            try:
                with self.con.cursor() as cur:
                    cur.execute(sql)
                    self.con.commit()

            except (Exception, psycopg2.DatabaseError) as error:
                raise psycopg2.DatabaseError("Error installing strategy parameters: " + str(error)) from error

        return None

    def get_user_strategies(self, uid: str) -> Optional[List[Dict[str, str]]]:
        """
        Fetches user strategies from the database.

        Args:
            uid: User ID.

        Returns:
            A list of dictionaries containing strategy details or None if an error occurred.
        """
        sql = """
        SELECT
            public.strategies.name AS str_named,
            public.cat_strategies.name AS str_name,
            public.strategies.str_id
        FROM
            public.cat_strategies
        INNER JOIN
            public.strategies ON public.cat_strategies.cat_str_id = public.strategies.cat_str_id 
        WHERE
            public.strategies.uid = %s
        """

        cur: Optional[PgCursor] = None
        try:
            cur = self.con.cursor()
            cur.execute(sql, (uid,))
            rows = [dbhelpers.reg(cur, row) for row in cur.fetchall()]
            return rows
        except (Exception, psycopg2.DatabaseError) as error:
            if "current transaction is aborted" in str(error):
                pass
            elif "invalid input syntax for type uuid" in str(error):
                pass
            else:
                logger.info(self.error_print(error=error, method="get_user_strategies", query=sql))
        finally:
            if cur is not None:
                cur.close()
        return None

    #gets exchanges read to be loaded to the bot
    def get_cat_strategies(self):
        sql="""SELECT * from cat_strategies"""        
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            rows=[]
            for row in cur.fetchall() :
                rows.append(dbhelpers.reg(cur,row))
            cur.close()
            return rows
        except (Exception, psycopg2.DatabaseError) as error:
            logger.warning(self.error_print(error = error, method = "get_cat_strategies", query = sql))
            raise         
