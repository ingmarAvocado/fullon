"""
runs a test live testing 
"""
from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals)

import sys
from libs import log
from libs.strategy import live_strategy as strategy
from time import sleep
import ipdb

logger = log.fullon_logger(__name__)


class Strategy(strategy.Strategy):
    """
    This is a derived Strategy class from the strategy.Strategy parent class.
    Additional methods or overrides can be implemented here.
    """

    verbose = False
    loop = 0
    test_side = "Buy"

    def __init__(self):
        super().__init__()

    def nextstart(self):
        """This only runs once... before init... before pre_next("""
        self._state_variables()
        if self.anypos != 0:
            logger.error("can't do this test with a position, please close it first")
            self.cerebro.runstop()

    def next(self) -> None:
        """
        The main method that runs on every iteration of the strategy.
        """
        # Check if data feed is live
        if not self.datas[0].islive():
            self.udpate_indicators_df()
            return

        self.status = "looping"
        self._state_variables()
        self._save_status()
        # Validate orders
        if not self._validate_orders():
            return self.end_next()
        self.udpate_indicators_df()
        self._pairs_test()
        # If there are no positions, call local_next, else call risk_management
        if self.anypos == 0:
            self.local_next()
        else:
            self.risk_management()
            self.end_next()

    def end_next(self):
        pass

    def _pairs_test(self):
        """ description """
        print("\n\n=======================================")
        print(f"Current loop: {self.loop}\n")
        for num in range(0, len(self.datas)):
            if self.datas[num].feed.trading:
                #print(f"Current feed: {num}")
                self._test(num, side=self.test_side)
        print("========================================")
        self.loop += 1

    def _test(self, num: int, side: str = "Buy") -> None:
        """
        Tests different kinds of sell and buy operations.

        Params:
            num: int = feed number to test on
            side: str =  what type of side (buy/sell)
        """
        self.new_candle[num] = False
        self.entry_signal[num] = ""

        match self.loop:
            case 1:
                print(f"\nStarting test for feed {num}")
                self._print_position_variables(num)
                self.new_candle[num] = False
                self.entry_signal[num] = ""

            case 2:
                print(f"\nCheck get_entry_signal feed {num}")
                signal = self.get_entry_signal()
                print(f"signal = {signal}")

            case 3:
                print(f"\nTest simple buying 1 feed {num}")
                self.entry_signal[num] = side
                print(f"signal = {side}")
                self.p.take_profit = True
            case 4:
                self._print_position_variables(num)
            case 5:
                print("I bought, i should have a position")
                self._print_position_variables(num)
                print("Now lets proceed to sell")
                try:
                    self.tick[num] = self.take_profit[num] + 10 if self.pos[num] > 0 else self.take_profit[num] - 60
                except (KeyError, TypeError):
                    raise ValueError("Strategy doesn't open a position, when it should have.")
            case 6:
                print("vendí no debe de haber nada")
                self._print_position_variables(num)
            case 8:
                print(f"\nTest simple buying 2 feed {num}")
                self.entry_signal[num] = side
                self.p.stop_loss = True
            case 9:
                self._print_position_variables(num)
            case 10:
                print(f"\nTest Stop Loss feed {num}")
                self.tick[num] = self.stop_loss[num] - 1 if self.pos[num] > 0 else self.stop_loss[num] + 1
            case 11:
                self._print_position_variables(num)
            case 12:
                print(f"\nTest simple buying 3 feed {num}")
                self.entry_signal[num] = side
                self.p.rolling_stop = True
            case 13:
                self._print_position_variables(num)
            case 14:
                print(f"\nTest rolling_stop (stop should change in next loop)  feed {num} ")
                self.entry_signal[num] = side
                self.tick[num] = self.rolling_stop[num] + 1 if self.pos[num] > 0 else self.rolling_stop[num] - 1
                self.p.take_profit = False
                self.p.trailing_stop = False
                self.p.stop_loss = False
            case 15:
                self._print_position_variables(num)
            case 16:
                print(f"\nNow testing stop_loss from rolling_stop  feed {num}")
                self.p.take_profit = True
                self.p.trailing_stop = True
                self.p.stop_loss = True
                self.entry_signal[num] = side
                self.tick[num] = self.stop_loss[num] - 1 if self.pos[num] > 0 else self.stop_loss[num] + 1
            case 17:
                self._print_position_variables(num)
            case 18:
                print(f"\nTest simple buying 4  feed {num}")
                self.entry_signal[num] = side
                self.p.trailing_stop = True
                self.p.stop_loss = False
                self.p.rolling_stop = False
            case 19:
                self._print_position_variables(num)
            case 20:
                print(f"\nTest simple buying 4  feed {num}")
                self.tick[num] = self.trailing_stop[num] - 1 if self.pos[num] > 0 else self.trailing_stop[num] + 1
            case 21:
                self._print_position_variables(num)
            case 22:
                print("aca: ", self.loop)
                if self.test_side == "Buy":
                    self.test_side = "Sell"
                    self.loop = 0
                else:
                    print("test done")
                    self.cerebro.runstop()

    def _get_last_trade(self, datas):
        return self.last_trade

    def entry(self, datas_num, price=None):
        """
        Lets buy only for five USD
        """
        if self.dry_run:
            return strategy.strategy.Strategy.entry(
                self=self, datas_num=datas_num, price=price)
        if 'USD' in self.datas[datas_num].symbol:
            return 4 / self.tick[datas_num]
        else:
            logger.error("This test should be done with a USD as base currency")

    def notify_trade(self, trade):
        if self.dry_run:
            return strategy.strategy.Strategy.notify_trade(
                self=self, trade=trade)
        else:
            print("perro")
            exit()
            return super().notify_trade(trade=trade)

    '''
    def _get_last_trade(self, datas):
        if self.dry_run:
            return strategy.strategy.Strategy._get_last_trade(
                self=self, datas=datas)
        else:
            return super()._get_last_trade(datas=datas)
    '''
