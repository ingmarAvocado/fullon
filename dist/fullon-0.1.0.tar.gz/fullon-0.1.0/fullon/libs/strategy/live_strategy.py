"""
description
"""
from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals)

import sys
from typing import List
import backtrader as bt
from libs import log
from libs.strategy import drylive_strategy as strategy

logger = log.fullon_logger(__name__)


class Strategy(strategy.Strategy):
    """
    A trading strategy that uses a fixed number of bars for data feeds.

    Attributes:
        verbose (bool): Whether to print out detailed information.
        loop (int): The number of times the strategy has looped.
    """

    verbose: bool = False
    loop: int = 0

    def nextstart(self):
        """This only runs once... before init... before pre_next()...
        before next() but only once"""
        #super().nextstart()
        if self.nextstart_done is False:
            self._state_variables()
            self._save_status()
            """
            This will cancel all orders  without regards if its on a different exchange or not... just all of them
            this might have to be adjusted
            """
            #aqui tengo que mandar llamar un self.broker.cancel_all"
            '''
            self.dbase.update_orders_status(
                bot_id=self.helper.id,
                status='Cancel',
                restrict='Open')
            self.dbase.update_orders_status(
                bot_id=self.helper.id, status='Cancel', restrict='New')
            self._load_bot_vars()
            '''
        self.nextstart_done = True
        self.set_indicators_df()
        try:
            self.local_nextstart()  # How to check whether this exists or not
        except AttributeError:
            pass

    def kill_orders(self):
        """ description """
        for num in range(0, len(self.datas)):
            self.datas[num].broker.cancel_all_orders(self.getdatas[0].symbol)

    def _get_last_trade(self, datas):
        last_trade = self.dbase.get_trades(
                ex_id=datas.feed.ex_id, symbol=datas.symbol, last=True)
        return last_trade

    def notify_trade(self, trade: bt.Trade):
        print("hice un trade: ", trade)
        exit()
        pass
