"""
description
"""
from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals)
from libs import log, cache
from libs.strategy.strategy import Strategy
from libs.structs.trade_struct import TradeStruct
from libs.database import Database
from typing import Dict, Optional
import backtrader as bt
import json
import arrow
from time import sleep

logger = log.fullon_logger(__name__)


class Strategy(Strategy):
    """
    Parent Strategy class that focuses on base methods for dry but live testing
    its a child a backtrader strategy, this is not a strategy that will trade,
    but rather additional methods that can be used by a strategy that actually trades..
    """

    last_update: Optional[arrow.Arrow] = None
    last_trade = None

    def nextstart(self):
        """This only runs once... before init... before pre_next()...
        before next() but only once"""
        super().nextstart()
        if self.nextstart_done is False:
            self._state_variables()
            for n in range(0, len(self.datas)):
                if self.datas[n].feed.trading:
                    self.update_simulated_cash_account(datas_num=n)
            self._save_status()
            self.nextstart_done = True
            try:
                self.local_nextstart()  # How to check whether this exists or not
            except AttributeError:
                pass
            return None

    def next(self) -> None:
        """
        The main method that runs on every iteration of the strategy.
        """
        # Check if data feed is live
        if not self.datas[0].islive():
            self.udpate_indicators_df()
            self.indicators_df = self.indicators_df.tail(self.params.bars + 1)
            #self.indicators_df.reset_index(drop=True, inplace=True)
            return

        self.status = "looping"
        self._state_variables()
        self._save_status()
        # Print position variables if verbose is enabled
        if self.verbose:
            self._print_position_variables(0)

        # Validate orders
        if not self._validate_orders():
            return self.end_next()

        self.udpate_indicators_df()

        if not self.indicators_df.empty:
            self.indicators_df = self.indicators_df.tail(self.params.bars + 1)
            self.indicators_df.reset_index(drop=True, inplace=True)

        # If there are no positions, call local_next, else call risk_management
        if self.anypos == 0:
            self.local_next()
        else:
            self.risk_management()
            self.end_next()

    def _validate_orders(self):
        """ description """
        self.orders = self.broker.get_orders_open()
        if self.orders or self.order_placed:
            self.order_placed = False
            sleep(0.00001)
            return False
        else:
            return True

    def entry(self, datas_num, price=None):
        cash = self.cash[datas_num] * (self.p.size_pct / 100) * self.p.leverage
        return cash / self.tick[datas_num]

    def kill_orders(self):
        """ description """
        orders = self.broker.get_orders_open(self.datas[0])
        for order in orders:
            self.broker.cancel(order)

    def notify_order(self, order):
        """ description """
        if order.status == 7:
            logger.error(
                "Trying to buy more than can be afforded, check your entry")

    def save_log(self, action: str, num: int) -> None:
        """ description """
        message = self._get_bot_vars(action=action, feed_num=num)
        if self.datas[num].feed.trading:
            with Database() as dbase:
                dbase.save_bot_log(
                    bot_id=self.helper.id, message=message, feed_num=num)
        return None

    def notify_trade(self, trade: bt.Trade) -> None:
        """
        Notifies when a trade is completed.
        Args:
            trade (bt.Trade): The trade object with trade information.
        """
        datas_num: int = int(trade.data._name)
        _trade = self._bt_trade_to_struct(trade)
        reason = "strategy"
        with Database() as store:
            store.save_dry_trade(
                bot_id=self.helper.id,
                trade=_trade,
                reason='strategy'
            )
        if self.p.take_profit:
            self.datas[datas_num].take_profit = self.take_profit[datas_num]
        if self.p.stop_loss:
            self.datas[datas_num].stop_loss = self.stop_loss[datas_num]
        if self.p.timeout:
            self.datas[datas_num].timeout = self.timeout[datas_num]
        if trade.justopened:
            self.datas[datas_num].pos = _trade.volume
            cash = self.cash[datas_num] - _trade.cost
        else:
            self.datas[datas_num].pos = 0
            cash = self.cash[datas_num] + _trade.cost
        self.broker.cash = cash

    def _bt_trade_to_struct(self, trade: bt.Trade) -> TradeStruct:
        """
        Convert a backtrader Trade object to a TradeStruct dictionary.

        Args:
            trade (bt.Trade): The backtrader Trade object.

        Returns:
            Dict: The TradeStruct dictionary containing trade information.
        """

        # Extract relevant data from the Trade object
        datas_num: int = int(trade.data._name)
        symbol: str = self.datas[datas_num].symbol
        ex_id: str = self.datas[datas_num].feed.ex_id

        # Create the initial trade dictionary
        trade_dict: Dict = {
            'uid': self.helper.uid,
            'ex_id': ex_id,
            'symbol': symbol,
            'side': 'Buy' if trade.size > 0 else 'Sell',
            'volume': abs(trade.size),
            'price': trade.price,
            'cost': abs(trade.value),
            'fee': trade.commission
        }
        trade_struct = TradeStruct.from_dict(trade_dict)

        if trade.justopened:
            self.prev_trade = trade_struct
        else:
            # Calculate ROI and ROI percentage
            prev_cost: float = self.prev_trade.cost
            pnlcomm: float = float(trade.pnlcomm)
            roi: float = pnlcomm - self.prev_trade.fee
            roi_pct: float = (roi / prev_cost) * 100

            # Update trade dictionary with ROI information
            trade_struct.fee = trade.commission
            trade_struct.volume = self.prev_trade.volume
            trade_struct.cost = self.prev_trade.volume * trade.price
            trade_struct.roi = roi
            trade_struct.roi_pct = roi_pct
            trade_struct.closingtrade = True
            self.prev_trade = None
        return trade_struct

    def udpate_indicators_df(self) -> None:
        """
        updates self.indicator_df with lastest self.datas[num].dataframe
        """
        for num, data in enumerate(self.datas):
            if data.timeframe != bt.TimeFrame.Ticks:
                if self._is_new_candle(num):
                    self.set_indicators_df()

    def set_indicators_df(self):
        """ description"""
        pass

    def _save_status(self) -> None:
        """
        Save the status of each data feed in the strategy based on the timeframe and
        trading status. This method distinguishes between live and simulation mode,
        calling the appropriate save status method accordingly.

        The method only executes once every minute to avoid flooding the cache with updates.

        Returns:
            None
        """
        # Get the current time
        current_time = arrow.utcnow()

        # If the last update happened less than a minute ago, skip this run
        if self.last_update is not None and (current_time - self.last_update).seconds < 60:
            return

        # Initialize an empty dictionary to store the status of each data feed
        datas_status = {}

        # Loop over all data feeds in the strategy
        for n in range(len(self.datas)):
            # If the data feed's timeframe is Ticks and trading is active
            if self.datas[n].timeframe == bt.TimeFrame.Ticks and self.datas[n].feed.trading:
                # Retrieve the simulated status for the current feed and store it in the dictionary
                datas_status[f"feed_{n}"] = self._get_bot_status(n)

        # Connect to the cache
        with cache.Cache() as mem:
            # Update the bot's status in the cache
            mem.update_bot(bot_id=self.helper.id, bot=datas_status)
            # Update the process in the cache
            mem.update_process(tipe="bot_status", key=self.helper.id, message="Updated")

        # Update the time of the last update
        self.last_update = current_time

    def _get_last_trade(self, datas):
        return self.last_trade

    def _get_bot_status(self, datas_num: int = 0) -> dict:
        """
        Gets the simulated status of the trading bot.

        This function captures the current state of the bot's simulated trading activity and saves it into a dictionary.
        The dictionary includes information such as the bot ID, exchange ID, the trading symbol, ROI, current funds,
        position, position price, and other details.

        Args:
            datas_num (int): The data index number. Defaults to 0.

        Returns:
            dict: A dictionary containing the simulated status of the bot.
        """
        # Get the data for the specified data index number
        datas = self.datas[datas_num]
        tick = self.datas[datas_num].close
        bot_id = self.helper.id

        # Initialize variables
        roi, roi_pct, pos_price = (0, 0, 0)

        if self.pos[datas_num] != 0:
            last_trade = self._get_last_trade(datas=datas)
            orig_value = last_trade.cost if last_trade else 0
            pos_price = last_trade.price if last_trade else 0
            cur_value = self.pos[datas_num] * tick
            if self.pos[datas_num] < 0:
                cur_value *= -1
            if last_trade:
                roi = float(cur_value) - float(orig_value)
                if orig_value != 0:
                    roi_pct = (roi / float(orig_value)) * 100
                    roi_pct = round(roi_pct, 2)

        params = vars(self.params).copy()
        params.pop("helper", None)
        params = json.dumps(params, indent=4, sort_keys=True)

        is_live = "Yes" if __name__ == 'live_strategy' else "No"

        bot = {
            "bot_id": bot_id,
            "ex_id": datas.feed.ex_id,
            "bot_name": self.helper.bot_name,
            "symbol": datas.symbol,
            "exchange": datas.feed.exchange_name,
            "tick": self.tick[datas_num],
            "roi": roi,
            "cash": self.cash[datas_num],
            "free_funds": self.totalfunds[datas_num],
            "pos": self.pos[datas_num],
            "pos_price": pos_price,
            "roi_pct": roi_pct,
            "orders": "",
            "live": is_live,
            "strategy": self.helper.strategy,
            "base": datas.feed.base,
            "params": params,
            "variables": self._get_bot_vars(feed_num=datas_num)
        }
        return bot

    def update_simulated_cash_account(self, datas_num: int) -> None:
        """
        The purpose of this method is to simulate live trading using Backtrader's broker instead of a real exchange.

        This method is run once, from nextstart. It picks up the last trade, and if it is not a closing trade,
        it registers a closing date with current data and opens a new Backtrader broker trade. This is useful in case of a bot reboot.

        Args:
            datas_num (int): The index of the data feed to update.
        """
        # Get the last dry trade from the database
        with Database() as dbase:
            last_trade = dbase.get_last_dry_trade(
                bot_id=self.helper.id,
                symbol=self.datas[datas_num].symbol,
                ex_id=self.datas[datas_num].feed.ex_id
            )

        # If the last trade is not a closing trade, continue

        try:
            if last_trade.closingtrade:
                return
        except AttributeError:
            return

        with cache.Cache() as mem:
            price = float(mem.get_price(
                symbol=self.datas[datas_num].symbol,
                exchange=self.datas[datas_num].feed.exchange_name
            ))

        value = price * float(last_trade.volume)
        fee = last_trade.fee if last_trade.fee else 0

        # If it's a long position
        if last_trade.side == "Buy":
            side = "Sell"
            roi = value - (float(last_trade.cost) + fee * 2)
        # If it's a short position
        elif last_trade.side == "Sell":
            side = "Buy"
            roi = float(last_trade.cost) - (value + fee * 2)

        trade = {
            "uid": self.helper.uid,
            "ex_id": self.datas[datas_num].feed.ex_id,
            "symbol": self.datas[datas_num].symbol,
            "side": side,
            "price": price,
            "volume": last_trade.volume,
            "cost": value,
            "fee": fee,
            "order_type": "Limit",
            "roi": roi,
            "roi_pct": (roi / last_trade.cost) * 100,
            "reason": "botreboot",
            "closingtrade": True
        }
        trade = TradeStruct.from_dict(trade)

        with Database() as dbase:
            dbase.save_dry_trade(bot_id=self.helper.id, trade=trade, reason='botreboot')

        open_data = {
            "side": last_trade.side,
            "price": price,
            "amount": last_trade.volume,
            "timestamp": last_trade.timestamp
        }

        cash = self.broker.get_cash()
        with Database() as dbase:
            pnl = float(dbase.get_dry_margin(bot_id=self.helper.id))
        self.broker.cash = cash+pnl
