import pandas as pd
from backtrader.feed import DataBase


class FullonFeedResampler:
    """ this class can prepare DataBase resampled feed to add mehtods aparameters """

    _data: DataBase
    bars: int

    def prepare(self, data: DataBase,
                bars: int, timeframe: int, compression: int) -> DataBase:
        """
        Prepares the data feed by adding necessary attributes and methods.

        :param data: The data feed to prepare.
        :return: The prepared data feed.
        """
        self._data = data
        self._bars = bars

        # Define the DataFrame columns
        columns = {0: "date", 1: "open", 2: "high", 3: "low", 4: "close", 5: "volume"}
        dataframe = pd.DataFrame(columns=columns.values())

        # Set the index to the 'date' column
        dataframe.set_index("date", inplace=True)

        # set time frame and period in case is needed
        setattr(data, 'timeframe', timeframe)
        setattr(data, 'compression', compression)

        # Set the dataframe and append_row method as attributes of the data feed
        setattr(data, 'dataframe', dataframe)
        setattr(data, 'append_row', self.append_row.__get__(data))

        # Wrap the originalnext method and set the wrapped version as an attribute of data
        original_next = data.next
        setattr(data, 'next', self._custom_next(original_next))
        return data

    def append_row(self) -> None:
        """
        Appends the current data line to the internal DataFrame.
        """
        data = self._data
        datas = {
            "date": data.datetime.datetime(),
            "open": data.open[0],
            "high": data.high[0],
            "low": data.low[0],
            "close": data.close[0],
            "volume": data.volume[0],
        }
        row = pd.DataFrame([datas])
        row.set_index("date", inplace=True)
        data.dataframe = pd.concat([data.dataframe, row])
        if len(data.dataframe) >= self._bars:
            data.dataframe.drop(data.dataframe.index[0], inplace=True)

    def _custom_next(self, original_next):
        """
        Wraps the original _next method to call append_row before returning its result.

        :param original_next: The original _load method of the data feed.
        :return: The wrapped _load method.
        """
        def wrapper(*args, **kwargs):
            result = original_next()
            if result:
                self.append_row()
            return result
        return wrapper
