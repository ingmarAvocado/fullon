from libs.models import bot_model as database
from libs import log

logger = log.fullon_logger(__name__)


class Database(database.Database):

    def get_last_action(self):
        return None
        values=""
        try:
            cur=self.con.cursor()
            sql = 'select * from memory ORDER BY rowid DESC limit 1'
            #print (sql)
            cur.execute(sql)
            values=cur.fetchone()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            error="Error cant get_last_action, postgres says: " +str(error)
            logger.info(error)
            sys.exit()          
        finally:
            return values

    def register_action(self,function,action,epoch=""):
        return None
        values=""
        if self.simul:
            return None
        try:
            cur=self.con.cursor()
            if epoch=="":
                epoch=int(time.time())
            sql='INSERT INTO MEMORY VALUES("%d","%s","%s")' %(epoch,function,action)
            cur.execute(sql)
            self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            error="Error cant register_action, postgres says: " +str(error)
            logger.info(error)
            sys.exit()              
