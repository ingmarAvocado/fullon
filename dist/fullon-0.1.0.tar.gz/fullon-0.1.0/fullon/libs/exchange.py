from typing import Any, Dict, Callable, Optional
from multiprocessing import Process, Manager
from queue import Queue
from libs.cache import Cache
from libs.exchange_methods import ExchangeMethods
from libs import log, settings, database
from libs.structs.exchange_struct import ExchangeStruct
from time import sleep
from run import user_manager

logger = log.fullon_logger(__name__)

request_queues: Dict = {}
response_queues: Dict = {}
processes: Dict = {}

SENTINEL: Dict = {}
NOQUEUE_POOL: Dict = {}
UID: str = ''

if not UID:
    user = user_manager.UserManager()
    UID = user.get_user_id(mail=settings.ADMIN_MAIL)
    if UID:
        with database.Database() as dbase:
            try:
                PARAMS = dbase.get_exchange(user_id=UID)[0]
            except IndexError:
                PARAMS = []
    else:
        PARAMS = ExchangeStruct()
    del user


class WorkerError(Exception):
    """Custom error to be raised when an error occurs in the worker thread."""


def stop_exchange(exchange_pool):
    uids = list(exchange_pool.keys())
    for uid in uids:
        del exchange_pool[uid]
        sleep(1)


def process_requests(request_queue: Queue,
                     response_queue: Queue) -> None:
    """
    Process requests in a separate thread.

    Args:
        request_queue (Queue): Queue for incoming requests.
        response_queue (Queue): Queue for outgoing responses.
    """
    exchange_pool = {}
    while True:
        try:
            try:
                request = request_queue.get()
            except (BrokenPipeError, EOFError) as error:
                stop_exchange(exchange_pool)
                break

            if request == "StopThisRun":
                stop_exchange(exchange_pool)
                break

            exchange, uid, params, method_name, method_params = request
            try:
                _ = exchange_pool[uid]
            except (AttributeError, KeyError):
                exchange_pool[uid] = ExchangeMethods(
                                            exchange=exchange,
                                            params=params)

            # Perform the requested method with the Exchange object
            class_method = getattr(exchange_pool[uid], method_name)
            result = class_method(**method_params)
            response_queue.put(result)

            # Sleep for the specified time returned by get_sleep()
            if method_name not in exchange_pool[uid].no_sleep():
                logger.debug("Sleeping for: ", method_name)
                sleep(exchange_pool[uid].get_sleep())

        except KeyboardInterrupt:
            pass
        '''
        except Exception as error:
            error = f"{str(error)}  {method_name}  {str(params)}"
            response_queue.put((SENTINEL, str(error)))
            del exchange_pool[uid]
            exchange_pool[uid] = ExchangeMethods(
                exchange=exchange, params=params)
        '''


def start(exchange: str) -> None:
    """Start the process for processing requests."""
    global response_queues, request_queues, processes
    logger.info(f"Starting Exchange Queue Manager for {exchange}")
    m = Manager()
    response_queues[exchange] = m.Queue()
    request_queues[exchange] = m.Queue()
    processes[exchange] = Process(
        target=process_requests,
        args=(request_queues[exchange], response_queues[exchange]))
    processes[exchange].start()


def stop(exchange: str) -> None:
    """Stop the process for processing requests."""
    global response_queues, request_queues, processes
    try:
        logger.info(f"Stopping Exchange Queue Manager for {exchange}")
        request_queues[exchange].put('StopThisRun')
        sleep(1)
        processes[exchange].join(timeout=1)
        del processes[exchange]
    except KeyError:
        pass


def stop_all():
    with Cache() as store:
        exchanges = store.get_cat_exchanges()
    for exchange in exchanges:
        stop(exchange['name'])


def start_all():
    with Cache() as store:
        exchanges = store.get_cat_exchanges()
    for exchange in exchanges:
        start(exchange['name'])


class Exchange:
    def __init__(self,
                 exchange: str,
                 params: Optional[ExchangeStruct] = None,
                 dry_run: bool = False):
        """
        Initialize the Exchange object.

        Args:
            exchange (str): Exchange name.
            params (Dict[str, Any], optional): Parameters for the exchange. Defaults to {}.
            dry_run (bool, optional): If True, enables dry run mode. Defaults to False.
        """
        self.dry_run = dry_run
        self.exchange = exchange
        self.params = params if params else PARAMS
        self.uid = self.params.uid
        self.ex_id = self.params.ex_id

    def __del__(self):
        global NOQUEUE_POOL
        if self.exchange in NOQUEUE_POOL:
            del NOQUEUE_POOL[self.exchange]

    def __getattr__(self, attr: str) -> Callable[..., Any]:
        """
        Provide a default implementation for any missing methods.

        Args:
            attr (str): Attribute name (method name).

        Returns:
            Callable[..., Any]: Default implementation of the missing method.
        """

        def default(**params: Dict[str, Any]) -> Any:
            return self._run_default(attr, params)

        return default

    def _run_default(self, attr: str, params: Dict[str, Any]) -> Any:
        """
        Run the default implementation of a missing method.

        Args:
            attr (str): Attribute name (method name).
            params (Dict[str, Any]): Parameters for the missing method.

        Returns:
            Any: Result of the method execution.
        """
        global request_queues, response_queues
        try:
            request_queues[self.exchange].put((self.exchange,
                                               self.uid,
                                               self.params,
                                               attr,
                                               params))
        except KeyError as error:
            raise WorkerError("Exchange queue not working") from error

        # Wait for the result using the blocking get() method
        result = response_queues[self.exchange].get()
        if isinstance(result, tuple) and result[0] == SENTINEL:
            raise WorkerError(f"Error in worker process: {result[1]}")
        return result

    def _run_default_no_queue(self, attr: str, params: Dict[str, Any]) -> Any:
        """
        Run the default implementation of a missing method.

        Args:
            attr (str): Attribute name (method name).
            params (Dict[str, Any]): Parameters for the missing method.

        Returns:
            Any: Result of the method execution.
        """
        global NOQUEUE_POOL
        if self.exchange not in NOQUEUE_POOL:
            exch = ExchangeMethods(
                exchange=self.exchange, params=self.params)
            NOQUEUE_POOL[self.exchange] = exch
        method = getattr(NOQUEUE_POOL[self.exchange], attr)
        return (method(**params))
