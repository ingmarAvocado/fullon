#!/usr/bin/python3
"""
Fullon Installer Script

This script is responsible for setting up the necessary infrastructure for Fullon application.
It sets up databases, installs necessary SQL schemas, prepares cache and performs installations
of strategies, exchanges and optionally, a demo.

Usage:
    python install_fullon.py [--demo]

Optional flags:
    -d, --demo: Install a demo
"""

from typing import NoReturn
import argparse

from libs import log, settings
from libs.settings_config import fullon_settings_loader  # pylint: disable=unused-import
from libs.models.install_model import Database as Database_Install
from libs.models.ohlcv_model import Database as Database_ohlcv
from libs.cache import Cache
from run.install_manager import InstallManager

logger = log.fullon_logger(__name__)


def install_fullon(cli_args: argparse.Namespace) -> NoReturn:
    """
    Handles Fullon installation process

    Parameters:
    cli_args (argparse.Namespace): Command line arguments

    Returns:
    None
    """

    # Initialize the InstallManager and run necessary pre-install checks and installation tasks
    with Database_Install() as dbase:
        dbase.clean_base()  # Clean base tables
        dbase.install_base_sql()  # Install base SQL
        dbase.install_ohlcv()  # Install OHLCV
    logger.info("Databases and tables have been installed")

    # Setup database for OHLCV
    with Database_ohlcv(exchange='exchange', symbol='symbol') as dbase:
        dbase.install_timescale()  # Install timescale
        dbase.install_timescale_tools()  # Install timescale tools

    # Initialize Install Manager
    install = InstallManager()
    install.install_cache()  # Install cache

    logger.info("Let's install the basic SQL schema")

    # Install strategies and exchanges
    install.install_strategies()
    install.install_exchanges()
    install.install_cache()
    # Prepare the cache
    with Cache() as store:
        store.prepare_cache()
    logger.info("Installed")

    # If the demo flag was set, install the demo
    if cli_args.demo:
        install.install_demo()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Fullon Installer Help Page")
    parser.add_argument("-d", "--demo", action="store_true", help="Install demo data")
    args = parser.parse_args()
    install_fullon(args)
    logger.info("Done :)")
