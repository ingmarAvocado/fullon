#!/usr/bin/python3
"""
rpcdaemon_manager
"""
from __future__ import unicode_literals, print_function
import sys
import os
import time
import json
import decimal
from concurrent.futures import ThreadPoolExecutor, as_completed
from xmlrpc.server import SimpleXMLRPCServer, SimpleXMLRPCRequestHandler
import psutil
import numpy
from setproctitle import setproctitle  # pylint: disable=no-name-in-module
from libs import settings, log, simul
from run import system_manager
from typing import List, Optional

logger = log.fullon_logger(__name__)

handler: dict = {}
handler['tick'] = system_manager.TickManager()
handler['ohlcv'] = system_manager.OhlcvManager()
handler['account'] = system_manager.AccountManager()
handler['bot'] = system_manager.BotManager()


# Restrict to a particular path.
class RequestHandler(SimpleXMLRPCRequestHandler):
    """ class """
    rpc_paths = ('/RPC2',)


def daemon_startup():
    """ description """
    if find_another_daemon():
        logger.warning("Another daemon is running, can't run until its off")
        sys.exit()
    setproctitle("Fullon Trading Daemon")
    install = system_manager.InstallManager()
    install.install_exchanges()
    install.install_cache()
    del install
    logger.info("Cache component ready")
    return True


def rpc_test():
    """ description """
    return "fullon"


def stop_component(component: str) -> str:
    """ description """
    response = ""
    match component:
        case "tick":
            handler['tick'].stop_all()
            response = "Tick stopped"
        case "ohlcv":
            handler['ohlcv'].stop_all()
            response = "ohlcv stopped"
        case "account":
            handler['account'].stop_all()
            response = "ohlcv stopped"
        case "bot":
            handler['bot'].stop_all()
            del handler['bot']
            handler['bot'] = system_manager.BotManager()
            response = "bot stopped"
    return response


def component_on(component):
    """ description """
    match component:
        case "tick":
            if handler['tick'].started:
                return True
        case "ohlcv":
            if handler['ohlcv'].started:
                return True
        case "account":
            if handler['account'].started:
                return True
        case "bot":
            if handler['bot'].started:
                return True
    return False


def install_symbols():
    """ description """
    install = system_manager.InstallManager()
    install.install_symbols()
    del install
    return "Symbols Installed"


def list_symbols():
    """ description """
    install = system_manager.InstallManager()
    return install.list_symbols()


def install_symbol(symbol):
    """ description """
    install = system_manager.InstallManager()
    install.install_symbol(symbol)
    del install
    return "Symbol Installed"


def exchanges_list():
    """ description """
    install = system_manager.InstallManager()
    return install.list_exchanges()


def strategy_view(str_id):
    """ description """
    # iam  = user_manager.UserManager()
    return f"Not done ({str_id})"  # am.list_user_strats(str_id=str_id)


def strategy_add(strategy):
    """ description """
    user = system_manager.UserManager()
    done = user.add_strategy(strategy=strategy)
    if done:
        return "Strategy added"
    return "Strategy not Added"


def btc_ticker():
    """ description """
    start_tickers()
    return handler['tick'].btc_ticker()


def start_tickers():
    """ description """
    if not component_on('tick'):
        # this will launch the update ticker subprocess
        missing = pre_check(['tick'])
        if 'tick' in missing:
            handler['tick'].run_loop()
            return "Ticker Launched"
    return "Ticker already running"


def start_ohlcv():
    """ description """
    if not component_on('ohlcv'):
        # This will launch the update OHLCV tables process
        missing = pre_check(['ohlcv'])
        if 'ohlcv' in missing:
            handler['ohlcv'].run_loop()
            return "OHLCV started"
    return "OHLCV already running"


def start_trades(test=False):
    """ description """
    if not component_on('tick'):
        # this will launch the update accounts subprocess
        missing = pre_check(['trades'])
        if 'trades' in missing:
            trade_manager = system_manager.TradeManager()
            trade_manager.run_loop(test=test)
            return "Trade manager launched"
    return "Trade Manager already running"


def start_accounts():
    """ description """
    if not component_on('account'):
        missing = pre_check(['tick', 'account'])
        if 'tick' in missing:
            logger.info(start_tickers())
        if 'account' in missing:
            handler['account'].run_account_loop()
            return "Accounts launched"
    return "Accounts already running"


def start_bots():
    """ description """
    if not component_on('bot'):
        start_services()
        handler['bot'].run_bot_loop(daemon=True)
        return "Bots launched"
    return "Bots already running"


def bot_test(bot_id):
    """ description """
    if not component_on('bot'):
        services_started = check_services()
        if not services_started:
            logger.warning("Services are off, please start them")
            return False
        handler['bot'].start_bot(bot_id=bot_id, test=True)
        # if not services_started:
        #     stop_services()
        test_result = True
    else:
        test_result = False
    return test_result


def user_list():
    """ description """
    user = system_manager.UserManager()
    return user.list_users()


def user_details(uid):
    """ description """
    user = system_manager.UserManager()
    return json.dumps(user.user_details(uid))


def strategies_list():
    """ description """
    install = system_manager.InstallManager()
    return install.list_cat_strategies()


def user_strategies_list(uid):
    """ description """
    install = system_manager.InstallManager()
    return "\n" + install.list_user_strategies(uid=uid)


def strategies_list_params(str_id):
    """ description """
    # install=system_manager.InstallManager()
    # return "\n"+install.list_cat_strategies_params(str_id)
    return f"Not yet Implemented {str_id}"


def bot_add(bot):
    """ description """
    return f"Not done {bot}"
    # return handler['bot'].add(bot=bot)


def bots_list():
    """ description """
    return handler['bot'].bots_list()


def dry_reset(bot_id):
    """ description """
    handler['bot'].dry_delete(bot_id=bot_id)
    return "Dry reset done"


def bot_edit(bot):
    """ description """
    if 'bot_id' not in bot.keys():
        logger.error("Cant continue no bot_id in bot_edit()")
        return "Bot not edited"
    bot = handler['bot'].edit(bot=bot)
    if bot:
        ret_value = "Bot edited"
    else:
        ret_value = "Bot not edited"
    return ret_value


def get_simul_comas(simuls, key, value):
    """ description """
    if not simuls:
        for child_val in value.split(','):
            try:
                simuls.append({key: float(child_val)})
            except ValueError:
                return [f'ERROR malformatted string 1 ({value}) \
                por parameter {key}']
    else:
        simuls_tmp = []
        for sim in simuls:
            for child_val in value.split(','):
                params = {}
                params.update(sim)
                try:
                    params.update({key: float(child_val)})
                except ValueError:
                    return [f'ERROR malformatted string 2({value})\
                    for parameter {key}']
                simuls_tmp.append(params)
        simuls = simuls_tmp
    return simuls


def get_simul_dash_range(low: str, high: str) -> list:
    """
    Returns a list of values between low and high, with a step size that
    depends on the number of decimal places in the input
    """
    try:
        low = decimal.Decimal(low)
        high = decimal.Decimal(high)
        decimals = abs(low.as_tuple().exponent)
        if decimals == 0:
            low = int(low)
            high = int(high) + 1
            if low < 0 and high < 0:
                low = abs(low)
                high = abs(high)
                val = range(low, high)
                val = [-x for x in val]
            else:
                val = range(low, high)
        else:
            if low < 0 and high < 0:
                low = -low
                high = -high
                range_diff = high - low
                num_points = int((range_diff * (10 ** decimals)))
                val = [
                    round(
                        float(x),
                        decimals) for x in numpy.linspace(
                        float(low),
                        float(high),
                        num=num_points)]
                val = [-x for x in val]
            else:
                range_diff = high - low
                num_points = int((range_diff * (10 ** decimals)))
                val = [
                    round(
                        float(x),
                        decimals) for x in numpy.linspace(
                        float(low),
                        float(high),
                        num=num_points)]
    except decimal.InvalidOperation as error:
        raise ValueError("Invalid input, low and high must be valid numbers") from error
    return list(val)


def get_simul_dash(simuls, key, value):
    """ description """
    try:
        low = value.split(':')[0]
        high = value.split(':')[1]
    except ValueError:
        return [f'ERROR malformatted string 2 ({value})\
        for parameter {key}']
    try:
        val = get_simul_dash_range(low, high)
    except ValueError as error:
        return [f'ERROR ({str(error)}) for parameter {key}']
    if len(val) == 0:
        return [f'ERROR malformatted string 3 (low, high order) ({value}) for parameter {key}']
    if not simuls:
        for child_val in val:
            try:
                simuls.append({key: float(child_val)})
            except ValueError:
                return [f'ERROR malformatted string  5 ({value}) for parameter {key}']
    else:
        simuls_tmp = []
        for sim in simuls:
            for child_val in val:
                params = {}
                params.update(sim)
                try:
                    params.update({key: float(child_val)})
                except ValueError:
                    return [f'ERROR malformatted string6 ({value}) for parameter {key}']
                simuls_tmp.append(params)
        simuls = simuls_tmp
    return simuls


def get_simul_param(simuls: list, key: str, value) -> list:
    """
    This function takes a list of simulations, a key and a value and
    updates the key-value pair of the simulations in the list.
    If the key is one of take_profit, stop_loss, trailing_stop, rolling_stop, timeout,
    the value is casted to float, otherwise it is left as is.
    :param simuls: list of dictionaries representing simulations
    :param key: key to update in the simulation dictionary
    :param value: value to update the key with
    :return: the updated list of simulation dictionaries
    """
    if not simuls:
        if key in {"take_profit", "stop_loss", "trailing_stop", "rolling_stop", "timeout"}:
            try:
                value = float(value)
            except ValueError as error:
                raise ValueError(
                    f"The value for parameter {key} must be a number but it is {value}") from error
        simuls.append({key: value})
    else:
        simuls_tmp = []
        for sim in simuls:
            params = {}
            params.update(sim)
            if key in {"take_profit", "stop_loss", "trailing_stop", "rolling_stop", "timeout"}:
                try:
                    value = float(value)
                except ValueError as error:
                    raise ValueError(
                        f"The value for parameter {key} must be a number but it is {value}\
                        could be that your using - intead of : for range?") from error
            params.update({key: value})
            simuls_tmp.append(params)
        simuls = simuls_tmp
    return simuls


def get_simul_list(simul_params: dict) -> list:
    """
    This function receives a dictionary of simulation parameters and returns a list of simulations.
    Each simulation is a dictionary containing key-value pairs of the simulation parameters.
    The function handles input parameters with commas, colons, and single values.
    """
    simuls = []
    for key, value in simul_params.items():
        if ',' in str(value):
            simuls = get_simul_comas(simuls=simuls, key=key, value=value)
            if simuls:
                if 'ERROR' in simuls[0]:
                    return [simuls[0]]
        elif ':' in value:
            simuls = get_simul_dash(simuls=simuls, key=key, value=value)
            if simuls:
                if 'ERROR' in simuls[0]:
                    return [simuls[0]]
        else:
            simuls = get_simul_param(simuls=simuls, key=key, value=value)
            if simuls:
                if 'ERROR' in simuls[0]:
                    return [simuls[0]]
    return simuls


def bot_simul(bot, event_based=False, feeds: dict = {}, params=None) -> None:
    """
    This function runs a simulation for a given bot. If 'params' is provided,it
    will run the simulation with the provided parameters. If 'params' is not
    provided, it will run the simulation with the default parameters.
    If bot['params'] is provided, it will launch several simulations
    in parallel using threading.

    Args:
        bot (dict): A dictionary containing the bot's configuration and settings.
        event_based (bool, optional): Indicating whether to run an event simulation or a regular simulation.
        feeds (dict, optional): Any additional feeds to be provided to the bot.
        params (optional): A dictionary containing additional parameters for the simulation.
    """
    try:
        if bot['params']:
            sim_list = get_simul_list(bot['params'])
            '''
            with ThreadPoolExecutor(max_workers=4) as executor:
                futures = [executor.submit(run_simul, bot=bot, event=event_based, feeds=feeds, params=sim_param)
                           for sim_param in sim_list]
                for future in as_completed(futures):
                    result = future.result()
                    # process result as necessary
            '''
            for sim_params in sim_list:
                result = run_simul(bot=bot, event=event_based, feeds=feeds, params=sim_params)
        else:
            result = run_simul(bot=bot, event=event_based, feeds=feeds, params=params)
            # process result as necessary
    except KeyError:
        result = run_simul(bot=bot, event=event_based, feeds=feeds, params=params)
        # process result as necessary


def run_simul(bot, event=False, feeds={}, params=None) -> list:
    """
    This function runs a simulation based on the provided bot and simulation parameters. This function is designed
    to be used in a threading context.

    Args:
        bot (dict): A dictionary containing the bot's configuration and settings.
        event (bool, optional): A boolean indicating whether to run an event simulation or a regular simulation.
        feeds (dict, optional): Any additional feeds to be provided to the bot.
        params (optional): A dictionary containing additional parameters for the simulation.

    Returns:
        list: The results of the simulation, parsed according to the bot's configuration.
    """
    if params:
        if 'ERROR' in params:
            logger.error(params)
            return params
    periods = 365
    visual = None
    warm_up = False
    # Extract simulation parameters from bot dictionary
    if 'periods' in bot.keys():
        periods = int(bot['periods'])
    if 'visual' in bot.keys():
        visual = bot['visual']
    if 'warm_up' in bot.keys():
        warm_up = bot['warm_up']
    # Check that a bot_id is included in bot dictionary
    if 'bot_id' not in bot.keys():
        return "Cant continue, no bot_id included in bot array"
    # Launch simulation
    results = handler['bot'].launch_simul(bot_id=bot['bot_id'],
                                          periods=periods,
                                          visual=visual,
                                          warm_up=warm_up,
                                          event=event,
                                          feeds=feeds,
                                          test_params=params)
    if results:
        # Create an instance of simul
        sim = simul.simul()
        # Parse simulation results according to bot's configuration
        results = sim.parse(results=results, bot=bot)
        # Clean up by deleting sim instance
        del sim
    return results


def start_full():
    """ description """
    missing = pre_check(['tick', 'ohlcv', 'account', 'bots'])
    if 'tick' in missing:
        logger.info(start_tickers())
    if 'ohlcv' in missing:
        logger.info(start_ohlcv())
    if 'accounts' in missing:
        logger.info(start_accounts())
    if 'bot' in missing:
        logger.info(start_bots())
    return "Full services started"


def stop_full():
    """ description """
    stop_component(component='bot')
    stop_component(component='account')
    stop_component(component='ohlcv')
    stop_component(component='tick')
    return "Full services stopped"


def check_services():
    """ description """
    missing = pre_check(['tick', 'ohlcv', 'account'])
    if missing:
        result = False
    else:
        result = True
    return result


def start_services():
    """ description """
    missing = pre_check(['tick', 'ohlcv', 'account'])
    # print("missing",missing)
    if 'tick' in missing:
        logger.info(start_tickers())
    if 'ohlcv' in missing:
        logger.info(start_ohlcv())
    if 'account' in missing:
        logger.info(start_accounts())
    return "Services started"


def stop_services():
    """ description """
    stop_component(component='tick')
    stop_component(component='ohlcv')
    stop_component(component='account')
    return "Services stopped"


def pre_check(services: Optional[List[str]] = None) -> List[str]:
    """Returns the symmetric difference between the specified services and
    the currently running services.

    Args:
        services (list of str, optional): A list of service names to check.
        Defaults to None.

    Returns:
        list of str: A list of services that are not currently
        running or are running but should not be.
    """
    if not services:
        return []
    pre = system_manager.InstallManager()
    running = pre.get_running_services()
    return list(set(services) ^ set(running))


def backup_recover(name=None):
    """ description """
    stop_full()
    backup = system_manager.InstallManager()
    backup.clean_base()
    backup.install_base()
    backup.recover_backup(name=name)
    return "Backup recovered - Pls restart services manually"


def backup_create(name=None, full=None, mini=None):
    """ description """
    backup = system_manager.InstallManager()
    backup.make_backup(name=name, full=full, mini=mini)
    return "Backup created"


def backup_create_full():
    """ description """
    backup = system_manager.InstallManager()
    backup.make_backup(name=None, full=True, mini=False)
    return "Full backup created"


def backup_create_mini():
    """ description """
    backup = system_manager.InstallManager()
    backup.make_backup(name=None, full=None, mini=True)
    return "Mini backup created"


def backup_list():
    """ description """
    backup = system_manager.InstallManager()
    backups = backup.list_backups()
    return backups


def fix_dry_trades():
    """ description """
    fixes = system_manager.InstallManager()
    fixes.correct_dry_trades()
    return "fixed dry trades completed (obsolete)"


def get_proc_overview():
    """ description """
    memory = 0
    ptime = 0.0
    count = 0
    my_pid = os.getpid()
    for proc in psutil.process_iter(['pid', 'name']):
        if 'FULLON' in proc.name().upper():
            if proc.pid != my_pid:
                if proc.status() != "zombie":
                    # proc.memory_info()
                    memory += proc.memory_info().data
                    count += 1
    memory = round(memory / 1024 / 1024 / 1024, 2)
    ptime = psutil.cpu_percent()
    vmem = psutil.virtual_memory()
    total = round(vmem.total / 1024 / 1024 / 1024, 2)
    free = round(vmem.free / 1024 / 1024 / 1024, 2)
    percent = vmem.percent
    ret = {"rss": memory,
           "free": free,
           "total": total,
           "percent": percent,
           "time": ptime,
           "count": count}
    return ret


def find_another_daemon():
    """ description """
    for proc in psutil.process_iter(['pid', 'name', 'username']):
        if 'Fullon Trading Daemon' in proc.name():
            if os.getuid() == proc.uids().real:
                return True
    return False


def shutdown(message: str = "") -> None:
    """Shut down the daemon and log a message if provided."""
    logger.info("Daemon has been shut down")
    if message:
        logger.info(message)
    sys.exit()


def pre_rpc_server(full, services, stop_event):
    """ description """
    daemon_startup()
    which_startup(full, services)
    rpc_server(logs=False, stop_event=stop_event)
    stop_full()


def which_startup(full, services):
    """ description """
    if full:
        logger.info("Full components startup initiated")
        start_full()
        logger.info("Full components startup completed")
        return None
    if services:
        logger.info("Services component startup initiated")
        start_services()
        logger.info("Services component startup completed")
        return None
    return None


def rpc_server(stop_event, logs=True):
    """ description """
    with SimpleXMLRPCServer((settings.XMLRPC_HOST, settings.XMLRPC_PORT),
                            logRequests=logs,
                            requestHandler=RequestHandler,
                            allow_none=True) as server:
        server.register_introspection_functions()
        server.register_function(user_list)
        server.register_function(user_details)
        server.register_function(start_tickers)
        server.register_function(start_accounts)
        server.register_function(start_full)
        server.register_function(stop_full)
        server.register_function(fix_dry_trades)
        server.register_function(backup_recover)
        server.register_function(backup_create)
        server.register_function(backup_create_full)
        server.register_function(backup_create_mini)
        server.register_function(backup_list)
        server.register_function(start_ohlcv)
        server.register_function(start_trades)
        server.register_function(start_services)
        server.register_function(stop_services)
        server.register_function(install_symbols)
        server.register_function(install_symbol)
        server.register_function(list_symbols)
        server.register_function(strategies_list)
        server.register_function(strategies_list_params)
        server.register_function(strategy_add)
        server.register_function(strategy_view)
        server.register_function(strategies_list)
        server.register_function(user_strategies_list)
        server.register_function(exchanges_list)
        server.register_function(rpc_test)
        server.register_function(bots_list)
        server.register_function(start_bots)
        server.register_function(bot_add)
        server.register_function(bot_edit)
        server.register_function(bot_simul)
        server.register_function(dry_reset)
        server.register_function(get_proc_overview)
        server.register_function(btc_ticker)
        server.register_function(bot_test)
        logger.info("Fullon Daemon Starting")
        server.timeout = 0.5
        while not stop_event.is_set():
            server.handle_request()
        logger.info("Fullon Daemon Stopped")
