"""
Dictionary with all public methos available.
"""


def get_components():
    """ description """
    components = {'account': ['start', 'stop'],
                  'backup': ['recover', 'create', 'create_full', 'create_mini', 'list'],
                  'bots': ['list', 'add', 'start', 'stop', 'simul', 'disable', 'test', 'dry_run'],
                  'cat_exchanges': ['list'],
                  'cat_strategies': ['list', 'params'],
                  'exchange': ['list', 'add', 'edit', 'delete'],
                  'fixes': ['dry_trades'],
                  'full': ['start', 'stop'],
                  'ohlcv': ['start', 'stop'],
                  'order': ['start', 'stop'],
                  'services': ['start', 'stop'],
                  'setup': ['install'],
                  'strategies': ['list', 'list_user', 'add', 'edit', 'delete'],
                  'symbols': ['list', 'add', 'update'],
                  'tick': ['start', 'stop'],
                  'trades': ['start', 'stop'],
                  'top': [],
                  'help': [],
                  'kill': ['pid'],
                  'user': ['add', 'list', 'edit', 'details', 'delete'],
                  }
    return components
