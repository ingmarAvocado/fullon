"""
Process manager
"""

import time
import xmlrpc.client
from setproctitle import setproctitle
from libs import settings, cache, log
import json


logger = log.fullon_logger(__name__)


class ProcessManager():
    """ description """

    def __init__(self):
        """ description """
        self.rpc = xmlrpc.client.ServerProxy(
            f'http://{settings.XMLRPC_HOST}:{settings.XMLRPC_PORT}')
        self.cache = ""

    def start(self):
        """ description """
        setproctitle("Fullon Process Monitor Component")
        self.monitor()

    def start_monitor(self):
        """ description """
        return self.start()

    def killpid(self, pid):
        """ description """
        self.rpc.kill_pid(pid)

    def correct_top_table(self):
        """ description """
        top = self.cache.get_top()
        for proc in top:
            if not self.rpc.is_child_process(proc.pid):
                self.cache.delete_from_top(pid=proc.pid)
        return True

    def monitor(self):
        """ description """
        while True:
            self.cache = cache.Cache()
            components = {'tick': 120,
                          'account': 120,
                          'ohlcv': 120,
                          'order': 300,
                          'bot': 2000
                          }
            for comp, time_c in components.items():
                top = self.cache.get_top(deltatime=time_c, comp=comp)
                for proc in top:
                    self.killpid(proc.pid)
                    logger.info(
                        "Launching component %s proc.key %s params %s",
                        comp, proc.key, proc.params)
                    self.rpc.launch_proc(
                        comp,
                        proc.key,
                        json.dumps(proc.params))
            del self.cache
            time.sleep(5)
