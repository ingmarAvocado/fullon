"""
Manages the tick data for multiple exchanges.
"""
from __future__ import annotations
from typing import Any, Dict, List
import threading
import time
import arrow
from libs import exchange, log
from libs.cache import Cache
from os import getpid


logger = log.fullon_logger(__name__)


class TickManager:
    """
    Manages the tick data for multiple exchanges.
    """
    started: bool = False

    def __init__(self) -> None:
        """Initializes the Tick Manager."""
        # logger.info("Initializing Tick Manager...")
        # self.clean_cache()
        self.stop_signals = {}
        self.thread_lock = threading.Lock()
        self.threads = {}

    def __del__(self) -> None:
        self.stop_all()

    def stop(self, thread):
        """
        Stops the tick data collection loop for the specified exchange.
        """
        with self.thread_lock:  # Acquire the lock before accessing shared resources
            if thread in self.stop_signals:
                self.stop_signals[thread].set()
                try:
                    self.threads[thread].join(timeout=10)  # Wait for the thread to finish with a timeout
                except Exception as error:
                    logger.error(f"Error stopping ohlcv {thread}: {error}")
                else:
                    logger.info(f"Stopped ohlcv {thread}")
                try:
                    del self.threads[thread]
                except KeyError:
                    pass
            else:
                logger.info(f"No running ticker found for exchange {thread}")

    def stop_all(self) -> None:
        """
        Stops tick data collection loops for all exchanges.
        """
        # Create a list of keys to prevent RuntimeError due to dictionary size change during iteration
        threads_to_stop = list(self.stop_signals.keys())
        for thread in threads_to_stop:
            self.stop(thread=thread)

    def clean_cache(self) -> None:
        """
        Cleans the table of process from tick processes
        """
        store = Cache()
        store.delete_from_top(component='tick')
        for key in store.get_keys(key='tickers:*'):
            store.delete_from_top(component=key)
        del store

    def get_cat_exchanges(self) -> List[Dict[str, Any]]:
        """
        Returns a list of supported exchanges with their names and ids.
        """
        with Cache() as store:
            exchanges = store.get_cat_exchanges()
        ret_list = [{'name': exch['name'], 'id': exch['id']} for exch in exchanges]
        return ret_list

    def btc_ticker(self) -> float:
        """
        Returns the current BTC price in USD from either Deribit or FTX.
        """
        cache_cur = Cache()
        price = cache_cur.get_price(symbol="XBT/USD")
        if price:
            del cache_cur
            return price
        price = cache_cur.get_price(symbol="BTC/USD")
        del cache_cur
        if price:
            return price
        logger.info("Could not get btc_ticker")
        return 0

    def get_exchange_pairs(self, exchange_name) -> List:
        """
        Returns a list of supported pairs in an exchanges .
        """
        with Cache() as store:
            pairs = store.get_symbols(exchange=exchange_name)
        result = []
        for pair in pairs:
            result.append(pair.symbol)
        return result

    def start(self, exchange_name: str) -> None:
        """
        Starts the tick data collection loop for the specified exchange.
        """
        # Create a new stop signal Event for the current thread and store it in the stop_signals dictionary
        stop_signal = threading.Event()
        self.stop_signals[exchange_name] = stop_signal
        tick_exchange = exchange.Exchange(exchange_name)
        if tick_exchange.has_ticker():
            pairs = self.get_exchange_pairs(exchange_name=exchange_name)
            tick_exchange.start_ticker_socket(tickers=pairs)
        del tick_exchange
        logger.info(f"Websocket loop for exchange {exchange_name} is up and running")
        time.sleep(1)
        # this is the loop somehow
        while not stop_signal.is_set():
            with Cache() as store:
                store.update_process(tipe="tick",
                                     key=exchange_name,
                                     message="Updated")
            time.sleep(7)
        del self.stop_signals[exchange_name]

    def run_loop(self) -> None:
        """
        Starts tick data collection loops for all supported exchanges.
        """
        exchanges = self.get_cat_exchanges()
        for exch in exchanges:
            thread = threading.Thread(target=self.start,
                                      args=(exch['name'],))
            thread.daemon = True
            thread.start()
            self.threads[exch['name']] = thread  # Store the thread in the threads dictionary
            self.register_process(exch=exch)
        # Start a new thread to monitor and relaunch dead threads
        self.launch_socket_monitor()
        statuses_updated: int = 0
        while statuses_updated < len(exchanges):
            for exch in exchanges:
                with Cache() as store:
                    proc = store.get_process(tipe="tick", key=exch['name'])
                if proc:
                    if proc['message'] == 'Updated':
                        statuses_updated += 1
                time.sleep(1)
        self.started = True

    def run_loop_one_exchange(self, exchange_name: str, monitor: bool = False) -> None:
        """
        Starts tick data collection loops for a particular exchange.
        """
        exchanges = self.get_cat_exchanges()
        for exch in exchanges:
            if exch['name'] == exchange_name:
                thread = threading.Thread(target=self.start,
                                          args=(exchange_name,))
                thread.daemon = True
                thread.start()
                self.threads[exch['name']] = thread  # Store the thread in the threads dictionary
                time.sleep(0.5)
                self.register_process(exch=exch)

        # Start a new thread to monitor and relaunch dead threads
        if monitor:
            self.launch_socket_monitor()

    def launch_socket_monitor(self) -> None:
        """
        Launches a new thread to monitor and relaunch dead threads.
        """
        monitor_thread = threading.Thread(target=self.relaunch_dead_threads)
        monitor_thread.daemon = True
        monitor_thread.start()

    def register_process(self, exch: Dict[str, Any]) -> None:
        """
        Registers a new process in the cache.
        """
        store = Cache()
        params = [exch['name'], exch['id']]
        store.new_process(tipe="tick",
                          key=exch['name'],
                          pid=f"thread:{getpid()}",
                          params=params,
                          message="Started")
        del store

    def relaunch_dead_threads(self) -> None:
        """
        Monitors and relaunches dead threads for tick data collection.
        """
        while True:
            for exchange_name, thread in self.threads.items():
                if not thread.is_alive():
                    logger.info(f"Thread for tick exchange {exchange_name} \
                        has died, relaunching...")
                    self.run_loop_one_exchange(exchange_name=exchange_name)
                    time.sleep(0.5)
            time.sleep(10)  # Check for dead threads every 10 seconds