"""
Manages launch of Bots
"""
from libs import log, bot as fbot
from libs.database import Database
import sys
import threading
import time
from typing import Any, Dict, Optional

logger = log.fullon_logger(__name__)


class BotManager:
    """
    Manages the launch of Bots
    """
    started: bool = False

    def __init__(self) -> None:
        """
        Initialize the BotManager class
        """
        self.stop_signals = {}
        self.threads = {}
        self.thread_lock = threading.Lock()

    def __del__(self):
        self.stop_all()

    def stop(self, bot_id: int) -> None:
        """
        Stops the specified bot.

        Args:
            bot_id (int): The id of the bot to stop
        """
        with self.thread_lock:  # Acquire the lock before accessing shared resources
            if bot_id in self.stop_signals:
                self.stop_signals[bot_id].set()
                try:
                    self.threads[bot_id].join(timeout=10)  # Wait for the thread to finish with a timeout
                except Exception as e:
                    logger.error(f"Error stopping bot {bot_id}: {e}")
                else:
                    logger.info(f"Stopped bot {bot_id}")

                del self.stop_signals[bot_id]
                del self.threads[bot_id]
            else:
                logger.info(f"No running bot found for bot_id {bot_id}")

    def stop_all(self) -> None:
        """
        Stops all the bots.
        """
        # Create a list of keys to prevent RuntimeError due to dictionary size change during iteration
        bots_to_stop = list(self.stop_signals.keys())
        for bot_id in bots_to_stop:
            self.stop(bot_id=bot_id)

    def bots_list(self) -> str:
        """
        Get a list of all bots

        Returns:
            str: A string representation of all bots in the format of
                '{bot_id: <id>, dry_run: <dry_run>}\n'
        """
        dbase = Database()
        bots = dbase.get_bot_list()
        del dbase
        bot_list = ""
        for bbot in bots:
            string = f'"bot_id":"{bbot.bot_id}",  "dry_run":"{bbot.dry_run}"'
            bot_list = bot_list + '{' + string + '}\n'
        return bot_list

    def edit(self, bot: fbot.Bot) -> bool:
        """
        Edit the specified bot

        Args:
            bot (bot.Bot): The bot to edit

        Returns:
            bool: True if the bot was successfully edited, False otherwise
        """
        dbase = Database()
        dbase.edit_bot(bot=bot)
        del dbase

    def start(self, bot_id: int) -> None:
        """
        Start the specified bot

        Args:
            bot_id (int): The id of the bot to start
        """
        return self.start_bot(bot_id=bot_id)

    def dry_delete(self, bot_id: int) -> None:
        """
        Delete all dry trades for the specified bot

        Args:
            bot_id (int): The id of the bot to delete dry trades for
        """
        dbase = Database()
        dbase.delete_dry_trades(bot_id=bot_id)
        del dbase

    @staticmethod
    def launch_simul(   # pylint: disable=too-many-arguments
            bot_id: int,
            periods: int = 500,
            visual: int = 0,
            event: bool = False,
            feeds: list = [],
            warm_up: Optional[Any] = None,
            test_params: Optional[Any] = None) -> Dict[str, Any]:
        """
        Launches simulation of bot with the specified parameters.
        :param bot_id: ID of the bot to simulate
        :param days: Number of days to simulate
        :param compression: Compression level for the simulation
        :param visual: Indicator for whether to show visual output during simulation
        :param warm_up: Additional parameters for warm-up phase of simulation
        :param test_params: Additional parameters for testing during simulation
        :return: Dictionary of results from the simulation
        """
        mainbot = fbot.Bot(bot_id=bot_id, bars=periods)
        if not mainbot.id:
            logger.error("Can't find bot id to run")
            return []
        results = mainbot.run_simul_loop(
            visual=visual,
            test_params=test_params,
            warm_up=warm_up,
            feeds=feeds,
            event=event)
        del mainbot
        return results

    def start_bot(self, bot_id: int, test: Optional[bool] = False) -> None:
        """
        Start a bot with the given bot_id.
  
        Parameters:
            bot_id (int): The id of the bot to start.
            test (Optional[bool]): Whether to run the bot in test mode. Defaults to False.
        """
        stop_signal = self.stop_signals.get(bot_id)
        if stop_signal is None:
            logger.error(f"Stop signal for bot {bot_id} not found")
            return

        mainbot = fbot.Bot(bot_id=bot_id)
        if mainbot.id:
            mainbot.run_loop(test=test, stop_signal=stop_signal)
        del self.stop_signals[bot_id]

    def run_bot_loop(self, daemon: Optional[bool] = True, test: Optional[bool] = False) -> None:
        """
        Description:
            This method starts a new process for each bot in the bot list that is set to active.
        Args:
            daemon (Optional[bool]): A flag indicating if the bot processes
                                    should run as daemons. Default is True.
            test (Optional[bool]): A flag indicating if the bot should run in
                                    test mode. Default is False.
        Returns:
            None
        """
        with Database() as dbase:
            dbase = Database()
        bots = dbase.get_bot_list(active=True)
        for bbot in bots:
            bot_id = bbot.bot_id
            if daemon:
                thread = threading.Thread(target=self.start,
                                          args=(bot_id,))
                thread.daemon = True
                thread.start()
                self.threads[bot_id] = thread  # Store the thread in the threads dictionary
                time.sleep(0.5)
            else:
                self.start_bot(bot_id=bot_id, test=test)
                sys.exit()
        logger.info("Bots started")
        #monitor_thread = threading.Thread(target=self.relaunch_dead_threads)
        #monitor_thread.daemon = True
        #monitor_thread.start()
        self.started = True

    def relaunch_dead_threads(self):
        """
        comment
        """
        while True:
            for bot_id, thread in self.threads.items():
                if not thread.is_alive():
                    logger.info(f"Thread for bot {bot_id} has died, relaunching...")
                    new_thread = threading.Thread(target=self.start, args=(bot_id,))
                    new_thread.daemon = True
                    new_thread.start()
                    self.threads[bot_id] = new_thread
                    time.sleep(0.5)
            time.sleep(10)  # Check for dead threads every 10 seconds