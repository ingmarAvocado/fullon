import os
from pathlib import Path
import arrow
import psutil
from typing import List, Optional, Any
from libs.structs.symbol_struct import SymbolStruct
from libs import settings, cache, log
from libs.database import Database
from libs.models.ohlcv_model import Database as Database_ohlcv
from run import install_demo

logger = log.fullon_logger(__name__)


class InstallManager:
    """A class that provides methods to install and manage Fullon Trading System"""

    def __init__(self):
        """
        Initializes InstallManager
        """
        pass

    def __enter__(self) -> 'InstallManager':
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        return self

    def make_backup(self, name: Optional[str] = None, full: bool = False, mini: bool = False) -> None:
        """
        Create a backup of the PostgreSQL database using pg_dump and gzip.

        Args:
            name (str, optional): The name of the backup file. If not provided, a default name will be used.
            full (bool, optional): Whether to create a full backup of the database (including all schemas).
            mini (bool, optional): Whether to create a mini backup of the database (including only some tables).

        Raises:
            ValueError: If neither full nor mini is True.
        """
        logger.info("Making backup...")
        if not (full or mini):
            raise ValueError("One of 'full' or 'mini' must be True.")

        backup_name = (
            f"{arrow.utcnow().format('YYYY-MM-DD_HH:mm:ss')}.sql.gz"
            if not name
            else f"{name}.sql.gz"
        )
        backup_type = "fullon_back_" if full else "mini_fullon_back_"
        backup_path = os.path.join(settings.BACKUPS, backup_type + backup_name)

        if full:
            schema = ""  # Add a specific schema here if needed
        elif mini:
            schema = (
                "-a -t cat_exchanges -t symbols -t cat_exchanges_params -t users "
                "-t exchanges -t cat_strategies -t cat_strategies_params -t strategies "
                "-t strategies_params -t bots -t bot_exchanges -t trades -t dry_trades"
            )

        prefix = (
            f"PGHOST={settings.DBHOST} PGPORT={settings.DBPORT} PGDATABASE={settings.DBNAME} "
            f"PGUSER={settings.DBUSER} PGPASSWORD={settings.DBPASSWD} {settings.PG_DUMP} -w"
        )
        cmd = f"{prefix} {schema} | {settings.GZIP} --best  >  {backup_path}"
        logger.info(cmd)
        os.system(cmd)
        logger.info("Backup completed")

    def recover_backup(self, name: str) -> bool:
        """
        Recovers a backup with the given name.

        Args:
            name (str): The name of the backup to recover.

        Returns:
            bool: True if the backup was recovered successfully, False otherwise.
        """
        dbase = Database()
        msg = f"Recovering backup {name}"
        logger.info(msg)
        name = settings.BACKUPS + name
        cmd = f"{settings.GUNZIP} -c {name} | PGHOST={settings.DBHOST} \
                PGPORT={settings.DBPORT} PGDATABASE={settings.DBNAME} \
                PGUSER={settings.DBUSER} PGPASSWORD={settings.DBPASSWD}\
                {settings.PSQL} -w  %s' {settings.DBNAME}"
        logger.info(cmd)
        result = os.system(cmd)
        del dbase
        if result == 0:
            logger.info("Backup recovered")
            return True
        else:
            logger.error("Failed to recover backup")
            return False

    def list_backups(self) -> List[str]:
        """
        Lists all backups.

        Returns:
            List[str]: A list of strings representing the names and sizes of each backup.
        """
        logger.info("Listing backups...")
        flist = []
        count = 1
        try:
            for this_path in Path(settings.BACKUPS).iterdir():
                if this_path.is_file():
                    name = this_path.name
                    if 'sql.gz' in name:
                        filesize = int(os.path.getsize(this_path))
                        size = round(filesize/1024/1024, 2)
                        flist.append(f"{count}:\t{name}\t{size}M")
                        count = count + 1
        except FileNotFoundError as error:
            if "No such file or directory" in str(error):
                os.mkdir(settings.BACKUPS)
        return flist

    def install_strategies(self) -> None:
        """
        Installs all available strategies by scanning the 'strategies/' directory and installing each strategy.
        """
        with Database() as dbase:
            for (dirpath, dirnames, filenames) in os.walk('strategies/'):
                for dirname in dirnames:
                    if dirname != "__pycache__":
                        dbase.install_strategy(dirname)
            del dbase

    def install_exchanges(self) -> None:
        """
        Installs all available exchanges by scanning the 'exchanges/' directory and installing each exchange.
        """
        with Database() as dbase:
            # Try the first path
            path = 'exchanges/'
            if not os.path.exists(path):
                # If the first path is not found, try the second path
                path = 'fullon/exchanges'
            for (dirpath, dirnames, filenames) in os.walk(path):
                for dirname in dirnames:
                    if dirname not in ["simulator", "ccxt", "__pycache__"]:
                        dbase.install_exchange(dirname)

    def install_symbol(self, symbol: SymbolStruct) -> None:
        """
        Installs a specific symbol in the database.

        Args:
            symbol (str): The symbol to be installed in the database.
        """
        with Database() as dbase:
            dbase.install_symbol(symbol=symbol)

    def remove_symbol(self, symbol: SymbolStruct) -> None:
        """
        Removes a specific symbol in the database.

        Args:
            symbol (str): The symbol to be installed in the database.
        """
        with Database() as dbase:
            dbase.remove_symbol(symbol=symbol)
        with cache.Cache() as store:
            store.delete_symbol(symbol=symbol.symbol,
                                exchange_name=symbol.exchange_name)

    def add_user(self, user: dict) -> None:
        """
        Adds a new user to the database.

        Args:
            user (dict): The user dict
        """
        with Database() as dbase:
            dbase.add_user(user)

    def remove_user(self, user_id: Optional[str] = None, email: Optional[str] = None) -> None:
        """
        Adds a new user to the database.

        Args:
            username (str): The username for the new user.
            password (str): The password for the new user.
            email (str): The email address for the new user.
        """
        with Database() as dbase:
            dbase.remove_user(user_id, email)

    def list_symbols(self) -> List[SymbolStruct]:
        """
        Lists all available symbols in the database.

        Returns:
            List[Tuple[str, str]]: A list of tuples with the symbol names and exchange names.
        """
        with Database() as dbase:
            symbols = dbase.get_symbols()
        return symbols

    def install_symbols(self, exchange: str) -> None:
        """
        Installs all symbols for a given exchange.

        Args:
            exchange (str): The name of the exchange for which to install symbols.
        """
        with Database() as dbase:
            symbols = dbase.get_symbols(exchange)
        if symbols:
            for symbol in symbols:
                dbase.install_symbol(symbol)

    def list_exchanges(self) -> str:
        """
        Lists installed exchanges.

        Returns:
            str: A string containing the list of installed exchanges.
        """
        with cache.Cache() as store:
            exchanges = store.get_exchanges()
            list_exs = ""
        for exch in exchanges:
            string = f'"exchange:"{exch.name}","Active":"{exch.active}"'
            list_exs = list_exs + "{"+string+"}\n"
        return list_exs

    def list_cat_strategies(self) -> str:
        """
        Lists installed strategies.

        Returns:
            str: A string containing the list of installed strategies.
        """
        with Database() as dbase:
            strategies = dbase.get_cat_strategies()
            list_str = ""
            for strat in strategies:
                list_str = list_str + \
                 '{"strategy:"'+strat.name+'","id":"'+strat.cat_str_id+'"}\n'
            return list_str

    def list_user_strategies(self, uid: int) -> str:
        """
        Lists user-installed strategies.

        Args:
            uid (int): User ID for which to list installed strategies.

        Returns:
            str: A string containing the list of user-installed strategies.
        """
        with Database() as dbase:
            strategies = dbase.get_user_strategies(uid=uid)
            list_str = ""
            if strategies:
                for strat in strategies:
                    list_str = list_str +\
                     '{strategy:"'+strat.str_id+'","id":"'+strat.str_named+'}"}\n'
            return list_str

    def install_cache(self) -> bool:
        """
        Initializes the cache.

        Returns:
            bool: True if the cache is initialized successfully, False otherwise.
        """
        with cache.Cache() as store:
            store.prepare_cache()
        logger.info("Cache Started...")
        return True

    def get_running_services(self):
        """Returns the names of all child processes of a given parent process name.

        Args:
            parent_name (str): The name of the parent process.

        Returns:
            list of str: A list of child process names.
        """
        parent_name = "Fullon Trading Daemon"
        child_names = []
        for process in psutil.process_iter(['name', 'ppid']):
            if process.info['name'] == parent_name:
                parent_pid = process.pid
                break
        else:
            # Parent process not found
            return child_names
        for process in psutil.process_iter(['name', 'ppid']):
            if process.info['ppid'] == parent_pid:
                if 'Ticker' in process.info['name']:
                    child_names.append('tick')
                if 'OHLCV' in process.info['name']:
                    child_names.append('ohlcv')
                if 'Account' in process.info['name']:
                    child_names.append('account')
                if 'Order' in process.info['name']:
                    child_names.append('order')
                if 'Bot' in process.info['name']:
                    child_names.append('bot')
        return child_names

    def get_top(self) -> List[Any]:
        """
        Get the top services.
        Returns:
            A list of top services.
        """
        store = cache.Cache()
        services = store.get_top()
        del store
        return services

    def clean_top(self, component: Optional[str] = None, pid: Optional[int] = None) -> bool:
        """
        Delete a component or process from the top services list.

        Args:
            component: The component to be deleted, if provided.
            pid: The process ID to be deleted, if provided.

        Returns:
            bool: True if deleted
        """
        store = cache.Cache()
        res = store.delete_from_top(component=component, pid=pid)
        del store
        if res > 0:
            return True
        return False

    def test_pre_install(self) -> bool:
        """
        Test if the pre-installation conditions are met.

        Returns:
            True if the conditions are met, otherwise False.
        """
        ret = True
        with Database() as dbase:
            if 'Error' in dbase.get_user_list():
                ret = False
        return ret

    def install_demo(self) -> None:
        """
        Install the demo data.
        """
        install_demo.install()
