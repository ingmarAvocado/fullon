#!/usr/bin/python3
from libs.settings_config import fullon_settings_loader
from libs import log, settings, database, cache
import sys
from multiprocessing import Process
import os
import time
from libs import simul, bot
from run import rpcdaemon_manager as rpc



#This will launch the bot manager
#print ("Launching BOT Manager...")


#bot_manager=system_manager.BotManager()
#bot_manager.run_bot_loop(daemon=False, test = False)
#bot_manager.start_bot(bot_id="00000000-0000-0000-0000-000000000004")
#print ("launched")

#install=system_manager.InstallManager()

#p=system_manager.ProcessManager()
#p.monitor()

#bot_manager.run_bot_simul_loop()
#Process(target=bot_manager.run_bot_loop,args=()).start()
#Process(target=bot_manager.run_bot_loop,args=()).start()

# params = {"stop_loss": "10"}
#./fullon_daemons.py bots simul '{"bot_id":"3dba0791-aced-410d-bfc1-c2094a8ba376", "days":"30",  "verbose":"1", "compression":"480", "visual":"0", "params":{"smaShort":"7", "smaLong":"13"}}'

#45, 13 seems to work on 1 day, and 5min

params1 = {"sma1": "45",
          "sma2": "13",
          "zshort": "-3.0",
          "zlong": "3.0",
          "zexitlow": "-1.5",
          "zexithigh": "1.5",
          "stop_loss": "1",
          "take_profit": "1",
          "size_pct": "10",
          "leverage": "1"}
#77
params2 = {
          "stop_loss": "1.5",
          "take_profit": "2.5",
          "size_pct": "10",
          "leverage": "1",
          "rsi_upper": "74",
          "rsi_lower": "30",
          "leverage": "1"}

#params = {"sma1": "30", "sma2": "13", "zshort": "-1", "zlong": "1", "zexitlow": "-0.75", "zexithigh": "0.75", "stop_loss": "4.1"}
BOT = {"bot_id": "00000000-0000-0000-0000-000000000005",
       "periods": 8800,
       "warm_up": 9200,
       "xls": 0,
       "verbose": "0",
       "visual": False,
       "params": params2}
#feeds = {2: {'compression': 30}, 3: {'compression': 30}}
feeds = {}


#parallel
#r = rpc.bot_simul(bot=BOT)
#BOT = {"bot_id": "00000000-0000-0000-0000-000000000002", "periods": 432, "warm_up": 450, "params": {}}

r = rpc.bot_simul(bot=BOT, event_based=True, feeds=feeds, params=params2)
#r = rpc.bot_simul(bot=BOT, event_based=False, feeds=feeds, params=params)
#r = rpc.bot_test('00000000-0000-0000-0000-000000000003')
"""
params ={"stop_loss":"4","take_profit":"8"}
BOT = {"bot_id": "00000000-0000-0000-0000-000000000001", "days": 100, "xls": 0, "verbose": "0",  "visual": "0", "params": params}
from run import rpcdaemon_manager as rpc
r = rpc.run_simul(bot=BOT, params=params)
"""

