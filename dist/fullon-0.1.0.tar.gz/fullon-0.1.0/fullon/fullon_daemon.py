#!/usr/bin/python3
"""
Runs fullon_daemon
"""
from __future__ import unicode_literals, print_function
#from signal import signal, SIGINT
import shutil
import sys
import os
import time
from threading import Thread, Event
import argparse
import psutil
from termcolor import cprint
from pyfiglet import figlet_format
from clint.textui import colored
from libs import log, settings
from libs.settings_config import fullon_settings_loader  # pylint: disable=unused-import
from libs.exchange import Exchange, start_all, stop_all
from libs.cache import Cache
from run import system_manager, rpcdaemon_manager as rpc

logger = log.fullon_logger(__name__)
thread: Thread

'''
def handler(signal_received: int, frame) -> None:
    """ Handle any cleanup here """
    del signal_received
    del frame
    try:
        thread.join()
        stop()
    except AssertionError:
        pass
    logger.info('SIGINT or CTRL-C detected. Exiting gracefully')
    sys.exit()
'''


def start_pmanager() -> None:
    """
    Start the process manager.
    This function initializes the ProcessManager from the system_manager module,
    logs a message indicating that the ProcessManager is running, and then starts
    the process monitor.
    Returns:
        None
    """
    pass


def print_colored_line(char: str, color: str) -> None:
    """
    Prints a colored line using the given character and color.

    Args:
        char (str): The character to be repeated to form the line.
        color (str): The color to be used for the line.

    Returns:
        NoReturn: This function does not return any value.
    """
    cprint(char * 80, color, attrs=['bold'])


def main(cli_args: argparse.Namespace) -> None:
    """
    Main function to manage the execution of the trading bot based on the provided arguments.

    Args:
        cli_args: argparse.Namespace object containing the parsed command line arguments.
    """
    # Check if the "stop" argument is passed, and stop components accordingly
    global thread

    if cli_args.stop:
        rpc.shutdown(message="Shutdown from command line")
        return

    # Set up signal handling for graceful shutdown on SIGINT or CTRL-C
    #signal(SIGINT, handler)

    # Remove the 'tmp' directory if it exists and create a new one
    try:
        shutil.rmtree('tmp/')
    except FileNotFoundError:
        pass
    os.mkdir('tmp')

    # Print the Fullon Crypto Trading Bot title using PyFiglet
    figlet = figlet_format('Fullon Crypto Trading Bot', font='larry3d', width=120)

    print_colored_line('=', 'blue')
    cprint(figlet, 'yellow', attrs=['bold'])
    print_colored_line('=', 'blue')

    print(colored.yellow(" Fullon Crypto Trading Bot FERI7701027FL9 Crypto Services (C) 2023"))
    print_colored_line('-', 'magenta')

    # Check if an instance of the trading bot is already running and exit if it is
    for process in psutil.process_iter(['pid', 'name', 'username']):
        if "Fullon" in process.name():
            if os.getuid() == process.uids().real:
                print(colored.red("A daemon is already running, use -x to stop it"))
                return

    # Start the trading bot based on the provided arguments
    if cli_args.daemon:
        logger.warning("Daemon mode not yet implemented")
    else:
        logger.info("Press Q/q to quit")
        start_all()
        stop_event = Event()
        # Start the ProcessManager and RPC server
        thread = Thread(target=rpc.pre_rpc_server,
                        args=(cli_args.full, cli_args.services, stop_event))
        thread.start()
        logger.info("Console detached")
        quit = False
        try:
            while thread.is_alive():
                time.sleep(5)
        except KeyboardInterrupt:
            try:
                logger.info(colored.red("Quitting Fullon... stopping threads..."))
                rpc.stop_full()
                stop_event.set()
                thread.join()
            except (EOFError, KeyboardInterrupt) as error:
                pass
        stop_all()


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Fullon Daemon Help Page")
    parser.add_argument("-f", "--full", action="store_true",
                        help="Starts all components")
    parser.add_argument("-s", "--services", action="store_true",
                        help="Starts all components, but not individual bots")
    parser.add_argument("-d", "--daemon", action="store_true",
                        help="Runs in background")
    parser.add_argument("-x", "--stop", action="store_true",
                        help="Stops components")

    args = parser.parse_args()
    main(args)
