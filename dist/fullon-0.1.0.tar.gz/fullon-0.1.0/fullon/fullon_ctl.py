#!/usr/bin/python3
"""
This module helps launch the fullon CLI interface.
"""
from __future__ import unicode_literals, print_function
import sys
from typing import List
from setproctitle import setproctitle
from clint.textui import colored
from termcolor import cprint
from pyfiglet import figlet_format
from prompt_toolkit import PromptSession
from prompt_toolkit.history import FileHistory
from prompt_toolkit.key_binding import KeyBindings
from run import ctl_manager as ctl
from libs import log, settings
from libs.settings_config import fullon_settings_loader  # pylint: disable=unused-import

logger = log.fullon_logger(__name__)
bindings = KeyBindings()


class FullonSwitch:  # pylint: disable=too-few-public-methods
    """FullonSwitch is a command dispatcher for the Fullon CLI."""

    argv: str

    def exec(self, argv: List[str]) -> None:
        """Execute the appropriate command based on the given arguments.

        Args:
            argv (List[str]): A list of command-line arguments.
        """
        self.argv = argv
        default = "Unknown option"
        name = argv[1]
        if name == "h":
            name = "help"
        return getattr(self, name, lambda: default)()

    # ... All other FullonSwitch methods ...


def print_colored_line(char: str, color: str) -> None:
    """
    Prints a colored line using the given character and color.

    Args:
        char (str): The character to be repeated to form the line.
        color (str): The color to be used for the line.

    Returns:
        NoReturn: This function does not return any value.
    """
    cprint(char * 80, color, attrs=['bold'])


def main(argv: List[str]) -> None:
    """Main function to execute the Fullon CLI command.

    Args:
        argv (List[str]): A list of command-line arguments.
    """
    ctl.validate_command(argv)
    switch = FullonSwitch()
    switch.exec(argv)

# ... KeyBindings ...


@bindings.add('c-c')
def _(event):
    """ Exit when `c-c` is pressed. """
    logger.info("Bye...\n")
    print("\n")
    event.app.exit()
    sys.exit()


@bindings.add('c-d')
def _(event):
    """ Exit when `c-d` is pressed. """
    logger.info("Bye...\n")
    print("\n")
    event.app.exit()
    sys.exit()


if __name__ == "__main__":
    setproctitle("Fullon Trading CTL")
    figlet = figlet_format('Fullon Crypto Trading Bot CTL', font='larry3d', width=120)
    print_colored_line('=', 'blue')
    cprint(figlet, 'red', attrs=['bold'])
    print_colored_line('=', 'blue')
    print(colored.yellow(" Fullon Crypto Trading Bot FERI7701027FL9 Crypto Services (C) 2023"))
    print_colored_line('-', 'magenta')

    session = PromptSession(history=FileHistory("fullon_history.txt"),
                            key_bindings=bindings)
    MESG = 'Running Fullon Shell....   '+colored.blue('Press CTRL-C to exit.')
    logger.info(MESG)
    logger.info('Fullon Crypto Trading Bot FERI7701027FL9 Crypto Services (C) 2023')
    ARGS = None
    try:
        if ctl.RPC.rpc_test() == "fullon":
            logger.info(colored.green("Connected to daemon!\n"))
            while True:
                reply = session.prompt("(Fullon Shell)> ")
                if ctl.RPC.rpc_test() == "fullon":
                    jsonstring = reply
                    reply = ' '.join(reply.split()).split(' ')
                    ARGS = ['fullon']
                    for e in reply[0:2]:
                        jsonstring = jsonstring.replace(e,'')
                        ARGS.append(e)
                    ARGS.append(jsonstring.lstrip())
                    main(argv=ARGS)
    except ConnectionRefusedError:
        logger.warning(colored.red("Connection Refused: Is daemon up and running?\n"))
        sys.exit()
