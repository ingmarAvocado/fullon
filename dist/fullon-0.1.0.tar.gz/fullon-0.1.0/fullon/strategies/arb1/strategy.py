from __future__ import (absolute_import, division, print_function, unicode_literals)

import sys
from time import sleep
import backtrader as bt
import backtrader.indicators as btind
import arrow
from libs import strategy as st
from libs import settings
import os

        
class strategy(st.strategy):
      
    
    params = (
    )
    

    def local_init(self): 
        return None


    def get_entry_signal(self):
        return None


    #should we do a local_next?
    def local_next(self):
        mxn = self.get_ticker("bitso", "BTC/MXN")[0]
        tusd =  self.get_ticker("bitso", "TUSD/MXN")[0]
        inusd = round(mxn/tusd,2)
        line = f"{self.curtime},{self.tick},{inusd}\n"
        with open('arb1.csv', 'a') as f1:
            f1.write(line)
        return None


   
