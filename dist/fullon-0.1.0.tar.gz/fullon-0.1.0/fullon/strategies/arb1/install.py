class install_strategy():
    
    def __init__(self):
        return None
        
    def get_params(self):
        params=[]
        param={'name':'feed1','type':'select','options':'candles1m','default':'candles1m'}
        params.append(param)
        return params


