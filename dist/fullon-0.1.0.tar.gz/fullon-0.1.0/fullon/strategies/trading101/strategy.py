"""
Describe strategy
"""
import pandas
import decimal
import backtrader.indicators as btind
import backtrader as bt
import arrow
from typing import Union
from libs.strategy import loader
import pdb

#from libs.strategy import strategy as strat

# logger = log.setup_custom_logger('pairtrading1a', settings.STRTLOG)

strat = loader.strategy


class strategy(strat.Strategy):
    """description"""

    params = (('sma1', 45), ('bars', 45))

    def local_init(self):
        """description"""
        self.verbose = True
        self.order_cmd = "spread"
        #self.sema1 = btind.EMA(self.data1, period=10)

        return None

    def local_next(self):
        """ description """
        if self.entry_signal[0]:
            self.open_pos(0)

    def get_entry_signal(self):
        self.entry_signal[0] = None

    def risk_management(self):
        return super().risk_management()
