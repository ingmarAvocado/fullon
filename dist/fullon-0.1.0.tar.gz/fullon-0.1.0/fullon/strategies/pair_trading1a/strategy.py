"""
Describe strategy
"""
import arrow
from libs.strategy import loader
from libs import log
from typing import  Optional
#from libs.strategy import strategy as strat

logger = log.fullon_logger(__name__)


strat = loader.strategy


class strategy(strat.Strategy):
    """description"""

    event_table = ""

    params = (
        ('sma1', 45),
        ('sma2', 13),
        ('stop_loss', 1),
        ('zshort', -3.0),
        ('zlong', 3.0),
        ('zexitlow', -1.15),
        ('zexithigh', 1.15),
        ('block', 3),
        ('bars', 51)
    )

    def local_init(self):
        """description"""
        self.verbose = False
        self.p.sma1 = int(self.p.sma1)
        self.p.sma2 = int(self.p.sma2)
        self.p.zshort = float(self.p.zshort)
        self.p.zlong = float(self.p.zlong)
        self.p.zexitlow = float(self.p.zexitlow)
        self.p.zexithigh = float(self.p.zexithigh)
        self.p.block = int(self.p.block)
        self.stopd = None
        self.next_open = None
        if not self.feeds_have_futures():
            logger.error("To run this strategy you need feeds that support futures")
        return None

    def local_next(self):
        """ Runs every tick, when there is no position at all """
        if self.entry_signal[0] and self.entry_signal[1]:
            if self.curtime[0] >= self.next_open:
                self.open_pos(0)
                self.open_pos(1)
                self.entry_signal[0] = ""
                self.entry_signal[1] = ""

    def set_indicators_df(self) -> None:
        """
        This method sets a new dataframe based on the values of class attributes 'simul' and 'fast_simul'.
        Its run automatically every tick
        """
        # Create a new variable 'ratios' that contains the quotient of 'close'
        # column of the dataframe of the 3rd element of 'datas' and the 'close'
        # column of the dataframe of the 4th element of 'datas'
        ratios = self.datas[2].dataframe['close'] / self.datas[3].dataframe['close']
        # Calculate rolling mean of 'ratios' with window size of 'self.p.sma1' and
        # assign it to 'ma1'
        ma1 = ratios.rolling(window=self.p.sma1, center=False).mean()
        # Calculate rolling mean of 'ratios' with window size of 'self.p.sma2' and
        # assign it to 'ma2'
        ma2 = ratios.rolling(window=self.p.sma2, center=False).mean()
        # Calculate the standard deviation of 'ratios' with window size of
        # 'self.p.sma2' and assign it to 'std'
        std = ratios.rolling(window=self.p.sma2, center=False).std()
        # Calculate the z-score as the difference of 'ma1' and 'ma2' divided by
        # 'std' and assign it to 'zscore'
        zscore = (ma1 - ma2) / std
        # Create a new dataframe 'self.indicators_df' with the 'zscore' values, reset
        # the index and rename the column 'close' to 'zscore'
        self.indicators_df = zscore.to_frame().reset_index()
        self.indicators_df['date2'] = self.indicators_df['date']
        self.indicators_df.set_index('date', inplace=True)
        self.indicators_df.rename(columns={'date2': 'date', 'close': 'zscore'}, inplace=True)
        self.indicators_df.index.name = 'index'

    def local_nextstart(self):
        """ Only runs once, before local_next"""
        self.next_open = self.curtime[0]

    def risk_management(self):
        """
        Handle risk management for the strategy.
        This function checks for stop loss and take profit conditions,
        and closes the position if either of them are met.

        only works when there is a position, runs every tick
        """
        # Check for stop loss
        roi0 = self.roi_pct[0]
        roi1 = self.roi_pct[1]
        reason = None
        # if self.curtime[0].timestamp() >= arrow.get('2023-02-22 08:44:00').timestamp():
        #    print(self.curtime[0])
        #    print(f"tick0: ({self.tick[0]}) tick1: ({self.tick[1]}) roi0 ({roi0}) roi1 ({roi1}) stop loss0: ({self.stop_loss[0]}) stop_loss1: ({self.stop_loss[1]})")
        #    exit()
        if roi0 <= -abs(self.p.stop_loss) or roi1 <= -abs(self.p.stop_loss):
            reason = "stop_loss"
        # Check for take profit
        if self.p.take_profit:
            if roi0 >= self.p.take_profit or roi1 >= self.p.take_profit:
                reason = "take_profit"
        zscore = self._get_zscore()
        if reason is None:
            if zscore > self.p.zexitlow and zscore < self.p.zexithigh:
                reason = "strategy"
        if reason:
            next_period = self.datas[2].time_to_ohlcv(current_time=self.curtime[0])
            seconds = self.datas[2].get_time_factor()*(self.p.block)
            self.next_open = self.curtime[0].shift(seconds=seconds+next_period)
            self.close_position(reason=reason, feed=0)
            self.close_position(reason=reason, feed=1)

    def get_entry_signal(self) -> None:
        """
        Description:
        Sell short if the z-score is > 1
        Buy long if the z-score is < -1
        """
        self.entry_signal[0] = ""
        self.entry_signal[1] = ""
        #if self.new_candle[2]:
        zscore = self._get_zscore()
        if zscore is not None:
            if zscore < self.p.zshort:
                self.entry_signal[0] = "Sell"
                self.entry_signal[1] = "Sell"
            elif zscore > self.p.zlong:
                self.entry_signal[0] = "Buy"
                self.entry_signal[1] = "Buy"

    def _get_zscore(self) -> float:
        """
        This method retrieves the z-score value for the current date.
        """
        try:
            # Get the z-score value for the current date from the 'zscoredf' dataframe
            curtime_str = self.curtime[2].format('YYYY-MM-DD HH:mm:ss')
            zscore = self.indicators_df.at[curtime_str, 'zscore']
            #zscore = self.indicators_df.query(f"date =='{self.curtime[2].format('YYYY-MM-DD HH:mm:ss')}'").iloc[0][0]
        except IndexError as error:
            if "out-of-bounds" in str(error):
                # Return nothing if the date is out-of-bounds
                return
            else:
                # Raise an error if any other error occurs
                raise IndexError("Error setting event")
        except AttributeError as error:
            raise
            return None
        return zscore

    def event_in(self) -> Optional[arrow.Arrow]:
        """
        Returns the closest date when the zscore is greater than self.p.zlong or less than self.p.zshort
        This date is for the simulator to know when to get in a new position, this is for the event based simulator
        """
        try:
            feed_times = []
            curtime = self.next_open.format('YYYY-MM-DD HH:mm:ss')
            target = self.indicators_df.query(
                f"(zscore < {self.p.zshort} and \
                index >= '{curtime}') \
                or (zscore > {self.p.zlong} and \
                index >= '{curtime}')").iloc[0][1]
            target = arrow.get(target)
            return target

        except IndexError as error:
            if 'out-of-bounds' in str(error):
                return
            raise IndexError("Can't continue") from error
        except TypeError as error:
            return

    def event_out(self) -> arrow.Arrow:
        """
        This method retrieves the date of the next z-score event within the range defined by 'zexitlow' and 'zexithigh'
        and after the current date.

        This date is for the simulator, to know when to get out of a position. This is for the even based simulator
        """
        try:
            curtime0 = self.curtime[0].format('YYYY-MM-DD HH:mm:ss')
            curtime1 = self.curtime[1].format('YYYY-MM-DD HH:mm:ss')
            # Get the date of the next z-score event within the range defined by 'zexitlow' and 'zexithigh'
            # and after the current date from the 'zscoredf' dataframe
            # maybe this is on when to exit on stop?
            target0 = self.indicators_df.query(
                f"zscore > {self.p.zexitlow} and \
                       zscore < {self.p.zexithigh} and \
                       index >= '{curtime0}'").iloc[0][1]

            target1 = self.indicators_df.query(
                f"zscore > {self.p.zexitlow} and \
                       zscore < {self.p.zexithigh} and \
                       index >= '{curtime1}'").iloc[0][1]
            target0 = arrow.get(target0)
            target1 = arrow.get(target1)
            # Find the closest event time from both feeds and return it
            if target0 <= target1:
                return target0
            else:
                return target1

        except IndexError as error:
            if 'out-of-bounds' in str(error):
                # Return 'None' if the date is out-of-bounds
                return
            else:
                # Raise an error if any other error occurs
                raise IndexError("something bad happened") from error
        except AttributeError as error:
            return
