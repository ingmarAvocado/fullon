from __future__ import (absolute_import, division, print_function, unicode_literals)

import sys
from time import sleep
#sys.path.append("../btrader")
import backtrader as bt
from libs import strategy as st
import backtrader.indicators as btind
import random

       
        
        
class strategy(st.strategy):
    
    params= (
            ('entryframe', 20),
            ('exitframe', 20),
            ('mktorder', False),
            )
    
    def local_init(self):
        #self.min = btind.Lowest(self.data1, period=10)
        self.mini = 0
        #self.max = btind.Highest(self.data1, period=10)
        #self.ema50 = btind.EMA(self.data1, period=10)
        self.order_cmd = None
        self.bot_vars = ['mini']

        return None
    
    def local_next(self):
        if self.mini == 0:
            self.mini = random.random()
        self.order_cmd = None
        print("----------------------------"+self.datas[1].symbol+"--------------------------------------------------------")
        print("Date 1: ",bt.num2date(self.datas[0].datetime[0]))
        print("Date 2: ",bt.num2date(self.datas[1].datetime[0]))
        print("Our current position size:price: %s:%s" %(self.pos, self.pos_price))
        print("Our current total funds are ", self.totalfunds)
        print("Our current avail funds are ", self.cash)
        print("Current tick is: ", round(self.tick[0],8))
        print("curent mini: ", self.mini)
        question ="""Which test 
        (a) Limit Buy
        (b) Limit Sell 
        (c) Mkt Buy  
        (d) Mkt Sell 
        (e) Mkt Stop Buy 
        (f) Mkt stop Sell 
        (g) Limit Stop Buy 
        (i) Limit Stop Sell 
        (x) Fomo limit Buy 
        (y) Fomo limit Sell
        (z) Entry
        Test: """
        test = input(question)
        #test="x"
        #self.save_log(message = '{"work":"True"}')
        #print(vars(self.get_bot_vars))
        self.save_log(action = "test")

        self.signal=""
        if test=="a" or test=="c" or test=="e" or test == "g" or test=="x":
            self.signal="Buy"
        elif test=="b" or test=="d" or test=="f" or test =="i" or test=="y":
            self.signal="Sell"

        self.entry_signal[0] =  self.signal

        if self.signal:
            if test == "c" or test =="d":
                return self.mkt()
            elif test== "e" or test =="f":
                return self.mkt_stop()
            elif test=="g" or test=="i":
                return self.limit_stop()
            elif test == "x" or test=="y":
                return self.limit_fomo()
            else:
                return self.limit()
        else:
            if test == "z":
                return self.test_entry()
        return None


    def risk_management(self):
        return self.local_next()
                
    def limit_fomo(self):
        self.order_cmd = "process_now"
        #self.exectype = bt.Order.Market
        if self.futures and self.signal=="Buy" and self.pos < 0:
            order = self.close_position(type = "limit")
            return None
        if self.signal == "Sell" and self.pos > 0:
            order = self.close_position(type = "limit")
            return None
        if self.signal != "" :  
            if self.futures and self.signal == "Sell":
                self.open_short()
            elif self.signal == "Buy":    
                self.open_long()
        return None


    def test_entry(self): 
        print("Getting Entry")
        entry_size = self.entry()
        print ("Entry is :", entry_size)
        return None
        
    def limit(self): 
        if self.futures and self.signal=="Buy" and self.pos < 0:
            #if signal is buy, and we are shorting we close position.
            order = self.buy(self.datas[0], exectype=bt.Order.Limit, size=self.pos, price=self.tick) 
            return None
        if self.signal=="Sell" and self.pos > 0:
            #if signal is sell, and we are longing we close position.
            order = self.sell(self.datas[0], exectype=bt.Order.Limit, size=self.pos, price=self.tick)
            return None
        #if no position open a new one
        if self.signal != "" :  
            entry_size=self.entry()
            if self.futures and self.signal == "Sell":
                order = self.sell(self.datas[0], exectype=bt.Order.Limit, size=entry_size, price=self.tick)
            elif self.signal == "Buy":    
                order = self.buy(self.datas[0], exectype=bt.Order.Limit, size=entry_size, price=self.tick)
            return None
        return None
        
    def limit_stop(self): 
        stop = self.tick - (self.tick  * .020 ) #=int(input("tell me the limit stop price, remember this is a "+self.signal+" signal: "))
        price = stop #int(input("tell me the buy/sell price: "))
        
        if self.futures and self.signal=="Buy" and self.pos < 0:
            #if signal is buy, and we are shorting we close position.
            order = self.buy(self.datas[0], exectype=bt.Order.StopLimit, size=self.pos, price=price, plimit=stop) #will have to find a way for simulating market with limit
            return None
        
        if self.signal=="Sell" and self.pos > 0:
            #if signal is sell, and we are longing we close position.
            order = self.sell(self.datas[0], exectype=bt.Order.StopLimit, size=self.pos, price=price, plimit=stop) #will have to find a way for simulating market with limit
            return None

        #if no position open a new one
        if self.signal != "" and self.pos == 0 and not self.orders: 
            entry_size=self.entry()
            if self.futures and self.signal == "Sell":
                stop = self.tick - (self.tick  * .020 ) #=int(input("tell me the limit stop price, remember this is a "+self.signal+" signal: "))
                price = stop #int(input("tell me the buy/sell price: "))
                order = self.sell(self.datas[0], exectype=bt.Order.StopLimit, size=entry_size, price=price, plimit=stop)
            elif self.signal == "Buy":
                stop = self.tick + (self.tick  * .020 ) #=int(input("tell me the limit stop price, remember this is a "+self.signal+" signal: "))
                price = stop #int(input("tell me the buy/sell price: "))
                order = self.buy(self.datas[0], exectype=bt.Order.StopLimit, size=entry_size, price=price, plimit=stop) 

        return None   
        
    def mkt_stop(self): 
        if self.futures and self.signal=="Buy" and self.pos < 0:
            #if signal is buy, and we are shorting we close position.
            order = self.buy(self.datas[0], exectype=bt.Order.Stop, size=self.pos, price=self.tick+(10*self.tick/100), execInst='Close') #will have to find a way for simulating market with limit
            return None
        if self.signal=="Sell" and self.pos > 0:
            #if signal is sell, and we are longing we close position.
            order = self.sell(self.datas[0], exectype=bt.Order.Stop, size=self.pos, price=self.tick-(10*self.tick/100),execInst='Close') #will have to find a way for simulating market with limit
            return None
        #if no position open a new one
        if self.signal != "" and self.pos == 0 and not self.orders:  
            entry_size=self.entry()
            if self.futures and self.signal == "Sell":
                order = self.sell(self.datas[0], exectype=bt.Order.Stop, size=entry_size, price=self.tick-(10*self.tick/100))

            elif self.signal == "Buy":
                oid=1#order.ccxt_order['id']
                order = self.buy(self.datas[0], exectype=bt.Order.Stop, size=entry_size, price=self.tick+(10*self.tick/100),linkedOrder=oid) 
        return None    
        
        
    def mkt(self):
        #if no position open a new one
        if self.signal != "" and self.pos[0] == 0 and not self.orders:  
            self.open_pos(0)
        else:
            self.close_position(type = "manual", datas_num = 0)
        return None
   
