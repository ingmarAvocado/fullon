
class install_strategy():
    
    def __init__(self):
        return None
        
    def get_params(self):
        params=[]
        param={'name':'entryframe','type':'int','default':20}
        params.append(param)
        param={'name':'exitframe','type':'int','default':20}
        params.append(param)
        param={'name':'feed1','type':'select','options':'candles1m','default':'candles1m'}
        params.append(param)
        param={'name':'mktorder','type':'bool','default':False}
        params.append(param)
        return params
