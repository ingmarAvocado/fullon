from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals)
import sys
from time import sleep
import backtrader as bt
import backtrader.indicators as btind
import arrow
from libs import strategy as st
from libs import settings
from plugins import predictors as predictors


class strategy(st.strategy):

    params = (
        ('pred_name', ''),
        ('take_profit', 10),
        ('stop_loss', 3),
        ('timeout', 25),
        ('timeout_size', 1440),
        ('limit', 1)
    )

    def __local_del__(self):
        return None
        del self.pred

    def local_init(self):
        self.verbose = False
        self.fast_simul = True
        self.on_reboot_dry_open = False
        self.datas[0].fast_simul_candle = True
        self.pred = predictors.database_predictors()
        self.pred_name = self.p.pred_name
        self.prediction = 0
        self.bot_vars[0].append('prediction')
        self.bot_vars[0].append('pred_name')
        self.p.limit = float(self.p.limit)
        self.greenlight = True
        if not self.pred.valiate_prediction(predictor=self.pred_name):
            self.logger.warning(f"Predictor ({self.pred_name}) does not exist")
            raise bt.StrategySkipError
            #self.cerebro.runstop("Shit happened")
        return None

    def get_entry_signal(self, count=0):
        if self.str_test:
            return None
        curtime = bt.num2date(self.datas[1].datetime[0])
        p = self.pred.get_prediction(
            predictor=self.pred_name,
            ma=None,
            date=arrow.get(curtime),
            limit=1)
        entry = None
        if p:
            if p[0].prediction == 1:
                entry = "Buy"
            elif p[0].prediction == 0:
                entry = "Sell"
            self.prediction = p
        # We have to wait for a live prediction results. lets try getting it
        # for 2 min:
        elif not p and not self.simul:
            sleep(5)
            count += 1
            return self.get_entry_signal(count=count) if count < 24 else None
        self.entry_signal[0] = entry
        return None

    def risk_management(self):
        if self.str_test:
            return super().risk_management()
        # exit()
        if self.pos[0] > 0:
            if self.entry_signal[0] == "Sell":
                return self.close_position(reason="prediction", feed=0)
        if self.pos[0] < 0:
            if self.entry_signal[0] == "Buy":
                return self.close_position(reason="prediction", feed=0)
        # return self.update_trade_vars(0)
        return super().risk_management()

    # should we do a local_next?

    def local_next(self):
        if self.new_candle[1]:
            self.greenlight = True
        if self.greenlight:
            if self.entry_signal[0]:
                self.open_pos(0)
                self.greenlight = True
        return None
