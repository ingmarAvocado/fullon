from __future__ import (absolute_import, division, print_function, unicode_literals)
import sys
from time import sleep
import backtrader as bt
import backtrader.indicators as btind
import arrow
from libs import strategy as st, settings
from  plugins import predictors as predictors


class strategy(st.strategy):
    

    params = (
            ('pred_name',  ''),
            ('take_profit',5),
            ('stop_loss',4),
            ('timeout', 25),
            ('timeout_size', 480),
            ('limit',1)
        )

    def __local_del__(self):
        del self.pred


    def local_init(self):  
        self.verbose = False
        self.fast_simul = True
        self.datas[0].fast_simul_candle = True
        self.pred = predictors.database_predictors()
        self.pred_name = self.p.pred_name
        print(self.pred_name)
        self.prediction = 0
        self.bot_vars[0].append('prediction')
        self.bot_vars[0].append('pred_name')   
        self.p.limit = float(self.p.limit) 
        if not self.pred.valiate_prediction(predictor = self.pred_name): 
            self.logger.warning(f"Predictor ({self.pred_name}) does not exist")
            raise bt.StrategySkipError
            #self.cerebro.runstop("Shit happened")
        return None




    def get_entry_signal(self,  count = 0):
        if self.str_test: return None
        curtime = bt.num2date(self.datas[1].datetime[0])
        p = self.pred.get_prediction(predictor = self.pred_name, ma = None, date = arrow.get(curtime), limit = 1)
        entry = None
        if p:
            buy_limit = self.tick[0] * (self.p.limit + self.p.limit/100)
            #sell_limit = self.tick[0] - (self.tick[0]  *  self.p.limit /100 )
            sell_limit = self.tick[0] - (self.tick[0]  *  10 /100 )
            #print(f"tick ({self.tick[0]}) self prediction ({p[0].prediction}) buy limit ({buy_limit}) sell limit ({sell_limit})")
            if p[0].prediction >=  buy_limit:
                entry = "Buy"
            elif p[0].prediction <= sell_limit:
                entry =  "Sell"
                #print("finally?")
                #exit()
            self.prediction = p
        elif not p and not self.simul:# We have to wait for a live prediction results. lets try getting it for 2 min:
            sleep(5)
            count +=1
            return self.get_entry_signal(count = count) if count < 24 else  None
        self.entry_signal[0] = entry
        return None

    
    def risk_management(self):
        if self.str_test == True and  self.test_action: return super().risk_management()
        #print(self.curtime[0],self.pos[0],self.entry_signal[0])
        if self.new_candle[1]:
            if self.pos[0] > 0:
                if self.entry_signal[0] != "Buy": return self.close_position(type = "prediction", feed = 0)          
            if self.pos[0] < 0 :
                if self.entry_signal[0] != "Sell": return self.close_position(type = "prediction", feed = 0) 
            #return self.update_trade_vars(0)
        return super().risk_management()

    

    #should we do a local_next?
    def local_next(self):
        #print("next:",self.curtime[0], self.new_candle[1], self.entry_signal[0])
        if self.new_candle[1] or self.test_action:
            if self.entry_signal[0]:
                self.open_pos(0)
        return None
 
