"""
Describe strategy
"""
import backtrader as bt
import arrow
from typing import Optional
from libs.strategy import loader
import pandas_ta

#from libs.strategy import strategy as strat

# logger = log.setup_custom_logger('pairtrading1a', settings.STRTLOG)

strat = loader.strategy


class strategy(strat.Strategy):
    """description"""

    params = (
        ('take_profit', 5),
        ('stop_loss', 1),
        ('rsi_period', 14),
        ('rsi_upper', 70),
        ('rsi_lower', 30),
        ('printlog', False),
        ('bars', 30)
    )

    def local_init(self):
        """description"""
        self.p.rsi_upper = int(self.p.rsi_upper)
        self.p.rsi_lower = int(self.p.rsi_lower)
        self.verbose = False
        self.order_cmd = "spread"
        return None

    def local_next(self):
        """ description """
        if self.entry_signal[0]:
            if self.curtime[0] >= self.next_open:
                self.open_pos(0)

    def set_indicators_df(self):
        """
        A method to compute technical indicators and add them as new columns in the dataframe.

        For this particular implementation, we are computing and adding the following indicators:
        1. Relative Strength Index (RSI)


        Raises:
            ValueError: If 'high', 'low', or 'volume' columns are missing for computing ATR or volume volatility.
        """

        # Copy the 'close' column from OHLCV data into a new DataFrame
        self.indicators_df = self.datas[1].dataframe[['close']].copy()

        # Compute RSI and add it to the DataFrame
        self.indicators_df['rsi'] = pandas_ta.rsi(self.indicators_df['close'], length=self.p.rsi_period)

        # After all computations, handle NaN values introduced by the rolling window calculations
        self.indicators_df = self.indicators_df.dropna()

        # Return the updated DataFrame with the new indicators
        return self.indicators_df


    def set_indicators(self):
        rsi = self.indicators_df.loc[self.curtime[1].format('YYYY-MM-DD HH:mm:ss'), 'rsi']
        self.set_indicator('rsi', round(rsi, 2))

    def local_nextstart(self):
        """ Only runs once, before local_next"""
        self.next_open = self.curtime[0]

    def get_entry_signal(self):
        try:
            rsi = self.indicators.rsi
            if rsi < self.p.rsi_lower:  # if the RSI is less than the lower threshold
                self.entry_signal[0] = "Sell"

            elif rsi > self.p.rsi_upper:  # in the market & RSI greater than upper threshold
                self.entry_signal[0] = "Buy"

            else:
                self.entry_signal[0] = ""
        except KeyError:
            pass

    def risk_management(self):
        """
        Handle risk management for the strategy.
        This function checks for stop loss and take profit conditions,
        and closes the position if either of them are met.

        only works when there is a position, runs every tick
        """
        # Check for stop loss
        roi0 = self.roi_pct[0]
        reason = None
        if roi0 <= -abs(self.p.stop_loss):
            reason = "stop_loss"
        # Check for take profit
        if self.p.take_profit:
            if roi0 >= self.p.take_profit:
                reason = "take_profit"
        if reason:
            next_period = self.datas[1].time_to_ohlcv(current_time=self.curtime[0])
            self.next_open = self.curtime[0].shift(seconds=next_period)
            self.close_position(reason=reason, feed=0)
            self.entry_signal[0] = ""

    def event_in(self) -> Optional[arrow.Arrow]:
        """
        must use self.indicators_df
        """
        try:
            curtime = self.next_open.format('YYYY-MM-DD HH:mm:ss')
            query = f"(rsi < {self.p.rsi_lower} and \
                index >= '{curtime}') \
                or (rsi > {self.p.rsi_upper} and \
                index >= '{curtime}')"
            target = self.indicators_df.query(query).index[0]
            return arrow.get(str(target))
        except IndexError as error:
            if 'bounds' in str(error):
                return
            #print("aqui me dice que ya no hay records, pero si hay")
            #print(query)
            raise IndexError("Can't continue") from error
        except TypeError as error:
            return

    def event_out(self) -> Optional[arrow.Arrow]:
        """
        take profit and stop_loss are automatic
        """
        pass
