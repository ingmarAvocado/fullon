"""
Describe strategy
"""
import pandas
import decimal
import backtrader.indicators as btind
import backtrader as bt
import arrow
from typing import Union
from libs.strategy import loader
import pdb

#from libs.strategy import strategy as strat

# logger = log.setup_custom_logger('pairtrading1a', settings.STRTLOG)

strat = loader.strategy


class strategy(strat.Strategy):
    """description"""

    params = (('sma1', 45), ('bars', 45))

    def local_init(self):
        """description"""
        self.verbose = False
        #self.sema1 = btind.EMA(self.data1, period=10)

        return None

    def local_next(self):
        """ description """
        #print("\n--------------------------")
        # Access the last 10 values of the close line
        #for n in range(-9, 0):
        #    print("Esto andale: ", bt.num2date(self.datas[1].lines.datetime[n]), self.datas[1].lines.close[n])
        #print("Esto andale: ", bt.num2date(self.datas[1].lines.datetime[0]), self.datas[1].lines.close[0])
        # Print the last 10 close values
        #print("Time:", self.curtime[0])
        #print("Time:", self.curtime[1])
        for num, _ in enumerate(self.datas):
            if self.datas[num].timeframe == bt.TimeFrame.Ticks:
                if self.entry_signal[0]:
                    self.open_pos(num)

    def get_entry_signal(self):
        self.entry_signal[0] = None

    def risk_management(self):
        return super().risk_management()
