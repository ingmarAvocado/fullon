import sys
from libs import log
from libs.models import base_model as database
from libs.structs.symbol_struct import SymbolStruct
from typing import List, Optional
import psycopg2
import uuid


logger = log.fullon_logger(__name__)


class Database(database.Database):

    def remove_symbol(self, symbol: SymbolStruct) -> None:
        """
        Removes a symbol from the database.

        Args:
            symbol (str): The symbol to be removed.
            exchange (str, optional): The name of the exchange the symbol belongs to. If provided, it ensures that the symbol
                                      is removed only from the specified exchange. Defaults to None.

        Raises:
            psycopg2.DatabaseError: If an error occurs during the removal of the symbol.

        Returns:
            None
        """
        sql = f"DELETE FROM symbols WHERE symbol = '{symbol.symbol}' AND cat_ex_id = '{symbol.cat_ex_id}'"
        try:
            with self.con.cursor() as cur:
                cur.execute(sql)
                self.con.commit()
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            raise psycopg2.DatabaseError("Error removing symbol: " + str(error)) from error
        return

    def install_symbol(self, symbol: SymbolStruct) -> None:
        """
        Installs a symbol in the database.

        Args:
            symbol (SymbolStruct): A symbolstruct containing the symbol information.

        Raises:
            psycopg2.DatabaseError: If an error occurs during the installation of the symbol.

        Returns:
            None
        """
        if not symbol.symbol_id:
            symbol.symbol_id = str(uuid.uuid4())

        if not symbol.cat_ex_id:
            cat_ex_id = self.get_cat_exchanges(exchange=symbol.exchange_name)
            if cat_ex_id:
                cat_ex_id = cat_ex_id[0][0]
            else:
                raise ValueError("Couldnt find exchange on database")
        else:
            cat_ex_id = symbol.cat_ex_id

        futures = symbol.futures if hasattr(symbol, 'futures') else 'f'
        sql = """
            INSERT INTO symbols (
                symbol_id, symbol, cat_ex_id, updateframe,
                backtest, decimals, base, ex_base, futures
            ) VALUES (
                %s, %s, %s, %s, %s, %s, %s, %s, %s
            )
        """
        values = (
            symbol.symbol_id, symbol.symbol, cat_ex_id, symbol.updateframe,
            symbol.backtest, symbol.decimals, symbol.base, symbol.ex_base, futures
        )

        try:
            with self.con.cursor() as cur:
                cur.execute(sql, values)
                self.con.commit()
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            raise psycopg2.DatabaseError("Error installing symbol: " + str(error)) from error

        return None

    def get_symbol_decimals(self, symbol, cat_ex_id):
        sql = "SELECT decimals from symbols where  cat_ex_id ='"+cat_ex_id+"' and symbol ='"+symbol+"'"
        try:
            #print(sql)
            cur = self.con.cursor()
            cur.execute(sql)
            row =  cur.fetchone()
            cur.close()
            if row:
                return row[0]
            else:
                return 8
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(self.error_print(error = error, method = "get_symbol_decimals", query = sql))
            sys.exit()
        return None

    def get_symbols(self, exchange=None) -> List[SymbolStruct]:
        """
        Get a list of symbols from the database.

        Args:
            exchange (str): The name of the exchange to filter symbols by.

        Returns:
            List[StructSymbol]: A list of StructSymbol instances representing the symbols.
        """
        sql = """
              SELECT
                 public.symbols.symbol_id,
                 public.symbols.symbol,
                 public.symbols.cat_ex_id,
                 public.symbols.updateframe,
                 public.symbols.backtest,
                 public.symbols.decimals,
                 public.symbols.base,
                 public.symbols.ex_base,
                 public.symbols.only_ticker,
                 public.cat_exchanges.name as exchange_name,
                 public.cat_exchanges.ohlcv_view
              FROM
                 public.cat_exchanges
              INNER JOIN public.symbols
              ON public.cat_exchanges.cat_ex_id = public.symbols.cat_ex_id
        """
        params = None
        if exchange:
            sql += " WHERE public.cat_exchanges.name=%s"
            params = (exchange,)

        cur = self.con.cursor()
        try:
            cur.execute(sql, params)
            rows = cur.fetchall()
            symbols = []
            for row in rows:
                symbol = SymbolStruct(*row)
                symbols.append(symbol)
            cur.close()
            return symbols

        except (Exception, psycopg2.DatabaseError) as error:
            logger.error(self.error_print(
                error=error, method="get_symbols", query=sql))
            cur.close()
            raise

    def get_symbol(self, symbol: str, cat_ex_id: Optional[str] = None, exchange_name: Optional[str] = None) -> Optional[SymbolStruct]:
        """
        Get symbol information from the database.

        Args:
            symbol (str): The symbol to search for.
            cat_ex_id (Optional[str], optional): The cat_ex_id. Defaults to None.
            exchange_name (Optional[str], optional): The exchange name. Defaults to None.

        Returns:
            Optional[SymbolStruct]: Returns symbol information as a SymbolStruct instance or None if symbol is not found or both cat_ex_id and exchange_name are not provided.
        """
        if not cat_ex_id and not exchange_name:
            return None

        sql = """
            SELECT
                 public.symbols.symbol_id,
                 public.symbols.symbol,
                 public.symbols.cat_ex_id,
                 public.symbols.updateframe,
                 public.symbols.backtest,
                 public.symbols.decimals,
                 public.symbols.base,
                 public.symbols.ex_base,
                 public.symbols.only_ticker,
                 public.cat_exchanges.name as exchange_name,
                 public.cat_exchanges.ohlcv_view
            FROM
                public.cat_exchanges
            INNER JOIN public.symbols
            ON public.cat_exchanges.cat_ex_id = public.symbols.cat_ex_id
            WHERE symbol = %s
        """

        if exchange_name:
            sql += " AND public.cat_exchanges.cat_ex_id in (SELECT cat_ex_id FROM cat_exchanges WHERE name = %s)"
            params = (symbol, exchange_name)
        else:
            sql += " AND public.cat_exchanges.cat_ex_id = %s"
            params = (symbol, cat_ex_id)

        try:
            with self.con.cursor() as cur:
                cur.execute(sql, params)
                row = cur.fetchone()
            if row:
                return SymbolStruct(*row)
        except (Exception, psycopg2.DatabaseError) as error:
            error = "Error can't get_symbol, postgres says: " + str(error)
            logger.info(error)
            raise
