import sys
import psycopg2
from psycopg2.pool import ThreadedConnectionPool
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT
from libs import settings, log, cache
from libs.connection_pg_pool import create_connection_pool

logger = log.fullon_logger(__name__)


class Database():

    pool: ThreadedConnectionPool

    def __init__(self):
        self.pool = create_connection_pool()
        self.con = self.pool.getconn()
        self.cache = cache.Cache()
        return None

    def __del__(self):
        self.endthis()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.endthis()

    def endthis(self):
        try:
            self.pool.putconn(self.con)
            del self.pool
            del self.cache
            del self.con
        except AttributeError:
            pass
        except psycopg2.pool.PoolError:
            pass

    def error_print(self, error, method, query):
        error = "Error: " +str(error)
        error = error + "\nMethod "+method
        error = error + "\nQuery " +query
        return error

    def create_uuid_extension(self):
        sql = 'CREATE EXTENSION IF NOT EXISTS "uuid-ossp"'
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            cur.close()
        except:
            raise
        return True

    #gets exchanges read to be loaded to the bot
    def generate_uuid(self):
        sql="select uuid_generate_v4()"
        cur = self.con.cursor()
        try:
            cur.execute(sql)
            row = cur.fetchone()
            cur.close()
            return row[0] if row else  False
        except (Exception, psycopg2.DatabaseError) as error:
            logger.warning(self.error_print(error = error, method = "generate_uuid", query = sql))
            sys.exit()

    #gets an id from a table, probided a table a return field a validating field and the value of the validating field
    def get_id(self, table, ret_field, field,name):
        try:
            sql=("SELECT "+ret_field+" from "+table+" where "+field+"='"+name+"'")
            cur = self.con.cursor()
            cur.execute(sql)
            row =  cur.fetchone()
            cur.close()
            return row[0]
        except (Exception, psycopg2.DatabaseError) as error:
            error="Error cant get_id, postgres says: " +str(error)
            logger.info(error)
            raise
        return None
