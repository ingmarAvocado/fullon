from typing import List, Optional, Union, Tuple
import psycopg2
from psycopg2.extensions import AsIs, ISOLATION_LEVEL_AUTOCOMMIT, ISOLATION_LEVEL_DEFAULT
import time
import arrow
from libs import settings, log
from libs import database_helpers as dbhelpers
from libs.connection_pg_pool import create_connection_pool
from libs.structs.trade_struct import TradeStruct


logger = log.fullon_logger(__name__)


class Database:

    def __init__(self, exchange: str, symbol: str, simul: bool = False):
        self.exchange = exchange
        symbol = exchange + "_" + symbol.replace("/", "_")
        symbol = symbol.replace(":", "_")
        self.schema = symbol.replace("-", "_")
        self.con = ""
        self.simul = simul
        self.pool = create_connection_pool(database=settings.DBNAME_OHLCV)
        self.con = self.pool.getconn()
        return None

    def __del__(self):
        self.endthis()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, traceback):
        self.endthis()

    def endthis(self):
        try:
            self.pool.putconn(self.con)
            del self.pool
            del self.con
        except AttributeError:
            pass

    def fetch_ohlcv(self, table: str, compression: int, period: int, fromdate: str, todate: str) -> str:
        """
        Fetches OHLCV data from a PostgreSQL database.

        Args:
            table (str): The name of the table to fetch data from.
            compression (int): The compression factor for the time buckets.
            period (int): The period size for the time buckets.
            fromdate (str): The starting date for the data range (inclusive), in 'YYYY-MM-DD' format.
            todate (str): The ending date for the data range (inclusive), in 'YYYY-MM-DD' format.

        Returns:
            A list of tuples representing the OHLCV data. Each tuple contains:
            - The timestamp for the time bucket.
            - The opening price for the time bucket.
            - The highest price for the time bucket.
            - The lowest price for the time bucket.
            - The closing price for the time bucket.
            - The total trading volume for the time bucket.
        """
        # Determine column names based on table type
        if "trades" in table:
            open_col, high_col, low_col, close_col, vol_col = [
                "price", "price", "price", "price", "volume"]
        else:
            open_col, high_col, low_col, close_col, vol_col = [
                "open", "high", "low", "close", "vol"]

        # Construct SQL query
        sql = f"""
            SELECT time_bucket_gapfill('{compression} {period}', timestamp) AS ts,
            LOCF(FIRST({open_col}, "timestamp")) AS open,
            LOCF(MAX({high_col})) AS high,
            LOCF(MIN({low_col})) AS low,
            LOCF(LAST({close_col}, "timestamp")) AS close,
            COALESCE(SUM({vol_col}), 0) AS vol
            FROM {table}
            WHERE timestamp BETWEEN '{fromdate}' AND '{todate}'
            GROUP BY ts
            ORDER BY ts ASC
        """
        # Execute query and return results
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            rows = cur.fetchall()
            cur.close()
            return rows
        except psycopg2.DatabaseError as error:
            if cur:
                cur.close()
            self.con.rollback()
            raise ValueError(f"Failed to fetch OHLCV data with query: {sql}")

    def install_timescale(self):
        cur = self.con.cursor()
        try:
            logger.info("Installing timescaledb....")
            sql = 'CREATE EXTENSION IF NOT EXISTS timescaledb CASCADE;'
            cur.execute(sql)
            self.con.commit()
            del (cur)
            logger.info("timescaledb extension created")
            return True
        except (Exception) as error:
            logger.info(self.error_print(error=error, method="install_timescale_2", query=sql))
            del (cur)
        cur = self.con.cursor()
        try:
            sql = 'ALTER EXTENSION timescaledb UPDATE'
            cur.execute(sql)
            self.con.commit()
            logger.info("timescaledb updated")
            del (cur)
            return True
        except (Exception) as error:
            logger.info(self.error_print(error=error, method="install_timescale_1", query=sql))
            self.con.rollback()
            del (cur)

        return None
        # need to install timescaledb tools?

    def install_timescale_tools(self):
        return None
        cur = self.con.cursor()
        try:
            logger.info("\nInstalling timescaled tools....")
            sql = 'CREATE EXTENSION IF NOT EXISTS timescaledb_toolkit CASCADE;'
            cur.execute(sql)
            self.con.commit()
            del (cur)
            logger.info("timescaledb_tools extension created")
            return True
        except (Exception) as error:
            logger.info(
                self.error_print(
                    error=error,
                    method="install_timescale_tools_2",
                    query=sql))
            del (cur)
        cur = self.con.cursor()
        try:
            sql = 'ALTER EXTENSION timescaledb_toolkit UPDATE'
            cur.execute(sql)
            self.con.commit()
            logger.info("timescaledb_tools updated")
            del (cur)
            return True
        except (Exception) as error:
            logger.info(
                self.error_print(
                    error=error,
                    method="install_timescale_tools_1",
                    query=sql))
            self.con.rollback()
            del (cur)
        return None

    def error_print(self, error, method, query):
        error = "Error: " + str(error)
        error = error + "\nMethod " + method
        error = error + "\nQuery " + query
        return error

    def set_symbol(self, symbol):
        symbol = self.exchange + "_" + symbol.replace("/", "_")
        symbol = symbol.replace(":", "_")
        self.schema = symbol.replace("-", "_")
        return None

    def install_schema(self, ohlcv):
        if not self.table_exists():
            self.make_schema()
            self.make_trade_table()
            self.make_candle_table(ohlcv=ohlcv)

    def table_used(self, table='trades'):
        try:
            cur = self.con.cursor()
            # sql = f"select exists(select * from information_schema.tables where table_schema = '{self.schema.lower()}' and table_name='{table}')"
            sql = f"SELECT COUNT(*) FROM {self.schema.lower()}.trades"
            cur.execute(sql)
            r = cur.fetchone()[0]
            cur.close()
            del (cur)
            return True if r > 0 else False
        except (Exception, psycopg2.DatabaseError) as error:
            cur.close()
            del (cur)
            raise DatabaseError(f"Cant execute query {sql}")
        return False

    def table_exists(self, table: str = 'trades', schema: str = "") -> bool:
        if not schema:
            schema = self.schema
        try:
            cur = self.con.cursor()
            sql = f"select exists(select * from information_schema.tables where table_schema = '{schema.lower()}' and table_name='{table.lower()}')"
            cur.execute(sql)
            r = cur.fetchone()[0]
            cur.close()
            del (cur)
            return r
        except (Exception, psycopg2.DatabaseError) as error:
            cur.close()
            del (cur)
            raise DatabaseError(f"Cant execute query {sql}")
        except BaseException:
            raise
        return False

    def delete_schema(self):
        try:
            sql = "DROP SCHEMA %s CASCADE " % (self.schema)
            cur = self.con.cursor()
            cur.execute(sql)
            cur.close()
            self.con.commit()
            logger.info("Schema dropped")
            return True
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            cur.close()
        return False

    def delete_test_view(self, view_name):
        try:
            sql = f"DROP MATERIALIZED VIEW {view_name} CASCADE"
            cur = self.con.cursor()
            cur.execute(sql)
            cur.close()
            self.con.commit()
            logger.info("Test materialized view deleted")
            return True
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            cur.close()
            error = "Error cant delete_test_view, postgres says: " + str(error)
            logger.info(self.error_print(error=error, method="delete_test_view", query=sql))

            logger.info(error)
        return False

    def save_symbol_trades(self, data: List[TradeStruct]) -> None:
        """
        Save all trades from exchanges into a trade table.

        Args:
            data (List[Dict[str, Union[str, float]]]): List of trade data dictionaries.
            symbol (Optional[str], optional): Symbol for the trade table. Defaults to None.

        Returns:
            None
        """

        table = self.schema

        sql = """
        INSERT INTO %s.trades (timestamp, price, volume, side, type, ord)
        VALUES (%s, %s, %s, %s, %s, %s)
        ON CONFLICT (timestamp) DO NOTHING;
        """

        prepared_data = [(line.time, line.price, line.volume, line.side, line.order_type, line.ex_trade_id)
                         for line in data]

        try:
            cur = self.con.cursor()
            cur.executemany(sql, ([AsIs(table), *row] for row in prepared_data))
            self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            cur.close()
            logger.info(self.error_print(error=error, method="save_symbol_trades", query=sql))

    def make_schema(self):
        sql = "CREATE SCHEMA IF NOT EXISTS " + self.schema
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            self.con.commit()
            cur.close()
            del (cur)
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            logger.info(self.error_print(error=error, method="make_schema", query=sql))
            sys.exit()
        finally:
            return None

    def make_trade_table(self):
        sql = """
                CREATE TABLE IF NOT EXISTS %s.trades(
                    timestamp  TIMESTAMP NOT NULL PRIMARY KEY,
                    price DOUBLE PRECISION NOT NULL,
                    volume DOUBLE PRECISION NOT NULL,
                    side varchar(4) NOT NULL,
                    type varchar(1) NOT NULL,
                    ord varchar(32) NULL); """ % (self.schema)
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            self.con.commit()
            sql = f"SELECT create_hypertable('{self.schema}.trades','timestamp')"
            cur.execute(sql)
            self.con.commit()
            cur.close()
            logger.info("Trade hypertable created")
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            logger.info(self.error_print(error=error, method="make_trade_table", query=sql))
        finally:
            pass

        return True

    def make_candle_table(self, ohlcv=False):
        if ohlcv == "False":
            ohlcv = False
        if ohlcv:
            import base64
            base64_message = ohlcv
            base64_bytes = base64_message.encode('ascii')
            message_bytes = base64.b64decode(base64_bytes)
            sql = message_bytes.decode('ascii')
            sql = sql.replace('SCHEMA', self.schema)

        else:
            sql = """
                CREATE TABLE IF NOT EXISTS  %s.candles1m (
                    timestamp TIMESTAMP NOT NULL PRIMARY KEY,
                    open DOUBLE PRECISION NOT NULL,
                    high DOUBLE PRECISION NOT NULL,
                    low DOUBLE PRECISION NOT NULL,
                    close DOUBLE PRECISION NOT NULL,
                    vol DOUBLE PRECISION NOT NULL);""" % (self.schema)
        try:
            self.con.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
            cur = self.con.cursor()
            cur.execute(sql)
            self.con.set_isolation_level(ISOLATION_LEVEL_DEFAULT)
            if not ohlcv:
                sql = f"SELECT create_hypertable('{self.schema}.candles1m','timestamp')"
                cur.execute(sql)
                self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            logger.info(self.error_print(error=error, method="make_candle_tables", query=sql))
        finally:
            pass


    def get_latest_timestamp(self, table: str = "", table2: str = ""):
        if table2 and not table:
            sql = f'select max(timestamp) from {table2}'
        else:
            if self.table_used(table='trades') or not self.table_exists(
                    table="candles1m"):  # if trade table exists:
                table = "trades"
                sql = f'select max(timestamp) from {self.schema}.{table}'
            else:
                return None

        try:
            cur = self.con.cursor()
            cur.execute(sql)
            row = cur.fetchone()
            if row:
                values = row[0]
            cur.close()
            return values
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(self.error_print(error=error, method="get_latest_timestamp", query=''))

    def _get_oldest_timestamp(self):
        values = ""
        try:
            cur = self.con.cursor()
            table = "trades" if self.table_exists(table='trades') else "candles1m"
            sql = f'select min(timestamp) from {self.schema}.{table}'
            cur.execute(sql)
            row = cur.fetchone()
            if row:
                values = row[0]
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(self.error_print(error=error, method="get_oldest_timestamp", query=sql))
            sys.exit()
        finally:
            # print(values)
            return values

    def delete_before_midnight(self):
        if self.table_exists(table='trades'):
            return None
        ts = self._get_oldest_timestamp()
        if not ts:
            return None
        # print("ts:",ts,table)
        d1 = arrow.get(ts)
        hour = int(d1.format('HH'))
        minute = int(d1.format('mm'))
        basetime = d1.timestamp()

        if hour == 0 and minute == 0:
            return None
        add_hour = (23 - hour) * 60 * 60
        add_minute = (60 - minute) * 60
        delete_before = (basetime + add_hour + add_minute) - 1
        d1 = arrow.get(delete_before)
        delete_before = d1.format()
        try:
            cur = self.con.cursor()
            sql = "DELETE FROM %s.candles1m where timestamp < '%s'" % (self.schema, delete_before)
            cur.execute(sql)
            self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(self.error_print(error=error, method="delete_before_midnight", query=sql))
            pass
        return None

    def fill_candle_table(self, table: str, data: List[Union[dbhelpers.ohlcv, List]]) -> None:
        """
        Fills the candle table with provided OHLCV data.

        Args:
            table (str): The name of the table to fill.
            data (List[Union[dbhelpers.ohlcv, List]]): List of OHLCV data.

        Returns:
            None
        """

        if not self.table_used(table='trades'):
            data.pop()  # Remove the last minute as it is never fully filled.

            sql = """
            INSERT INTO %s (timestamp, open, high, low, close, vol)
            VALUES (%s, %s, %s, %s, %s, %s)
            ON CONFLICT (timestamp)
            DO UPDATE SET
                timestamp = EXCLUDED.timestamp,
                open = EXCLUDED.open,
                high = EXCLUDED.high,
                low = EXCLUDED.low,
                close = EXCLUDED.close,
                vol = EXCLUDED.vol;
            """

            prepared_data = []
            for line in data:
                if isinstance(line, list):
                    line = dbhelpers.ohlcv(t2=line)
                else:
                    line = dbhelpers.ohlcv(t1=line)

                prepared_data.append((line.ts, line.open, line.high, line.low, line.close, line.vol))

            try:
                cur = self.con.cursor()
                cur.executemany(sql, ([AsIs(f"{self.schema}.{table}"), *row] for row in prepared_data))
                self.con.commit()
                cur.close()
            except (Exception, psycopg2.DatabaseError) as error:
                logger.info(self.error_print(error=error, method="fill_candle_table", query=sql))
                sys.exit()

    def vwap(self, compression: int, period: str) -> List[Tuple[str, float]]:
        """
        Fetches VWAP data from a PostgreSQL database.

        Args:
            compression (int): The compression factor for the time buckets.
            period (str): The period size for the time buckets, e.g., 'minutes', 'hours'.

        Returns:
            A list of tuples representing the VWAP data. Each tuple contains:
            - The timestamp for the time bucket.
            - The VWAP for the time bucket.
        """
        price_col, vol_col = "price", "volume"
        table = self.schema + ".trades"
        todate = arrow.utcnow()
        match period.lower():
            case 'minutes':
                fromdate = todate.shift(minutes=-compression*8)
            case 'hours':
                fromdate = todate.shift(hours=-compression*8)
            case 'days':
                fromdate = todate.shift(days=-compression*8)
            case _:
                raise ValueError(f"Unsupported period: {period}")

        sql = f"""
            SELECT time_bucket_gapfill('{compression} {period}', timestamp) AS ts,
                   SUM({price_col} * {vol_col}) / SUM({vol_col}) as vwap
            FROM {table}
            WHERE timestamp BETWEEN '{fromdate}' AND '{todate}'
            GROUP BY ts
            ORDER BY ts ASC
        """
        try:
            with self.con.cursor() as cur:
                cur.execute(sql)
                rows = cur.fetchall()
                return rows
        except psycopg2.DatabaseError as error:
            self.con.rollback()
            raise error

    def twap(self, compression: int, period: str) -> List[Tuple[str, float]]:
        """
        Fetches TWAP data from a PostgreSQL database.

        Args:
            compression (int): The compression factor for the time buckets.
            period (str): The period size for the time buckets, e.g., 'minutes', 'hours'.

        Returns:
            A list of tuples representing the TWAP data. Each tuple contains:
            - The timestamp for the time bucket (arrow.Arrow).
            - The TWAP for the time bucket (Decimal).
        """
        price_col = "price"
        table = self.schema + ".trades"
        todate = arrow.utcnow()
        match period.lower():
            case 'minutes':
                fromdate = todate.shift(minutes=-compression*8)
            case 'hours':
                fromdate = todate.shift(hours=-compression*8)
            case 'days':
                fromdate = todate.shift(days=-compression*8)
            case _:
                raise ValueError(f"Unsupported period: {period}")

        sql = f"""
            SELECT time_bucket_gapfill('{compression} {period}', timestamp) AS ts,
                   AVG({price_col}) as twap
            FROM {table}
            WHERE timestamp BETWEEN '{fromdate}' AND '{todate}'
            GROUP BY ts
            ORDER BY ts ASC
        """

        try:
            with self.con.cursor() as cur:
                cur.execute(sql)
                rows = cur.fetchall()
                return rows
        except (TypeError, psycopg2.DatabaseError) as error:
            logger.error(f"Failed to get TWAP data: {error}")
            return []
