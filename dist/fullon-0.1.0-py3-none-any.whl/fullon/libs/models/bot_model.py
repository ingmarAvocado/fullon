import psycopg2
import arrow
from libs import log
from libs import database_helpers as dbhelpers
from libs.models import trades_model as database
from typing import List, Dict, Optional
import uuid

logger = log.fullon_logger(__name__)


class Database(database.Database):

    # gets the params from an strategy set by a user
    def get_str_feeds(self, bot_id: str) -> List:
        """doc"""
        sql = f"""SELECT DISTINCT
                    public.exchanges.ex_id,
                    public.feeds.period,
                    public.feeds.compression,
                    public.feeds.order as feed_order,
                    public.cat_exchanges.name as exchange_name,
                    public.cat_exchanges.cat_ex_id,
                    public.symbols.symbol,
                    public.symbols.base,
                    public.symbols.futures,
                    public.symbols.ex_base
                FROM
                    public.cat_exchanges
                    INNER JOIN public.symbols
                        ON public.cat_exchanges.cat_ex_id = public.symbols.cat_ex_id
                    INNER JOIN public.feeds
                        ON public.symbols.symbol_id = public.feeds.symbol_id
                    INNER JOIN public.exchanges
                        ON public.cat_exchanges.cat_ex_id = public.exchanges.cat_ex_id
                    INNER JOIN public.bot_exchanges
                        ON public.bot_exchanges.ex_id = public.exchanges.ex_id
                WHERE
                    feeds.bot_id = '{bot_id}' and bot_exchanges.bot_id= '{bot_id}'
                    ORDER by feed_order ASC"""
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            rows = []
            for row in cur.fetchall():
                rows.append(dbhelpers.reg(cur, row))
            cur.close()
            return rows
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(
                self.error_print(
                    error=error,
                    method="get_str_feeds",
                    query=sql))
            if cur:
                cur.close()
            return []

    def add_exchange_to_bot(self, bot_id: str, exchange: dict) -> bool:
        """
        Add an exchange to a bot.

        Args:
            bot_id (str): The bot ID.
            exchange (dict): A dictionary containing the exchange details.

        Returns:
            bool: True if the operation is successful, otherwise an exception is raised.

        Raises:
            psycopg2.DatabaseError: If an error occurs while inserting the exchange.
        """
        exchange_id = exchange['exchange_id']
        sql = f"""INSERT INTO bot_exchanges VALUES('{bot_id}','{exchange_id}')"""
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            cur.close() if cur else cur
            logger.warning(
                self.error_print(
                    error=error,
                    method="add_bot",
                    query=sql))
            raise
        return True

    def get_last_bot_log(self, bot_id, last_candle, feed_num):
        sql = f"SELECT message FROM  bot_log  where bot_id='{bot_id}' and feed_num = {feed_num} and timestamp > '{last_candle}' order by timestamp desc limit 1" 
        #print(sql)
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            row =  cur.fetchone()
            cur.close()
            if row:
                return row[0]
            else:
                return ""
        except (Exception, psycopg2.DatabaseError) as error:
            logger.info(self.error_print(error = error, method = "get_last_bot_log", query = sql))
            raise
        return None

    def save_bot_log(self, bot_id, message, feed_num):
        sql = f"INSERT INTO bot_log (bot_id, feed_num, message, timestamp) VALUES ('{bot_id}', {feed_num},'{message}', '{arrow.utcnow().format()}')"
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            self.con.commit()
            cur.close()
            return True
        except (Exception, SyntaxError) as error:
            logger.info(self.error_print(error = error, method = "save_bot_log", query = sql))
            raise
        return None

    def get_trading_currency(self, bot_id, ex_id, symbol):
        sql = f"""SELECT symbols.base 
                FROM bots 
                INNER JOIN bot_exchanges  ON bots.bot_id = bot_exchanges.bot_id 
                INNER JOIN symbols
                ON bot_exchanges.symbol_id = symbols.symbol_id
                WHERE bots.bot_id = '{bot_id}' and bot_exchanges.ex_id = '{ex_id}' and symbols.symbol = '{symbol}'
                """
        try:            
            cur = self.con.cursor()
            cur.execute(sql)
            row =  cur.fetchone()
            cur.close()
            if row:
                return row[0]
            else:
                return []
        except (Exception, psycopg2.DatabaseError) as error:
            error="Error cant get_currency postgres says: " +str(error)
            logger.info(error)
            raise

    def add_bot(self, bot: dict) -> str:
        """
        Add a bot to the database.

        Args:
            bot (dict): A dictionary containing the bot details.

        Returns:
            str: The bot ID if the operation is successful, otherwise an exception is raised.

        Raises:
            psycopg2.DatabaseError: If an error occurs while inserting the bot.
        """
        bot_id = f"{bot['bot_id']}" if 'bot_id' in bot else str(uuid.uuid4())
        uid = f"(select uid from users where mail='{bot['user']}')"
        str_id = f"(select str_id from strategies where uid={uid} and  name='{bot['str_name']}')"
        sql = f"""INSERT INTO bots VALUES('{bot_id}',{uid}, {str_id},'{bot['name']}',{bot['dry_run']},{bot['active']})"""
        cur = None
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            if cur:
                del (cur)
            if 'not-null' in str(error):
                error = "some of the parameters of the Bot are wrong, maybe the exchange, or maybe there is no strategy\n" + \
                    str(error)
            logger.warning(
                self.error_print(
                    error=error,
                    method="add_bot",
                    query=sql))
            raise
        return bot_id

    def get_bot_timestamp(self, bot_id):
        sql = """SELECT timestamp from bots where bot_id='%s'""" % (bot_id)
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            rows = []
            for row in cur.fetchall():
                rows.append(dbhelpers.reg(cur, row))
            cur.close()
            return rows[0].timestamp
        except (Exception, psycopg2.DatabaseError) as error:
            logger.warning(
                self.error_print(
                    error=error,
                    method="get_bot_timestamp",
                    query=sql))
            sys.exit()

    def edit_bot(self, bot):
        bot_id = bot['bot_id']
        sql = "UPDATE bots  SET "
        for key, value in bot.items():
            if key == 'str_id':
                sql = sql + key+"='"+value+"', "
            if key == 'dry_run':
                sql = sql + key+"='"+value+"', "
        sql = sql.rstrip(', ')
        sql  =  sql +" WHERE bot_id='%s'" %(bot_id)
        #print (sql)
        try:
            cur = self.con.cursor()
            cur.execute(sql)
            self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            error="Error cant edit bot: " +str(error)
            logger.info(error)
            raise
        return None

    def get_bot_list(self, uid: Optional[str] = None, bot_id: Optional[str] = None, active: bool = False) -> Optional[List[Dict[str, str]]]:
        """
        Fetches bot list from the database.

        Args:
            uid: User ID.
            bot_id: Bot ID.
            active: Fetch active bots only.

        Returns:
            A list of dictionaries containing bot details or None if an error occurred.
        """
        cur: Optional[PgCursor] = None
        try:
            cur = self.con.cursor()

            if uid:
                sql = "SELECT * FROM bots WHERE uid = %s"
                cur.execute(sql, (uid,))
            elif bot_id:
                sql = "SELECT * FROM bots WHERE bot_id = %s"
                cur.execute(sql, (bot_id,))
            elif active:
                sql = "SELECT * FROM bots WHERE active = 't'"
                cur.execute(sql)
            else:
                sql = "SELECT * FROM bots"
                cur.execute(sql)

            rows = [dbhelpers.reg(cur, row) for row in cur.fetchall()]
            return rows
        except (Exception, psycopg2.DatabaseError) as error:
            if "current transaction is aborted" in str(error):
                return None
            logger.info(self.error_print(error=error, method="get_bot_list", query=sql))
        finally:
            if cur is not None:
                cur.close()

    def get_feed_id(self, symbol_id: str, period: str, compression: str) -> str:
        """
        Retrieve the feed_id for a specific symbol, period and compression from the database.

        Args:
            symbol_id (str): The symbol_id of the feed.
            period (str): The period of the feed.
            compression (str): The compression of the feed.

        Returns:
            str: The feed_id if found, otherwise an empty string.

        Raises:
            psycopg2.DatabaseError: If an error occurs while retrieving the feed_id from the database.
        """
        sql = """
            SELECT feed_id FROM feeds
            WHERE symbol_id = %s AND period = %s AND compression = %s
        """
        data = (symbol_id, period, compression)

        try:
            with self.con.cursor() as cur:
                cur.execute(sql, data)  # Use SQL parameter substitution
                rows = [dbhelpers.reg(cur, row) for row in cur.fetchall()]

            return rows[0].feed_id if rows else ''

        except (Exception, psycopg2.DatabaseError) as error:
            logger.warning(self.error_print(error=error, method="get_feed_id", query=sql))
            raise

    def add_feed_to_bot(self, feed: dict) -> bool:
        """
        Add a feed to a strategy.

        Args:
            feed (dict): A dictionary containing feed details.

        Returns:
            bool: True if the operation is successful, otherwise an exception is raised.

        Raises:
            psycopg2.DatabaseError: If an error occurs while inserting the feed.
        """
        feed_id = uuid.uuid4()
        if not feed_id:
            raise ValueError("No feed id provided")
        sql = """
            INSERT INTO public.feeds (feed_id, bot_id, symbol_id, period, compression, "order")
            VALUES (uuid_generate_v4(), %s, %s, %s, %s, %s)
        """
        data = (feed['bot_id'], feed['symbol_id'], feed['period'], feed['compression'], feed['order'])
        cur = None
        try:
            cur = self.con.cursor()
            cur.execute(sql, data)  # Use SQL parameter substitution
            self.con.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            self.con.rollback()
            if cur:
                cur.close()  # Use close instead of del
            logger.warning(
                self.error_print(
                    error=error,
                    method="add_feed_to_bot",
                    query=sql))
            raise
        return True
