"""
description
"""
from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals)
import itertools
from collections import deque
import pandas
import arrow
import backtrader as bt
from libs.btrader.fullonsimfeed import FullonSimFeed


# from libs import settings

MAX_TRADE_DAYS = 180  # days


class FullonEventFeed(FullonSimFeed):
    """ Fullon Fast Sim for event base simul, fast but need to double check"""
    event_timeout = None

    def _load(self):
        """Description"""
        # if its a live queue
        if self._state == self._ST_HISTORY:
            self._fetch_ohlcv()
            self._load_ohlcv()
            return True
        if self._state == self._ST_OVER:
            return False
        return False

    def _next_timeout(self, cur_time: str) -> arrow.Arrow:
        """
        Determine the time of the next timeout.

        If a timeout has been set, it will be used. Otherwise, the timeout will
        be set to 180 days after the current time.

        Parameters:
        - cur_time (str): The current time.

        Returns:
        - arrow.Arrow: The time of the next timeout.
        """
        if self.timeout:
            timeout = arrow.get(self.timeout)
        else:
            timeout = arrow.get(cur_time).shift(days=MAX_TRADE_DAYS)
        return timeout

    def get_event_date(self,
                       event: str,
                       price: float,
                       cur_ts: arrow.Arrow,
                       limit: arrow.Arrow = None) -> arrow.Arrow:
        """
        Get the timestamp of the first occurrence of the given
        event within the specified time range.
        Parameters:
            event (str): The name of the event to check for.
                Can be either "take_profit" or "stop_loss".
            cur_ts (datetime.datetime): The start of the time range in which to
                search for the event.
            limit (str, optional): The end of the time range in which to search
                for the event.   Defaults to the next timeout.
        Returns:
            arrow: The timestamp of the first occurrence of the event
            within the specified time range.
        """
        if not limit:
            limit = self._next_timeout(cur_time=cur_ts)
        cur_ts = pandas.to_datetime(cur_ts.format('YYYY-MM-DD HH:mm:ss'))
        limit = pandas.to_datetime(limit.format('YYYY-MM-DD HH:mm:ss'))
        df_ohlcv = self.dataframe.loc[cur_ts:limit]
        match event:
            case "take_profit":
                if self.pos > 0:
                    date_ohlcv = df_ohlcv.loc[df_ohlcv['close'] >= price]
                else:
                    date_ohlcv = df_ohlcv.loc[df_ohlcv['close'] < price]
            case "stop_loss":
                if self.pos > 0:  # Stoping a Long
                    date_ohlcv = df_ohlcv.loc[df_ohlcv['close'] <= price]
                else:  # stoping a short
                    date_ohlcv = df_ohlcv.loc[df_ohlcv['close'] > price]
        try:
            return_date = arrow.get(date_ohlcv.index[0])
        except (IndexError, UnboundLocalError):
            # return_date = arrow.get(self.params.mainfeed.result[-2][0])
            # pylint-disable: no-member
            return_date = arrow.get(bt.num2date(self.last_moments))
        return return_date

    @staticmethod
    def _slice_deque(ddeque: deque, start: int, stop: int) -> deque:
        """
        Given a deque, rotate the deque to the left by the given start
        position, slice the deque from start to stop
        and return the sliced deque.
        """
        ddeque.rotate(-start)
        mslice = list(itertools.islice(ddeque, 0, stop - start))
        mslice.pop()
        return deque(mslice)

    def _load_ohlcv(self):
        """Description"""
        one_row = self._jump_to_next_event()
        try:
            self._load_ohlcv_line(one_row=one_row)
        except:
            import ipdb
            ipdb.set_trace()
        if len(self.result) == 0:
            self._empty_bar()
        return True

    def _jump_to_next_event(self) -> list:
        """
        Determine the next event and jump to it.
        Sometimes this means we do a single step, which is necessary when
        opening and closing a position.

        Returns:
        list: The next event in the queue, or an empty list if the queue is empty.
        """
        # Read the first event in the list
        # Initialize steps to 0
        steps = 0
        event = self.result.popleft()
        if not self.event_timeout:
            return event
        if self.event_timeout.timestamp() < arrow.get(event[0]).timestamp():
            return event
        steps = (self.event_timeout.timestamp() -
                 arrow.get(event[0]).timestamp()) / self.time_factor
        # Get the size of the result_tick list
        size = len(self.result)
        # because we poped an element to the list, we need to account for it.
        # we use int to round down a float. Steps must be int.
        steps = int(steps) - 1
        if steps <= 0:
            return event
        # compression({self._compression}) event({event[0]}) last_event {self.result[-1][0]}")
        if size <= steps:
            return event
            raise Exception("This should not be happening")
        self.event_timeout = None
        self.result = self._slice_deque(self.result, steps, size + 1)
        return self.result.popleft() if self.result else []
