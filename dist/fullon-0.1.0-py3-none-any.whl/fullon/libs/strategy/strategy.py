"""
description
"""
from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals)
import backtrader as bt
import arrow
from libs import log
from libs.btrader.fullonbroker import FullonBroker
from libs.database import Database
import pandas
from typing import List, Optional, Dict
import json

logger = log.fullon_logger(__name__)


class indicators():
    pass


class Strategy(bt.Strategy):
    """ description """

    verbose = False

    params = (
        ('helper', None),
        ('mktorder', True),
        ('take_profit', False),
        ('stop_loss', False),
        ('rolling_stop', False),
        ('trailing_stop', False),
        ('timeout', False),
        ('timeout_size', 0),
        ('size_pct', 10),
        ('leverage', 1)
    )

    pos = {}
    pos_price = {}
    roi_pct = {}
    anypos = 0
    tick = {}
    curtime = {}
    cash = {}
    totalfunds = {}
    last_candle_date = {}
    new_candle = {}
    orders = {}
    bot_vars = {}
    entry_signal = {}
    take_profit = {}
    stop_loss = {}
    timeout = {}
    feed_timeout = {}
    lastclose = {}
    rolling_stop = {}
    trailing_stop = {}
    order_placed = False
    indicators_df: pandas.DataFrame = pandas.DataFrame()
    prev_trade_info: Dict = {}
    indicators: object = indicators()

    def __init__(self):
        """ description """
        self.last_candle_date = {}
        self.dbase = Database()
        self.helper = self.p.helper
        self.dry_run = self.helper.dry_run
        self.first = True
        self.order_cmd = "process_now"
        self.on_exchange = False
        """
        for some reason parameters come as  int or string, turning them into float
        """

        self.p.take_profit = False if self.p.take_profit == 'false' else self.p.take_profit
        self.p.stop_loss = False if self.p.stop_loss == 'false' else self.p.stop_loss
        self.p.rolling_stop = False if self.p.rolling_stop == 'false' else self.p.rolling_stop
        self.p.trailing_stop = False if self.p.trailing_stop == 'false' else self.p.trailing_stop

        if self.p.timeout == "false":
            self.p.timeout = False

        if self.p.take_profit:
            self.p.take_profit = float(self.p.take_profit)
        if self.p.stop_loss:
            self.p.stop_loss = float(self.p.stop_loss)
        if self.p.rolling_stop:
            self.p.rolling_stop = float(self.p.rolling_stop)
        if self.p.trailing_stop:
            self.p.trailing_stop = float(self.p.trailing_stop)
            self.p.stop_loss = False
            self.p.rolling_stop = False
        try:
            self.p.size_pct = float(self.p.size_pct)
            self.p.leverage = float(self.p.leverage)
        except ValueError:
            exit("Bad parameter")

        """
        each feed should have its own bot_vars variable according to its feed parameters
        """

        for n in range(0, len(self.datas)):
            self.bot_vars[n] = ['time', 'status', 'take_profit', 'timeout']
            self.bot_vars[n].append('stop_loss') if self.p.stop_loss else None
            self.bot_vars[n].append(
                'rolling_loss') if self.p.stop_loss else None
            self.bot_vars[n].append(
                'trailing_stop') if self.p.stop_loss else None
            if self.p.timeout and self.p.timeout != "false":
                if not self.p.timeout_size:
                    logger.error(
                        f"timeout is on, but there is no timeout_size for bot_id {self.helper.id}")
                    exit()
                # *60 because it must be in seconds
                self.feed_timeout[n] = self.p.timeout_size * \
                    int(self.p.timeout) * 60
            try:
                self.datas[n].feed.trading
            except AttributeError:
                class feed:
                    trading = False
                setattr(self.datas[n], "feed", feed)

        self.exectype = bt.Order.Limit if int(
            self.params.mktorder) == 0 else bt.Order.Market
        # edit if you want to close open trades on database and open new ones?
        self.nextstart_done = False
        self.local_init()
        for feed in range(0, len(self.datas)):
            self.entry_signal[0] = None
        for num, data in enumerate(self.datas):
            if data.timeframe == bt.TimeFrame.Ticks:
                self.prev_trade_info[num]: Dict[str, Union[int, float, str]] = {}
        return None

    def __del__(self):
        """ description """
        return None

    def set_indicators_df(self):
        pass

    def set_brokers(self) -> None:
        """
        Initializes and sets the brokers for each data feed.

        Returns:
            None
        """
        self.brokers: List[bt.Broker] = []
        for i, data in enumerate(self.datas):
            if self.dry_run:
                broker = bt.brokers.BackBroker()
                broker.setcash(10000)
                broker.setcommission(
                    commission=0.001,
                    margin=None,
                    mult=1,
                    interest=.001
                )
            else:
                broker = FullonBroker(feed=data.feed)
            self.datas[i].broker = broker

    def feeds_have_futures(self):
        """ check if a trading feed supports futures """
        for num, data in enumerate(self.datas):
            if data.timeframe == bt.TimeFrame.Ticks:
                if not data.feed.futures:
                    return False
        return True

    def local_init(self):
        """ description """
        pass

    def nextstart(self):
        if not self._check_datas_lengths():
            logger.error("Check your feeds as they are not all equal in size")
            logger.info("Maybe you want to update ohlcv for the corresponding symbols")
            exit()

    def next(self):
        """ description """
        pass

    def end_next(self):
        pass

    def local_nextstart(self):
        pass

    def _check_datas_lengths(self):
        lengths = []
        for num, datas in enumerate(self.datas):
            if self.datas[num].timeframe == bt.TimeFrame.Ticks:
                lengths.append(len(self.datas[num].result))
        first_length = lengths[0]
        for length in lengths[1:]:
            if length != first_length:
                msg = "Lowest time frame (usually 1min) need to measure the same. Dont forget to remove pickle files "
                logger.error(msg)
                return False
        return True

    def _state_variables(self) -> None:
        """
        Sets various state variables based on the current position and data feed.

        Returns:
            None
        """
        any_pos: int = 0
        for num, datas in enumerate(self.datas):
            if self.datas[num].feed.trading:
                position = self.getposition(datas)
                self.pos[num] = position.size
                self.pos_price[num] = position.price
                self.tick[num] = datas.close[0]
                if self.pos[num] > 0:
                    self.roi_pct[num] = round((self.tick[num] - self.pos_price[num]) / self.pos_price[num] * 100, 2)  # if long
                elif self.pos[num] < 0:
                    self.roi_pct[num] = round((self.pos_price[num] - self.tick[num]) / self.pos_price[num] * 100, 2)  # if short
                else:
                    self.roi_pct[num] = None
                self.cash[num] = self.broker.getcash()
                self.totalfunds[num] = self.broker.getvalue()
                if position.size != 0:
                    any_pos = 1
            self.curtime[num] = arrow.get(bt.num2date(datas.datetime[0]))
            self.new_candle[num] = self._is_new_candle(feed=num)
        self.anypos = any_pos
        self.set_indicators()
        self.get_entry_signal()

    def set_indicator(self, name: str, value: str) -> None:
        """
        sets object self.indicator with a new attribute name, with value value
        Args:
            name (str): Name of the attribute.
            value (str): value of the attribure
        """
        setattr(self.indicators, name, value)

    def set_indicators(self):
        pass

    def _print_position_variables(self, feed: int) -> None:
        """
        Prints the current position variables for a given data feed.

        Args:
            feed (int): The index of the data feed.

        Returns:
            None
        """
        print("----------------------------")
        print(f"Feed: {feed}, Exchange: {self.datas[feed].feed.exchange_name} symbol: {self.datas[feed].symbol}")
        print(f"Loop: {self.datas[0].buflen()}")
        print("Tick: ", self.tick[feed])
        print("Date: ", self.curtime[feed])
        print("Availabe Balance: ", self.cash[feed])
        print("Total Balance: ", self.totalfunds[feed])
        print("Pos: ", self.pos[feed])
        try:
            print("Entry Signal: ", self.entry_signal[feed])
        except (AttributeError, KeyError) as error:
            print("Entry Signal: ", "N/A for this feed")
        print("New Candle: ", self.new_candle[feed])
        if self.pos[feed]:
            try:
                print("Profit: ", self.take_profit[feed])
                print("Stop: ", self.stop_loss[feed])
                print("Rolling Stop: ", self.rolling_stop[feed])
                print("Trailing Stop: ", self.trailing_stop[feed])
            except KeyError:
                print("No stops for feed: ", feed)
            if feed in self.timeout:
                print("Timeout: ", self.timeout[feed])
        print("----------------------------")

    def _load_bot_vars(self):
        """ description """
        bot_vars = {}
        for n in range(0, len(self.datas)):
            last_candle = bt.num2date(self.datas[n].datetime[0])
            bot_vars[n] = self.dbase.get_last_bot_log(
                bot_id=self.helper.id, last_candle=last_candle, feed_num=n)
            if bot_vars[n]:
                try:
                    bot_vars[n] = json.loads(bot_vars[n])
                    for key in bot_vars[n]:
                        if key != "time":
                            setattr(self, key, bot_vars[n][key])
                except BaseException:
                    raise
                    pass
            return None

    def _get_bot_vars(self, feed_num, action=None):
        """ description """
        t0 = arrow.utcnow().format()
        bot_vars = {"time": t0}

        for key in vars(self):
            try:
                if key in self.bot_vars:
                    bot_vars.update({key: vars(self)[key]})
            except KeyError:
                pass
        if action:
            bot_vars.update({'_action': action})
        bot_vars = json.dumps(bot_vars, indent=4, sort_keys=True)
        return bot_vars

    def check_input_params(self):
        """ description """
        params = dict(vars(self.p))
        del (params['timeout'])
        del (params['mktorder'])
        del (params['take_profit'])
        del (params['stop_loss'])
        del (params['rolling_stop'])
        del (params['trailing_stop'])
        try:
            del (params['helper'])
        except BaseException:
            pass
        for p in params:
            if params[p] == 0:
                logger.info(
                    "Input params contains at least a zero, program may or may not run")
                logger.info("Zero at: %s", p)
                return False
        return True

    def risk_management(self):
        """ description """
        result = False
        for num in range(0, len(self.datas)):
            if self.datas[num].timeframe == bt.TimeFrame.Ticks:
                if self.pos[num] != 0:
                    # If timeout reached, then get out.
                    if self.p.timeout and num in self.timeout:
                        if self.timeout[num] <= self.curtime[num].timestamp():
                            self.close_position(reason="timeout", feed=num)
                            continue
                    # if handling auto orders for risk management on exchange
                    if self.on_exchange:
                        continue
                        # will need to check with exchange
                        # if orders are set properly, good.
                        # if not set/reset them.
                    # if bot does not open orders, it will market buy/sell when
                    # targets reached.
                    else:
                        if self.pos[num] > 0:
                            self._risk_mgmt_long(feed=num)
                        else:
                            self._risk_mgmt_short(feed=num)
        return result

    def _risk_mgmt_long(self, feed: int) -> None:
        """
        Manages risk for long positions by checking and applying various risk management
        techniques such as take profit, stop loss, trailing stop, and rolling stop.        
        Args:
            feed (int): The feed index to manage risk for.
        """
        # Check if take profit is enabled and if the current tick price has reached
        # or exceeded the take profit value, then close the position and return.
        if self.p.take_profit:
            if self.tick[feed] >= self.take_profit[feed]:
                self.close_position("take_profit", feed=feed)
                return

        # Check if stop loss is enabled and if the current tick price has reached
        # or dropped below the stop loss value, then close the position and return.
        if self.p.stop_loss:
            if self.tick[feed] <= self.stop_loss[feed]:
                self.close_position(reason="stop", feed=feed)
                return

        # Check if a trailing stop is defined for this strategy
        if self.p.trailing_stop:
            # Calculate the trailing stop value for the current feed.
            # This is done by subtracting a percentage (self.p.trailing_stop)
            # of the current tick price (self.tick[feed]) from the current tick price.
            trailing_stop = self.tick[feed] - \
                self.tick[feed] * self.p.trailing_stop / 100

            # Update the trailing stop for the feed with the maximum value
            # between the calculated trailing stop and the existing trailing stop.
            # This ensures the trailing stop only moves in one direction.
            self.trailing_stop[feed] = max(trailing_stop, self.trailing_stop[feed])

            # Check if the current tick price has reached or gone below the
            # trailing stop value. If it has, close the position and return.
            if self.tick[feed] <= self.trailing_stop[feed]:
                self.close_position(reason="trail", feed=feed)
                return

        # Check if a rolling stop is defined for this strategy
        # and the current tick price is greater than the rolling stop value
        if self.p.rolling_stop and self.tick[feed] > self.rolling_stop[feed]:
            # Calculate the stop loss value by subtracting a percentage (self.p.stop_loss)
            # of the current tick price (self.tick[feed]) from the current tick price.
            self.stop_loss[feed] = self.tick[feed] - \
                self.tick[feed] * self.p.stop_loss / 100

            # Calculate the new rolling stop value by adding a percentage (self.p.rolling_stop)
            # of the current tick price (self.tick[feed]) to the current tick price.
            self.rolling_stop[feed] = self.tick[feed] + \
                self.tick[feed] * self.p.rolling_stop / 100

    def _risk_mgmt_short(self, feed: int) -> None:
        """
        Manages risk for short positions by checking and applying various risk management
        techniques such as take profit, stop loss, trailing stop, and rolling stop.
        Args:
            feed (int): The feed index to manage risk for.
        """
        # Check if take profit is enabled and if the current tick price has reached
        # or dropped below the take profit value, then close the position and return.
        if self.p.take_profit:
            if self.tick[feed] <= self.take_profit[feed]:
                self.close_position(reason="profit", feed=feed)
                return

        # Check if stop loss is enabled and if the current tick price has reached
        # or exceeded the stop loss value, then close the position and return.
        if self.p.stop_loss:
            if self.tick[feed] >= self.stop_loss[feed]:
                self.close_position(reason="stop", feed=feed)
                return

        # Check if a trailing stop is defined for this strategy
        if self.p.trailing_stop:
            # Calculate the trailing stop value for the current feed.
            # This is done by adding a percentage (self.p.trailing_stop)
            # of the current tick price (self.tick[feed]) to the current tick price.
            trailing_stop = self.tick[feed] + \
                self.tick[feed] * self.p.trailing_stop / 100

            # Update the trailing stop for the feed with the minimum value
            # between the calculated trailing stop and the existing trailing stop.
            # This ensures the trailing stop only moves in one direction.
            self.trailing_stop[feed] = min(trailing_stop, self.trailing_stop[feed])

            # Check if the current tick price has reached or exceeded the
            # trailing stop value. If it has, close the position and return.
            if self.tick[feed] >= self.trailing_stop[feed]:
                self.close_position(reason="trail", feed=feed)
                return

        # Check if a rolling stop is defined for this strategy
        # and the current tick price is greater than or equal to the rolling stop value
        if self.p.rolling_stop and self.tick[feed] >= self.rolling_stop[feed]:
            # Calculate the stop loss value by adding a percentage (self.p.stop_loss)
            # of the current tick price (self.tick[feed]) to the current tick price.
            self.stop_loss[feed] = self.tick[feed] + \
                self.tick[feed] * self.p.stop_loss / 100

            # Calculate the new rolling stop value by subtracting a percentage (self.p.rolling_stop)
            # of the current tick price (self.tick[feed]) from the current tick price.
            self.rolling_stop[feed] = self.tick[feed] - \
                self.tick[feed] * self.p.rolling_stop / 100

    def _is_new_candle(self, feed):
        """ description """
        if feed == 0:
            return False
        try:
            _ = self.last_candle_date[feed]
            if self.datas[feed].datetime[0] == self.datas[0].datetime[0]:
                self.last_candle_date[feed] = self.datas[feed].datetime[0]
                return True
            else:
                return False
        except KeyError:
            self.last_candle_date[feed] = self.datas[feed].datetime[0]
            return self._is_new_candle(feed=feed)

    def save_log(self, action, num):
        """ description """
        return

    def get_entry_signal(self):
        """ description """
        return

    def update_trade_vars(self, feed=0):
        """ description """
        if self.pos[feed] > 0:
            self.take_profit[feed] = self.tick[feed] + self.tick[feed] * \
                self.p.take_profit / 100 if self.p.take_profit else None
            self.stop_loss[feed] = self.tick[feed] - self.tick[feed] * \
                self.p.stop_loss / 100 if self.p.stop_loss else None
            self.rolling_stop[feed] = self.tick[feed] + self.tick[feed] * \
                self.p.rolling_stop / 100 if self.p.rolling_stop else None
            self.trailing_stop[feed] = self.tick[feed] - self.tick[feed] * \
                self.p.trailing_stop / 100 if self.p.trailing_stop else None
        if self.pos[feed] < 0:
            self.take_profit[feed] = self.tick[feed] - self.tick[feed] * \
                self.p.take_profit / 100 if self.p.take_profit else None
            self.stop_loss[feed] = self.tick[feed] + self.tick[feed] * \
                self.p.stop_loss / 100 if self.p.stop_loss else None
            self.rolling_stop[feed] = self.tick[feed] - self.tick[feed] * \
                self.p.rolling_stop / 100 if self.p.rolling_stop else None
            self.trailing_stop[feed] = self.tick[feed] + self.tick[feed] * \
                self.p.trailing_stop / 100 if self.p.trailing_stop else None
        if self.p.take_profit:
            self.datas[feed].take_profit = self.take_profit[feed]
        if self.p.stop_loss:
            self.datas[feed].stop_loss = self.stop_loss[feed]
        if self.p.timeout:
            self.datas[feed].timeout = self.timeout[feed]

    def open_pos(self, datas_num=0, otype=None):
        """ description """
        if self.datas[0].last_moments is True:
            return None
        if self.entry_signal[datas_num] == "Buy":
            self.take_profit[datas_num] = self.tick[datas_num] + self.tick[datas_num] * \
                self.p.take_profit / 100 if self.p.take_profit else None
            self.stop_loss[datas_num] = self.tick[datas_num] - self.tick[datas_num] * \
                self.p.stop_loss / 100 if self.p.stop_loss else None
            self.rolling_stop[datas_num] = self.tick[datas_num] + self.tick[datas_num] * \
                self.p.rolling_stop / 100 if self.p.rolling_stop else None
            self.trailing_stop[datas_num] = self.tick[datas_num] - self.tick[datas_num] * \
                self.p.trailing_stop / 100 if self.p.trailing_stop else None
            self.open_long(datas_num, otype=otype)
        elif self.entry_signal[datas_num] == "Sell":
            self.take_profit[datas_num] = self.tick[datas_num] - self.tick[datas_num] * \
                self.p.take_profit / 100 if self.p.take_profit else None
            self.stop_loss[datas_num] = self.tick[datas_num] + self.tick[datas_num] * \
                self.p.stop_loss / 100 if self.p.stop_loss else None
            self.rolling_stop[datas_num] = self.tick[datas_num] - self.tick[datas_num] * \
                self.p.rolling_stop / 100 if self.p.rolling_stop else None
            self.trailing_stop[datas_num] = self.tick[datas_num] + self.tick[datas_num] * \
                self.p.trailing_stop / 100 if self.p.trailing_stop else None
            self.open_short(datas_num, otype=otype)
        self.timeout[datas_num] = self.curtime[datas_num].timestamp() + self.feed_timeout[datas_num] if self.p.timeout else None
        self.save_log(action='open', num=datas_num)
        if self.verbose:
            print(f"------------OPEN  feed({datas_num})----------\
\nopening on: {self.curtime[0].format()}\
\nsignal: {self.entry_signal[datas_num]}\
\ntick: {self.tick[datas_num]}\
\nstop loss: {self.stop_loss[datas_num]}\
\ntake_profit: {self.take_profit[datas_num]}\
\n------------------\n")
        return True

    def close_position(self, reason, feed=0, otype=None):
        """ description """
        datas = self.datas[feed]
        if self.pos[feed] is None:
            print("problem here",feed)
            exit()
        self.take_profit[feed] = None
        self.stop_loss[feed] = None
        self.rolling_stop[feed] = None
        self.trailing_stop[feed] = None
        self.datas[feed].event_timeout = None
        order = None
        kwargs = {'reason': reason}
        self.lastclose[feed] = reason
        if self.pos[feed] < 0:
            signal = "Buy"
        elif self.pos[feed] > 0:
            signal = "Sell"
        order = self.place_order(
            signal=signal,
            otype=otype,
            entry=self.pos[feed],
            datas=datas,
            reason=reason)
        self.save_log(action='close', num=feed)
        if self.verbose:
            print(
                f"--------- CLOSED ------------\nPosition closed on:\n{self.curtime[0].format()}\nwith signal: {signal}\n--------------\n\n")
        return None

    def entry(self, datas_num, price=None):
        """ description """
        if not price:
            price = self.tick[datas_num]
        return self.datas[datas_num].feed.pct * \
            self.cash[datas_num] / 100 / price

    def kill_orders(self):
        """ description """
        if self.dry_run:
            orders = self.broker.get_orders_open(self.datas[0])
            for order in orders:
                self.broker.cancel(order)

    def place_stop_order(self, size, price, datas=None):
        """ description """
        self.order_placed = True
        datas = self.datas[0] if not datas else data
        if size < 0:
            return self.buy(
                datas,
                exectype=bt.Order.StopLimit,
                size=size,
                price=price)
        if size > 0:
            return self.sell(
                datas,
                exectype=bt.Order.StopLimit,
                size=size,
                price=price)

    def place_stop_limit_order(self, size, price, datas=None):
        """ description """
        self.order_placed = True
        datas = self.datas[0] if not datas else datas
        if size < 0:
            return self.buy(
                datas,
                exectype=bt.Order.StopLimit,
                size=size,
                price=price,
                plimit=plimit)
        if size > 0:
            return self.sell(
                datas,
                exectype=bt.Order.StopLimit,
                size=size,
                price=price,
                plimit=plimit)

    def place_order(self, signal, entry, otype=None, datas=None, reason=None):
        """ description """
        self.order_placed = True
        if otype is None:
            otype = self.exectype
        datas = self.datas[0] if not datas else datas
        kwargs = {'reason': reason}
        if entry is None or entry == 0:
            print("entry size is cero", entry)
            exit()
        # maybe here save bot_vars
        if signal == "Buy":
            return self.buy(
                datas,
                exectype=otype,
                size=entry,
                command=self.order_cmd,
                **kwargs)
        if signal == "Sell":
            return self.sell(
                datas,
                exectype=otype,
                size=entry,
                command=self.order_cmd,
                **kwargs)
        return None

    def open_long(self, datas_num=0, otype=None):
        """ description """
        entry_size = self.entry(
            datas_num=datas_num,
            price=self.tick[datas_num])
        self.lastclose[datas_num] = 'Open'
        return self.place_order(
            signal="Buy",
            otype=otype,
            entry=entry_size,
            datas=self.datas[datas_num],
            reason='Open')

    def open_short(self, datas_num=0, otype=None):
        """ description """
        self.lastclose[datas_num] = 'Open'
        if self.datas[datas_num].feed.futures:
            entry_size = self.entry(
                datas_num=datas_num,
                price=self.tick[datas_num])
            return self.place_order(
                signal="Sell",
                otype=otype,
                entry=entry_size,
                datas=self.datas[datas_num],
                reason='Open')
        return None

    def notify_order(self, order):
        """ description """
        pass

    def notify_trade(self, trade):
        pass
