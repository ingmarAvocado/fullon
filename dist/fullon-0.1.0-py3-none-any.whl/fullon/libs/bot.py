from __future__ import (
    absolute_import,
    division,
    print_function,
    unicode_literals
)
from multiprocessing import Value
import sys
import datetime
import time
import importlib
import arrow
import backtrader as bt
import threading
from libs import cache, log, strategy
from libs.database import Database
from libs.btrader.fullonbroker import FullonBroker
from libs.btrader.fullonresampler import FullonFeedResampler
from typing import Optional, Union, List


FEED_CLASSES = {
    "FullonFeed": "libs.btrader.fullonfeed.FullonFeed",
    "FullonSimFeed": "libs.btrader.fullonsimfeed.FullonSimFeed",
    "FullonEventFeed": "libs.btrader.fulloneventfeed.FullonEventFeed"
}

logger = log.fullon_logger(__name__)


class Bot:

    test = False

    def __init__(self, bot_id: int, bars: int = 0) -> None:
        """
        Initialize the bot instance.

        :param bot_id: The ID of the bot.
        :param bars: The number of bars used in the bot. Defaults to 0.
        """
        with Database() as dbase:
            try:
                bot = dbase.get_bot_list(bot_id=bot_id)[0]
            except IndexError:
                self.id = None
                logger.warning(f"Bot id {bot_id} not found or not active")
                return None
            self.str_id = bot.str_id
            self.bars = bars
            self.strategy = dbase.get_str_name(str_id=bot.str_id)
            self.uid = bot.uid
            self.id = bot.bot_id
            self.bot_name = bot.name
            self.dry_run = bot.dry_run
            self.start_time = arrow.utcnow()
            self.simulresults = {}
            self.str_params = self._str_set_params(dbase=dbase)
            self.cache = cache.Cache()
            self.str_feeds = self._set_feeds(
                dbase.get_str_feeds(bot_id=bot.bot_id), dbase=dbase)

            if not self.str_feeds:
                logger.error(
                    "__init__: It is not possible to run a simulation without feeds")
                exit("bye")

    def __del__(self) -> None:
        """
        Clean up the bot instance before deleting.
        """
        pass

    def _set_feeds(self, feeds, dbase) -> list:
        """
        Set the feeds for the bot.

        :param feeds: A list of feeds to be used by the bot.
        :return: A list of modified feeds.
        """
        ret_feeds = []
        exchanges = dbase.get_exchange(user_id=self.uid)
        dict = {}
        tradeable = {}

        for e in exchanges:
            dict[str(e.cat_ex_id)] = e.ex_id

        for feed in feeds:
            try:
                if tradeable[feed.exchange_name][feed.symbol] is True:
                    setattr(feed, 'trading', False)
            except KeyError:
                setattr(feed, 'trading', True)
                if feed.exchange_name not in tradeable.keys():
                    tradeable[feed.exchange_name] = {}
                tradeable[feed.exchange_name][feed.symbol] = True
            ret_feeds.append(feed)

        return ret_feeds

    def _str_set_params(self, dbase) -> dict:
        """
        Set the strategy parameters for the bot.

        :return: A dictionary of strategy parameters.
        """
        strs = dbase.get_str_params(self.str_id)
        params = {}
        for s in strs:
            name = s[0]
            value = s[1]
            if name not in ('take_profit', 'stop_loss', 'rolling_stop', 'trailing_stop', 'timeout', 'timeout_size', 'size_pct', 'leverage'):
                try:
                    params.update({name: int(value)})
                except BaseException:
                    params.update({name: value})

        base_params = vars(dbase.get_base_str_params(str_id=self.str_id))

        for p, k in base_params.items():
            if k is not None:
                params.update({p: k})
        params.update({'helper': self})
        return params

    def extend_str_params(self, test_params: dict) -> None:
        """
        Extend the strategy parameters with additional test parameters.

        :param test_params: A dictionary containing additional test parameters.
        """
        if test_params:
            for key, value in test_params.items():
                self.str_params[key] = value

    def _set_timeframe(self, period: str) -> bt.TimeFrame:
        """
        Convert a string representation of a time frame to the corresponding constant value in the backtrader library.
        """
        # define a dictionary that maps the period strings to the corresponding constants
        period_map = {
            "ticks": bt.TimeFrame.Ticks,
            "minutes": bt.TimeFrame.Minutes,
            "days": bt.TimeFrame.Days,
            "weeks": bt.TimeFrame.Weeks,
            "months": bt.TimeFrame.Months
        }
        # convert the period to lowercase to ensure it matches the keys in the dictionary
        period = period.lower()
        # return the corresponding constant from the dictionary, or None if the period is not in the dictionary
        return period_map.get(period)

    def backload_from(self, bars: int = 100) -> arrow.Arrow:
        """
        Shift the current time by a certain amount, based on the 'frame' and 'compression' parameters.
        Returns a new Arrow object with the shifted time.
        """
        # define a dictionary that maps each period string to the corresponding time unit for Arrow
        period_map = {
            "ticks": "minutes",
            "minutes": "minutes",
            "hours": "hours",
            "days": "days",
            "weeks": "weeks",
            "months": "months"
        }
        # get the feed for the last data and calculate the time shift based on the compression and simul_backtest
        feed = self.str_feeds[-1]
        timeframe = self._set_timeframe(period=feed.period)
        time_unit = period_map.get(feed.period.lower())
        if time_unit is None:
            raise ValueError("Unrecognized period: {}".format(feed.period))
        shift_args = {time_unit: -feed.compression * bars}
        # shift the current time by the specified amount and set the time to midnight
        if timeframe >= 5:
            return arrow.utcnow().shift(**shift_args).floor('day')
        else:
            return arrow.utcnow().shift(**shift_args).floor('minute')

    def _pair_feeds(self, cerebro: bt.Cerebro) -> None:
        """
        Pair up the data feeds in the Cerebro object by setting the 'feed2' attribute of each feed to the
        corresponding feed in the pair.
        """
        # Determine the number of data feeds in the Cerebro object
        num_feeds = len(cerebro.datas)
        # If there is an odd number of data feeds, raise an error
        if num_feeds % 2 != 0:
            raise ValueError("Number of data feeds must be even.")
        # Determine the number of pairs of data feeds
        num_pairs = num_feeds // 2
        # Loop over each pair of data feeds and pair them up
        for i in range(num_pairs):
            # Set the 'feed2' attribute of the first feed to be the second feed in the pair
            cerebro.datas[i].feed2 = cerebro.datas[i + num_pairs]
            # Set the 'feed2' attribute of the second feed to be the first feed in the pair
            cerebro.datas[i + num_pairs].feed2 = cerebro.datas[i]

    def _feeds_can_start(self) -> bool:
        """
        Checks if all feeds in `self.str_feeds` can start. A feed can start if the following conditions are met:
        - The OHLCV process for the feed is 'Synced' and its timestamp is not older than 120 seconds.
        - The ticker for the feed is running, and its timestamp is not older than 120 seconds.
        - The account associated with `self.uid` is being updated, and its timestamp is not older than 120 seconds.

        This method iterates through all feeds. For each feed, it retrieves the associated process from the cache
        and checks if the process is 'Synced' and its timestamp is recent. It then retrieves the ticker for the feed
        and checks its timestamp. Finally, it retrieves the account process associated with `self.uid` and checks its timestamp.
        If any of these checks fail, the method immediately returns `False`, indicating that not all feeds can start. 
        If all checks pass for all feeds, the method returns `True`, indicating that all feeds can start.

        Returns:
            bool: `True` if all feeds can start, `False` otherwise.
        """
        for _, feed in enumerate(self.str_feeds):
            with cache.Cache() as store:
                # First we check if the OHLCV has started
                res = store.get_process(tipe='ohlcv', key=f'{feed.exchange_name}:{feed.symbol}')
                if 'Synced' not in res['message'] or arrow.get(res['timestamp']).shift(seconds=120) <= arrow.utcnow():
                    msg = f"ohlcv tick for {feed.exchange_name}:{feed.symbol} is not synced"
                    logger.error(msg)
                    return False
                # Now we check that the ticker is running, on for no more than 120 seconds
                res = store.get_ticker(exchange=feed.exchange_name, symbol=feed.symbol)
                if arrow.get(res[1]).shift(seconds=120) <= arrow.utcnow():
                    msg = f"Ticker for {feed.exchange_name}:{feed.symbol} doesnt seem to be working"
                    logger.error(msg)
                    return False
                # now we check that the account is being updated
                res = store.get_process(tipe="account", key=self.uid)
                if arrow.get(res['timestamp']).shift(seconds=120) <= arrow.utcnow():
                    msg = f"account {self.uid} is not being updated"
                    logger.error(msg)
                    return False
        return True

    def _load_feeds(self, cerebro: bt.Cerebro,
                    warm_up: int,
                    event: bool,
                    ofeeds: list) -> None:
        """
        Loads the feeds into the cerebro instance for backtesting.

        Parameters:
        - cerebro: A `backtrader.Cerebro` instance.
        - warm_up: The number of bars to warm up the strategy with.
        - event: A boolean indicating whether to use the event feed or the simulation feed.

        Returns:
        - None
        """
        # Initialize the first feed as None
        feed0 = None
        # Loop through all the feeds and add them to the cerebro instance
        for num, feed in enumerate(self.str_feeds):
            # Clear the simulation results list for this feed
            self.simulresults[num] = []
            # Set the timeframe for the feed
            timeframe = self._set_timeframe(period=feed.period)
            if feed.period.lower() == "ticks":
                self.str_feeds[num].period = "minutes"
                feed.period = "minutes"
            compression = feed.compression
            try:
                compression = ofeeds[num]['compression']
            except KeyError:
                pass
            period = feed.period
            try:
                period = ofeeds[num]['period']
            except KeyError:
                pass
            # Adjust the start date if the feed has compression > 1
            if compression > 1:
                fromdate = self.backload_from(bars=self.bars+warm_up).floor('day')
            else:
                # Set the start date for the backtest
                fromdate = self.backload_from(bars=self.bars).floor('day')
            # Choose the feed class based on the event parameter
            feed_name = "FullonEventFeed" if event else "FullonSimFeed"
            # Get the feed class object dynamically
            feed_class = FEED_CLASSES[feed_name]
            feed_module, feed_class_name = feed_class.rsplit(".", 1)
            FeedClass = getattr(importlib.import_module(feed_module), feed_class_name)
            # Create a new broker object for this feed
            # Create a new data object using the chosen feed class
            data = FeedClass(
                feed=feed,
                timeframe=timeframe,
                compression=int(compression),
                helper=self,
                fromdate=fromdate,
                mainfeed=feed0)
            # Add the data object to the cerebro instance
            cerebro.adddata(data, name=f'{num}')
            # Store the first feed object for later use
            if num == 0:
                feed0 = data
            del data

    def run_simul_loop(self,
                       feeds: dict = {},
                       visual: bool = False,
                       test_params: dict = {},
                       warm_up: int = 0,
                       event: bool = False) -> Union[bool, List[Union[str, dict]]]:
        """
        Run a simulation loop.

        :param feeds: A dictionary containing feeds. Defaults to an empty dictionary.
        :param visual: A flag indicating whether to enable visualization. Defaults to False.
        :param test_params: A dictionary containing test parameters. Defaults to an empty dictionary.
        :param warm_up: Warm-up period for the simulation. Defaults to 0.
        :param event: A flag indicating whether it's an event. Defaults to False.
        :return: Simulation results or an error message.
        """
        if not self.id:
            return False

        self.extend_str_params(test_params)
        cerebro = bt.Cerebro()

        if event:
            strategy.STRATEGY_TYPE = "event"
        else:
            strategy.STRATEGY_TYPE = "backtest"
        broker = self.get_broker(dry=True)
        cerebro.setbroker(broker)

        module = importlib.import_module(
            'strategies.' + self.strategy + '.strategy',
            package='strategy')
        cerebro.addstrategy(module.strategy, **self.str_params)

        self._load_feeds(cerebro=cerebro, warm_up=warm_up, event=event, ofeeds=feeds)
        self._pair_feeds(cerebro=cerebro)
        try:
            r = cerebro.run(live=True)
        except TypeError as error:
            logger.warning(
                "Error can't run Bot, probably loading a parameter that the bot does not have: ", str(error))
            sys.exit()

        if r == []:
            return [
                "ERROR: Either nothing happened or could not pass strategy __init__, check log"]
        imgtitle = ""
        if visual:
            now = arrow.utcnow().format('YYYY-MM-DD_HH:mm:ss')
            p = ""
            for key, value in test_params.items():
                p = p + str(key) + "_" + str(value) + "_"
            imgtitle = "tmp/simul_" + self.strategy + "_" + p + "_" + now + ".png"
            cerebro.plot(style='candles', saveimg=imgtitle)

        for n in range(0, len(self.simulresults)):
            self.simulresults[n].append(
                {"strategy": self.strategy, "params": test_params, "symbol": n, "imgtitle": imgtitle})
        del cerebro
        return self.simulresults

    def _load_live_feeds(self, cerebro: bt.Cerebro, bars: int):
        """
        Loads the feeds into the cerebro instance for backtesting.

        Parameters:
        - cerebro: A `backtrader.Cerebro` instance.
        Returns:
        - None
        """
        # Initialize the first feed as None
        feed0 = None
        fromdate = self.backload_from(bars=bars)
        feed_map = {}
        for num, feed in enumerate(self.str_feeds):
            compression = int(feed.compression)
            period = feed.period
            timeframe = self._set_timeframe(period=period)
            # Choose the feed class based on the event parameter
            feed_class = FEED_CLASSES['FullonFeed']
            feed_module, feed_class_name = feed_class.rsplit(".", 1)
            FeedClass = getattr(importlib.import_module(feed_module), feed_class_name)
            # Create a new broker object for this feed
            # Create a new data object using the chosen feed class
            #  Since when the database should load
            if timeframe == bt.TimeFrame.Ticks:
                data = FeedClass(feed=feed,
                                 timeframe=1,
                                 compression=1,
                                 helper=self,
                                 fromdate=fromdate,
                                 mainfeed=None)
                cerebro.adddata(data, name=f'{num}')
                try:
                    feed_map[feed.exchange_name].update({feed.symbol: data})
                except KeyError:
                    feed_map[feed.exchange_name] = {feed.symbol: data}
            else:
                #that this moment len(cerebro.datas) is 1
                parent_data = feed_map[feed.exchange_name][feed.symbol]
                resampled_data = cerebro.resampledata(parent_data,
                                                      timeframe=timeframe,
                                                      compression=compression,
                                                      name=f'{num}')
                #print(f"Len is {len(cerebro.datas)}")
                #that this moment len(cerebro.datas) is 2
                #this one shouldnt be added,see?
                sampler = FullonFeedResampler()
                fullon_resampled_data = sampler.prepare(data=resampled_data,
                                                        bars=bars,
                                                        timeframe=timeframe,
                                                        compression=compression)
                #cerebro.adddata(fullon_resampled_data, name=f'{num}')
                #print(f"Len is {len(cerebro.datas)}")
                #that this moment len(cerebro.datas) is 3
                #or maybe this one is unecessary?

    def get_broker(self, dry=False) -> bt.brokers.BackBroker:
        """
        Initializes and sets the brokers for each data feed.

        Returns:
            None
        """
        if self.dry_run or dry:
            broker = bt.brokers.BackBroker()
            broker.setcash(10000)
            broker.setcommission(
                commission=0.001,
                margin=None,
                mult=1,
                interest=.001
            )
        else:
            broker = FullonBroker(feed=self.str_feeds[0])
        return broker

    def run_loop(self, test: Optional[bool] = False, stop_signal: Optional[threading.Event] = None) -> None:
        """
        Run the bot's main loop until the stop_signal is set.

        Parameters:
            test (Optional[bool]): Whether to run the bot in test mode. Defaults to False.
            stop_signal (Optional[threading.Event]): An event object to signal the loop to stop. Defaults to None.
        """

        if not self._feeds_can_start():
            logger.error("Feeds can't start, exiting bot startup")
            return

        if stop_signal is None:
            stop_signal = threading.Event()

        self.test = test
        cerebro = bt.Cerebro()
        if self.dry_run:
            strategy.STRATEGY_TYPE = "drylive"
        else:
            strategy.STRATEGY_TYPE = "live"
        if test:
            strategy.STRATEGY_TYPE = "testlive"
        broker = self.get_broker()
        cerebro.setbroker(broker)

        module = importlib.import_module(
            'strategies.' + self.strategy + '.strategy',
            package='strategy')
        cerebro.addstrategy(module.strategy, **self.str_params)
        self._load_live_feeds(cerebro=cerebro, bars=module.strategy.params.bars)
        # return True
        logger.info("Starting Bot...")
        # print(len(cerebro.datas))

        # Check if stop_signal is set before starting the loop
        if stop_signal.is_set():
            return

        cerebro.run(live=True)

        #while True:
        #    # Check if stop_signal is set after the loop has finished
        #    if stop_signal.is_set():
        #        print(">>>>>> bot is being stopped")
        #        break
