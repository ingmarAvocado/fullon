"""
Cache class for managing caching operations with Redis.
The Cache class provides functionality to interact with
a Redis cache server, including creating, updating,
and retrieving cache entries. It also includes utility
methods for testing the connection to the cache server,
preparing the cache, and filtering cache entries based
on timestamps and component types.
"""

import json
from libs import log
from libs.caches import trades_cache as cache
from typing import Dict, Tuple, Union
import arrow

logger = log.fullon_logger(__name__)


class Cache(cache.Cache):
    """
    A class for managing caching operations with Redis.
    Attributes:
    """

    def get_bot_position(self, bot_id: str, ex_id: str, symbol: str) -> Tuple[float, float]:
        """
        Returns the position for a bot.

        Args:
            bot_id (str): The bot ID.
            uid (str): The user ID.
            ex_id (str): The exchange ID.
            symbol (str): The trading symbol.

        Returns:
            Tuple[float, float]: A tuple containing the total position (float) and the position price (float).
        """
        try:
            user_ex = self.get_exchange(ex_id=ex_id)
            key = f"{user_ex.uid}:{user_ex.ex_id}"
            datas = self.conn.hget(f"account_positions", key)
            if datas:
                datas = json.loads(datas)
                pos1 = datas[symbol]
                pos2 = json.loads(self.conn.hget("bot_status", bot_id))
                return float(pos1['total']), float(pos2['pos_price'])
        except KeyError:
            pass
        return 0.0, 0.0

    def update_bot(self, bot_id: str, bot: Dict[str, Union[str, int, float]]) -> bool:
        """
        Update a bot's status in the cache.

        Args:
            bot_id (str): The ID of the bot.
            bot (Dict[str, Union[str, int, float]]): A dictionary containing the bot's status.

        Returns:
            bool: True if the operation was successful, False otherwise.
        """

        # Iterate over each feed's status in the bot dictionary
        for feed_status in bot.values():
            # Set the timestamp for each feed's status
            feed_status["timestamp"] = arrow.utcnow().format()

        # Save the updated bot status to the cache
        if self.conn.hset("bot_status", bot_id, json.dumps(bot)):
            return True
        return False

