import uuid
import sys
from run import install_manager
from run import user_manager
from libs.structs.symbol_struct import SymbolStruct
from libs.structs.exchange_struct import ExchangeStruct
from libs.database import Database


def install():
    # Instantiante install manager
    system = install_manager.InstallManager()

    # First lets install some symbols
    SYMBOL = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "symbol": "BTC/USD",
        "exchange_name": "kraken",
        "updateframe": "1h",
        "backtest": "2700",
        "decimals": 6,
        "base": "USD",
        "ex_base": "",
        "futures": "t"}
    system.install_symbol(symbol=SymbolStruct.from_dict(SYMBOL))

    SYMBOL = {
        "symbol_id": "00000000-0000-0000-0000-000000000002",
        "symbol": "ETH/USD",
        "exchange_name": "kraken",
        "updateframe": "1h",
        "backtest": "300",
        "decimals": 6,
        "base": "USD",
        "ex_base": "",
        "futures": "t"}
    system.install_symbol(symbol=SymbolStruct.from_dict(SYMBOL))

    SYMBOL = {
        "symbol_id": "00000000-0000-0000-0000-000000000003",
        "symbol": "BTC/USDT",
        "exchange_name": "kraken",
        "updateframe": "1h",
        "backtest": "1",
        "decimals": 6,
        "base": "USDT",
        "ex_base": "",
        "futures": "t"}
    system.install_symbol(symbol=SymbolStruct.from_dict(SYMBOL))

    # now lets add a user

    USER = {
        "mail": "admin@fullon",
        "password": "password",
        "f2a": '---',
        "role": "admin",
        "name": "robert",
        "lastname": "plant",
        "phone": 666666666,
        "id_num": 3242}
    system.add_user(USER)

    # Add stragegies
    user = user_manager.UserManager()

    STRAT = {
        "cat_str_name": "pair_trading1a",
        "user": "admin@fullon",
        "name": "pairs1",
        "size_pct": 10,
        "leverage": 2}
    str_id = user.add_strategy(strategy=STRAT)

    STRAT = {
        "cat_str_name": "trading101",
        "user": "admin@fullon",
        "name": "trading101",
        "size_pct": 10,
        "leverage": 2}
    str_id = user.add_strategy(strategy=STRAT)

    STRAT = {
        "cat_str_name": "trading101_pairs",
        "user": "admin@fullon",
        "name": "trading101_pairs",
        "size_pct": 10,
        "leverage": 2}
    str_id = user.add_strategy(strategy=STRAT)

    STRAT = {
        "cat_str_name": "trading_rsi",
        "user": "admin@fullon",
        "name": "trading_rsi",
        "size_pct": 10,
        "leverage": 2}
    str_id = user.add_strategy(strategy=STRAT)

    uid = user.get_user_id(mail='admin@fullon')
    with Database() as dbase:
        cat_ex_id = dbase.get_cat_exchanges(exchange='kraken')[0][0]

    exchange = {
        "uid": uid,
        "cat_ex_id": cat_ex_id,
        "name": "kraken1",
        "test": "False",
        "active": "True"}
    ex_id = user.add_exchange(exch=ExchangeStruct.from_dict(exchange))

    key = input("Please give your exchange API key to fullon: ")
    secret = input("\nPlease give your exchange SECRET key to fullon: ")

    user.set_secret_key(user_id=uid, exchange=cat_ex_id, key=key, secret=secret)

    # -------------------------------------------------------
    # New bot # 1

    BOT = {
        "bot_id": '00000000-0000-0000-0000-000000000001',
        'user': 'admin@fullon',
        'str_name': 'pairs1',
        'name': 'test pair',
        'dry_run': 'True',
        'active': 'True'
    }
    bot_id = user.add_bot(bot=BOT)
    exchange = {"exchange_id": f"{ex_id}"}
    user.add_bot_exchange(bot_id=bot_id, exchange=exchange)

    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "bot_id": bot_id,
        "period": 'Ticks',
        "compression": 1,
        "order": 1}
    user.add_feed_to_bot(feed=feed)
    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000002",
        "bot_id": bot_id,
        "period": 'Ticks',
        "compression": 1,
        "order": 2}
    user.add_feed_to_bot(feed=feed)

    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "bot_id": bot_id,
        "period": 'Minutes',
        "compression": 10,
        "order": 3}
    user.add_feed_to_bot(feed=feed)

    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000002",
        "bot_id": bot_id,
        "period": 'Minutes',
        "compression": 10,
        "order": 4}
    user.add_feed_to_bot(feed=feed)

    # -------------------------------------------------------
    # New bot #2

    BOT = {
        "bot_id": '00000000-0000-0000-0000-000000000002',
        'user': 'admin@fullon',
        'str_name': 'trading101',
        'name': 'trading101',
        'dry_run': 'True',
        'active': 'True'
    }
    bot_id = user.add_bot(bot=BOT)
    exchange = {"exchange_id": f"{ex_id}"}
    user.add_bot_exchange(bot_id=bot_id, exchange=exchange)

    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "bot_id": bot_id,
        "period": 'Ticks',
        "compression": 1,
        "order": 1}
    user.add_feed_to_bot(feed=feed)
    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "bot_id": bot_id,
        "period": 'Minutes',
        "compression": 10,
        "order": 2}
    user.add_feed_to_bot(feed=feed)

    # -------------------------------------------------------
    # New bot #3
    BOT = {
        "bot_id": '00000000-0000-0000-0000-000000000003',
        'user': 'admin@fullon',
        'str_name': 'trading101_pairs',
        'name': 'trading101_pairs',
        'dry_run': 'True',
        'active': 'True'
    }
    bot_id = user.add_bot(bot=BOT)
    exchange = {"exchange_id": f"{ex_id}"}
    user.add_bot_exchange(bot_id=bot_id, exchange=exchange)

    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "bot_id": bot_id,
        "period": 'Ticks',
        "compression": 1,
        "order": 1}
    user.add_feed_to_bot(feed=feed)
    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "bot_id": bot_id,
        "period": 'Minutes',
        "compression": 10,
        "order": 2}
    user.add_feed_to_bot(feed=feed)

    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000002",
        "bot_id": bot_id,
        "period": 'Ticks',
        "compression": 1,
        "order": 1}
    user.add_feed_to_bot(feed=feed)
    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000002",
        "bot_id": bot_id,
        "period": 'Minutes',
        "compression": 10,
        "order": 2}
    user.add_feed_to_bot(feed=feed)

    # -------------------------------------------------------
    # New bot #4
    BOT = {
        "bot_id": '00000000-0000-0000-0000-000000000004',
        'user': 'admin@fullon',
        'str_name': 'trading_rsi',
        'name': 'trading_rsi',
        'dry_run': 'True',
        'active': 'True'
    }
    bot_id = user.add_bot(bot=BOT)
    exchange = {"exchange_id": f"{ex_id}"}
    user.add_bot_exchange(bot_id=bot_id, exchange=exchange)
    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "bot_id": bot_id,
        "period": 'Ticks',
        "compression": 1,
        "order": 1}
    user.add_feed_to_bot(feed=feed)
    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000001",
        "bot_id": bot_id,
        "period": 'Minutes',
        "compression": 60,
        "order": 2}
    user.add_feed_to_bot(feed=feed)

    # -------------------------------------------------------
    # New bot #5
    user = user_manager.UserManager()
    UID = user.get_user_id(mail='admin@fullon')
    details = user.user_details(uid=UID)
    with Database() as dbase:
        exch = dbase.get_exchange(user_id=UID)[0]
    BOT = {
        "bot_id": '00000000-0000-0000-0000-000000000005',
        'user': 'admin@fullon',
        'str_name': 'trading_rsi',
        'name': 'trading_rsi',
        'dry_run': 'True',
        'active': 'True'
    }
    bot_id = user.add_bot(bot=BOT)
    exchange = {"exchange_id": f"{exch.ex_id}"}
    user.add_bot_exchange(bot_id=bot_id, exchange=exchange)
    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000002",
        "bot_id": bot_id,
        "period": 'Ticks',
        "compression": 1,
        "order": 1}
    user.add_feed_to_bot(feed=feed)
    feed = {
        "symbol_id": "00000000-0000-0000-0000-000000000002",
        "bot_id": bot_id,
        "period": 'Minutes',
        "compression": 60,
        "order": 2}
    user.add_feed_to_bot(feed=feed)
