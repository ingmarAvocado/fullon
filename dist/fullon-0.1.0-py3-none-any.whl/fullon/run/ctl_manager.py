#!/usr/bin/python3
"""
Fullon CTL Manager
"""
from __future__ import unicode_literals, print_function
import json
import xmlrpc.client
from clint.textui import puts, colored, indent
import pandas as pd
from run import system_manager, avail_components as comp
from libs import settings, log


logger = log.fullon_logger(__name__)


RPC = xmlrpc.client.ServerProxy(
    f"http://{settings.XMLRPC_HOST}:{settings.XMLRPC_PORT}")


def top():
    """ description """
    topt = system_manager.InstallManager()
    records = []
    for record in topt.get_top():
        rec = {
            "pid": record.pid,
            "type": record.type,
            "key": record.key,
            "message": record.message,
            "timestamp": record.timestamp}
        records.append(rec)
    dframe = pd.DataFrame.from_dict(records)
    print(dframe.to_string())


def full(argv):
    """ description """
    if len(argv) > 2:
        if "start" in argv[2]:
            logger.info(RPC.start_full())
        if "stop" in argv[2]:
            logger.info(RPC.stop_full())


def fixes(argv):
    """ description """
    if len(argv) > 2:
        if "dry_trades" == argv[2]:
            # RPC.fix_dry_trades())
            logger.info(colored.red("No working, obsolete?"))


def kill(argv):
    """ description """
    if len(argv) > 2:
        if "pid" in argv[2]:
            try:
                if RPC.kill_pid(int(argv[3])):
                    mesg = colored.cyan(f"Process ({argv[3]}) killed")
                else:
                    mesg = colored.red("\nno such pid")
                    logger.info(mesg)
            except IndexError:
                mesg = colored.red("\nNo such pid")
                logger.warning(mesg)
            except ValueError:
                mesg = colored.cyan("\nExample: kill pid 31416")
                logger.warning(mesg)
            print_help_function(
                component="kill", subname="pid", help_mesg=mesg)


def backup(argv):
    """ description """
    if len(argv) > 2:
        if "recover" == argv[2]:
            try:
                if argv[3]:
                    logger.info(RPC.backup_recover(argv[3]))
            except ValueError:
                mesg = "Example: \
                backup recover mini_fullon_back_2020-04-15_15:22:16.sql.gz"
                print_help_function(
                    component='backup',
                    subname='recover',
                    help_mesg=mesg)
        if "create" == argv[2]:
            logger.info(RPC.backup_create())
        if "create_full" == argv[2]:
            logger.info(RPC.backup_create_full())
        if "create_mini" == argv[2]:
            logger.info(RPC.backup_create_mini())
        if "list" == argv[2]:
            for back in RPC.backup_list():
                logger.info(colored.cyan(back))


def ohlcv(argv):
    """ description """
    if len(argv) > 2:
        if "start" in argv[2]:
            logger.info(RPC.start_ohlcv())
        elif "stop" in argv[2]:
            logger.info(RPC.stop_component("ohlcv"))
    print_comp_menu(component="ohlcv")


def tickers(argv):
    """ description """
    if len(argv) > 2:
        if "start" in argv[2]:
            logger.info(RPC.start_tickers())
        elif "stop" in argv[2]:
            logger.info(RPC.stop_component("tick"))


def trades(argv):
    """ description """
    if len(argv) > 2:
        if "start" in argv[2]:
            logger.info(RPC.start_trades())
        elif "stop" in argv[2]:
            logger.info(RPC.stop_component("trades"))


def orders(argv):
    """ description """
    if len(argv) > 2:
        if "start" in argv[2]:
            logger.info(RPC.start_orders())
        elif "stop" in argv[2]:
            logger.info(RPC.stop_component("orders"))


def accounts(argv):
    """ description """
    if len(argv) > 2:
        if "start" in argv[2]:
            logger.info(RPC.start_accounts())
        if "stop" in argv[2]:
            logger.info(RPC.stop_component("account"))


def services(argv):
    """ description """
    if len(argv) > 2:
        if "start" in argv[2]:
            logger.info(RPC.start_services())
        if "stop" in argv[2]:
            logger.info(RPC.stop_services())


def setup(argv):
    """ description """
    if len(argv) > 2:
        if "install" in argv[2]:
            logger.info(RPC.setup_install())


def bots(argv):  # pylint: disable=too-many-return-statements,too-many-branches
    """ description """
    if len(argv) > 2:
        if "start" in argv[2]:
            logger.info(colored.magenta(RPC.start_bots()))
            return None
        if "stop" in argv[2]:
            logger.info(RPC.stop_component("bot"))
            return None
        if "list" in argv[2]:
            mesg = "\n" + colored.cyan(RPC.bots_list())
            return None
        if "simul" in argv[2]:
            try:
                bot = json.loads(argv[3])
                for record in RPC.bot_simul(bot):
                    mesg = f"Result: {record}"
                    logger.info(mesg)
            except (json.decoder.JSONDecodeError, IndexError):
                jsonstr = '''{"bot_id":"e8657273-7a15-4a1c-bf50-8cfc81483ec1",
                "days":"150",  "verbose":"1", "compression":"480","visual":1,
                "params":{"smaShort":"7", "smaLong":"45", \
                "ema":"45","rsi_range":"45"}}'''
                mesg = colored.cyan(f"\nrun: bots simul <json> \nExample: \
                    bots simul {jsonstr}")
                print_help_function(
                    component="bots",
                    subname="simul",
                    help_mesg=mesg)
            return None
        if "add" in argv[2]:
            try:
                bot = json.loads(argv[3])
                logger.info(RPC.bot_add(bot))
            except IndexError:
                jsonstr = '{"bot_id":"8976705d-3713-4d20-8f4d-00b4975c572c",\
                "symbol":"AE/BTC", "exchange":"binance",\
                "cat_str_name":"npi3"}'
                mesg = colored.cyan(
                    f"\nrun: bots add <json> \nExample: bots add {jsonstr}")
                print_help_function(
                    component="bots", subname="add", help_mesg=mesg)
            return None
        if "dry_reset" in argv[2]:
            try:
                bot_id = argv[3]
                logger.info(RPC.dry_reset(bot_id))
            except IndexError:
                mesg = colored.cyan("\nrun: bots dry_reset <bot_id> \n\
                        Example: bots dry_reset e8657273-7a15-4a1c-bf50-8cfc4")
                print_help_function(
                    component="symbols",
                    subname="dry_reset",
                    help_mesg=mesg)
            return None
        if "test" in argv[2]:
            try:
                bot_id = argv[3]
                logger.info(RPC.bot_test(bot_id))
            except IndexError:
                mesg = colored.cyan("\nrun: bots test <bot_id> \n\
                    Example: bots test e8657273-7a15-4a1c-bf50-8cfc81483ec1")
                print_help_function(
                    component="symbols",
                    subname="test",
                    help_mesg=mesg)
            return None
        if "edit" in argv[2]:
            try:
                bot = json.loads(argv[3])
                logger.info(RPC.bot_add(bot))
            except IndexError:
                jsonstr = '{"bot_id":"8976705d-3713-4d20-8f4d-00b4975c572c",\
                 "str_id":"AA76705d-3799-4d20-8f4d-00b4975cx3423x", \
                 "leverage":"1", "dry_run":"f", "pct":"10", "active":"t"}'
                mesg = colored.cyan(
                    f"\nrun: bots edit <json> \nExample: bots edit {jsonstr}")
                print_help_function(
                    component="bots", subname="add", help_mesg=mesg)
            return None
        if "disable" in argv[2]:
            logger.info(colored.red("API not yet implemented"))
            return None
    return None


def symbols(argv):
    """ description """
    if len(argv) > 2:
        if "update" == argv[2]:
            try:
                symbol = json.loads(argv[3])
                logger.info(colored.red(RPC.install_symbol(symbol)))
            except IndexError:
                mesg = colored.red("API NOT YET DONE")
                print_help_function(
                    component="symbols",
                    subname="update",
                    help_mesg=mesg)
        elif "add" == argv[2]:
            try:
                symbol = str(argv[3])
                symbol = json.loads(symbol)
                logger.info(colored.red(RPC.install_symbol(symbol)))
            except IndexError:
                mesg = colored.red("API NOT YET DONE")
                print_help_function(
                    component="symbols",
                    subname="add",
                    help_mesg=mesg)
        elif "list" == argv[2]:
            mesg = f"\n{colored.cyan(RPC.list_symbols())}"
            logger.info(mesg)


def users(argv):
    """ description """
    if len(argv) > 2:
        if 'list' == argv[2]:
            mesg = f"\n{colored.cyan(RPC.user_list())}"
            logger.info(mesg)
        if 'details' == argv[2]:
            try:
                logger.info(RPC.user_details(argv[3]))
            except IndexError:
                mesg = 'Run: user details <uid>\nExample: \
                user details 8091209c-f676-4a11-9c1d-f2f9e96d45e3'
                print_help_function(
                    component="users",
                    subname="details",
                    help_mesg=mesg)
        if 'add' == argv[2]:
            logger.info(colored.red("API not yet ready"))
        if 'edit' == argv[2]:
            logger.info(colored.red("API not yet ready"))
        if 'delete' == argv[2]:
            logger.info(colored.red("API not yet ready"))


def cat_strategies(argv):
    """ description """
    if len(argv) > 2:
        if 'list' == argv[2]:
            logger.info(RPC.strategies_list())
        if "params" == argv[2]:
            try:
                logger.info(colored.red(RPC.strategies_list_params(argv[3])))
            except IndexError:
                mesg = "Run: cat_strategies params <str_id>\nExample: \
                cat_strategies params f35b8561-558d-48b0-b6a3-1d45e058fa8d"
                print_help_function(
                    component="cat_strategies",
                    subname="params",
                    help_mesg=mesg)


def strategies(argv):
    """ description """
    if len(argv) > 2:
        if 'add' == argv[2]:
            try:
                strategy = json.loads(argv[3])
                logger.info(RPC.strategy_add(strategy))
                logger.info(RPC.user_strategies_list(argv[3]))
            except IndexError:
                mesg = 'Run: strategies add <json stryin>\nExample: strategies\
                 add {"strategy":"sma_limit", \
                 "uid":"8091209c-f676-4a11-9c1d-f2f9e96d45e3", \
                 "str_named":"sma_limit"}'
                print_help_function(
                    component="strategies",
                    subname="list_user",
                    help_mesg=mesg)
        if 'view' == argv[2]:
            try:
                logger.info(RPC.strategy_view(argv[3]))
            except IndexError:
                mesg = 'Run: strategies view <str_id>\nExample:strategies view\
                 8091209c-f676-4a11-9c1d-f2f9e96d45e3"'
                print_help_function(
                    component="strategies",
                    subname="list_user",
                    help_mesg=mesg)
        if "list" == argv[2]:
            mesg = f"\n {colored.cyan(RPC.strategies_list())}"
            logger.info(mesg)
        if "list_user" == argv[2]:
            try:
                logger.info(RPC.user_strategies_list(argv[3]))
            except IndexError:
                mesg = "Run: strategies list_user <uid_id>\nExample:\
                 strategies list_user f35b8561-558d-48b0-b6a3-1d45e058fa8d"
                print_help_function(
                    component="strategies",
                    subname="list_user",
                    help_mesg=mesg)
        if "edit" == argv[2]:
            mesg = colored.red("API not working")
            print_help_function(
                component="strategies",
                subname="edit",
                help_mesg=mesg)
        if "delete" == argv[2]:
            mesg = colored.red("API not working")
            print_help_function(
                component="strategies",
                subname="delete",
                help_mesg=mesg)


def exchange(argv):
    """ description """
    if len(argv) > 2:
        if 'list' == argv[2]:
            logger.info(RPC.exchanges_list())
        else:
            mesg = colored.red(
                f"API not yet ready for exchange ({argv[2]})")
            print_help_function(
                component="cat_strategies",
                subname="params",
                help_mesg=mesg)


def cat_exchanges(argv):
    """ description """
    if len(argv) > 2:
        if "list" == argv[2]:
            logger.info(
                colored.red("\n\nNo API yet\n\nWait for next releases...\n\n"))


def print_comp_menu(component):
    """ description """
    components = comp.get_components()
    if len(components[component]) == 0:
        return None

    mesg = "-------------------------------------------------------------\n"
    mesg += f"            AVAILABLE COMMANDS FOR {component.upper()}       \n"
    mesg += "--------------------------------------------------------------"
    puts(colored.magenta(mesg))
    for compo in components[component]:
        puts(colored.blue(compo))
    puts(colored.magenta("----------------------------------------------\n"))
    return None


def print_help_function(component, subname, help_mesg):
    """ description """
    mesg = "----------------------------------------------------------------\n"
    mesg += f"            HELP FOR {component.upper()} FUNCTION ({subname}) \n"
    mesg += "---------------------------------------------------------------"
    puts(colored.magenta(mesg))
    puts(colored.blue(help_mesg))
    puts(colored.magenta("-----------------------------------------------\n"))


def run_help():
    """ description """
    components = comp.get_components()
    mesg = "----------------------------------------------------------------\n"
    mesg += "             AVAILABLE PLATFORM COMPONENTS                     \n"
    mesg += "---------------------------------------------------------------\n"
    puts(colored.magenta(mesg))

    for compo, commands in components.items():
        puts(colored.cyan(compo))
        for cmd in commands:
            with indent(8):
                puts(colored.blue(cmd))
    mesg += colored.magenta("----------------------------------------------\n")
    # logger.info(mesg)


def validate_command(argv):
    """ description """
    components = comp.get_components()
    if argv[1] in components:
        if len(argv) <= 2:
            return True
        if argv[2] in components[argv[1]]:
            return True
        print_comp_menu(component=argv[1])
        # logger.info(colored.cyan("Sub command (%s) for (%s) not found."
        # %(argv[2], argv[1])))#run_help()
        return False
    mesg = f"Command ({argv[1]}) not found. Type help or h to view \
    all available commands."
    logger.info(colored.cyan(mesg))
    return False
