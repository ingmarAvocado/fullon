import uuid
import sys
from libs import settings
from libs.settings_config import fullon_settings_loader
from run import install_manager
from run import user_manager
from libs.structs.symbol_struct import SymbolStruct
from libs.structs.exchange_struct import ExchangeStruct
from libs.database import Database


def install():
    # -------------------------------------------------------
    # New bot #4
    user = user_manager.UserManager()
    UID = user.get_user_id(mail='admin@fullon')
    details = user.user_details(uid=UID)
    with Database() as dbase:
        exch = dbase.get_exchange(user_id=UID)[0]
    system = install_manager.InstallManager()

    # First lets install some symbols
    SYMBOL = {
        "symbol_id": "00000000-0000-0000-0000-000000000004",
        "symbol": "ETH/BTC",
        "exchange_name": "kraken",
        "updateframe": "1h",
        "backtest": "500",
        "decimals": 6,
        "base": "BTC",
        "ex_base": "",
        "futures": "t"}
    system.install_symbol(symbol=SymbolStruct.from_dict(SYMBOL))

install()
