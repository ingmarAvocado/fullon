echo "Bitstamp - compression 10" 
./fullon_daemons.py bots simul '{"bot_id":"69c43076-9c2c-4453-9386-6e5a38a751c5", "days":"702", "verbose":"0", "compression":"60", "visual":"0", "params":{"yema1":"30", "period":"3", "angle":"3"}}'

echo "Bitmex - compression 10" 
./fullon_daemons.py bots simul '{"bot_id":"596564e1-0ffd-4350-95b1-94e6a16fde6b", "days":"702", "verbose":"0", "compression":"2", "visual":"0", "params":{"yema1":"30", "period":"3", "angle":"3"}}'

echo "Binance - compression 10" 
./fullon_daemons.py bots simul '{"bot_id":"52717ebb-a99e-4f46-bd2f-81a0d3184cfb", "days":"702", "verbose":"0", "compression":"2", "visual":"0", "params":{"yema1":"30", "period":"3", "angle":"3"}}'


echo "Bitmex - compression 10" 
./fullon_daemons.py bots simul '{"bot_id":"596564e1-0ffd-4350-95b1-94e6a16fde6b", "days":"702", "verbose":"0", "compression":"2", "visual":"0", "params":{"yema1":"25", "period":"3", "angle":"3"}}'

echo "Binance - compression 10" 
./fullon_daemons.py bots simul '{"bot_id":"52717ebb-a99e-4f46-bd2f-81a0d3184cfb", "days":"702", "verbose":"0", "compression":"2", "visual":"0", "params":{"yema1":"25", "period":"3", "angle":"3"}}'

